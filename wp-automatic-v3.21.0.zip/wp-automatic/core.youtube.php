<?php

// Main Class
require_once 'core.php';

Class WpAutomaticYoutube extends wp_automatic{


/*
 * ---* youtube get links ---
 */
function youtube_fetch_links($keyword, $camp) {
	echo "<br>so I should now get some links from youtube for keyword :" . $keyword;

	//check if there is an api key added
	$wp_automatic_yt_tocken = get_option('wp_automatic_yt_tocken','');

	if(trim($wp_automatic_yt_tocken) == ''){
		echo '<br>Youtube API key is required, please visit settings page and add it';
		return false;
	}

	// ini options
	$camp_opt = unserialize ( $camp->camp_options );
	if( stristr($camp->camp_general, 'a:') ) $camp->camp_general=base64_encode($camp->camp_general);
	$camp_general=unserialize(base64_decode($camp->camp_general));
	$camp_general=array_map('stripslashes', $camp_general);

	$sortby = $camp->camp_youtube_order;
	$camp_youtube_category = $camp->camp_youtube_cat;

	// get start-index for this keyword
	$query = "select keyword_start ,keyword_id from {$this->wp_prefix}automatic_keywords where keyword_name='$keyword' and keyword_camp={$camp->camp_id}";
	$rows = $this->db->get_results ( $query );
	$row = $rows [0];
	$kid = $row->keyword_id;
	$start = $row->keyword_start;
	if ($start == 0)
		$start = 1;


	if ($start == - 1 ) {
		echo '<- exhausted keyword';
			
		//check if it is reactivated or still deactivated
		if($this->is_deactivated($camp->camp_id, $keyword)){
			$start =1;
		}else{
			//still deactivated
			return false;
		}
			

	}

	echo ' index:' . $start;

	// update start index to start+50
	if( ! in_array( 'OPT_YT_CACHE' , $camp_opt )){
		echo '<br>Caching is not enabled setting youtube page to query to 1';
		$nextstart =1;
	}else{
		$nextstart = $start + 50;
	}



	$query = "update {$this->wp_prefix}automatic_keywords set keyword_start = $nextstart where keyword_id=$kid ";
	$this->db->query ( $query );

	// get items
	$orderby = $camp->camp_youtube_order;
	$cat = $camp->camp_youtube_cat;

		


	if ($cat != 'All')
		$criteria .= '&category=' . $cat;

	//base url
	$search_url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&key=".trim($wp_automatic_yt_tocken)."&maxResults=50";
		
	//keyword add
	if( trim($keyword) != '*') {
		$search_url = $search_url .'&q='.urlencode(trim($keyword));
	}
		
	//published after filter 2014-3-10T00:00:00.000-00
	if(in_array('OPT_YT_DATE', $camp_opt)){
		$beforeDate=$camp_general['cg_yt_dte_year']."-".$camp_general['cg_yt_dte_month']."-".$camp_general['cg_yt_dte_day']."T00:00:00.000-00";
		$search_url.= "&publishedAfter=".$beforeDate;
	}
		
	//OPT_YT_LIMIT_EMBED
	if(in_array('OPT_YT_LIMIT_EMBED', $camp_opt)){
		$search_url.= "&videoEmbeddable=true";
	}
		
	//license
	$cg_yt_license = $camp_general['cg_yt_license'];
	if( trim($cg_yt_license)!='' && $cg_yt_license != 'any'){
		$search_url.="&videoLicense=".$cg_yt_license;
	}
		
	//cg_yt_type
	$cg_yt_type = $camp_general['cg_yt_type'];
	if( trim($cg_yt_type)!='' && $cg_yt_type != 'any'){
		$search_url.="&videoType=".$cg_yt_type;
	}
		
		
	//videoDuration
	$cg_yt_duration = $camp_general['cg_yt_duration'];
	if( trim($cg_yt_duration)!='' && $cg_yt_duration != 'any'){
		$search_url.="&videoDuration=".$cg_yt_duration;
	}

	//videoDefinition
	$cg_yt_definition = $camp_general['cg_yt_definition'];
	if( trim($cg_yt_definition)!='' && $cg_yt_definition != 'any'){
		$search_url.="&videoDefinition=".$cg_yt_definition;
	}
		
	//order
	$camp_youtube_order = $camp->camp_youtube_order;
	if(trim($camp_youtube_order) == 'published') $camp_youtube_order = 'date';
	$search_url.="&order=".$camp_youtube_order;
		
	//videoCategoryId
	$videoCategoryId = $camp->camp_youtube_cat;
	if(trim($videoCategoryId) != 'All' && is_numeric($videoCategoryId)){
		$search_url.="&videoCategoryId=".$videoCategoryId;
	}
		
	//regionCode
	if(in_array('OPT_YT_LIMIT_CTRY', $camp_opt) && trim($camp_general['cg_yt_ctr']) !=''){
		$search_url.="&regionCode=".trim($camp_general['cg_yt_ctr']);
	}
		
	//relevanceLanguage
	if(in_array('OPT_YT_LIMIT_LANG', $camp_opt) && trim($camp_general['cg_yt_lang']) !=''){
		$search_url.="&relevanceLanguage=".trim($camp_general['cg_yt_lang']);
	}

		
	if (in_array ( 'OPT_YT_USER', $camp_opt )) {
		echo '<br>Fetching vids for specific user/channel ' . $camp->camp_yt_user;

		//check if playlist
		if (in_array ( 'OPT_YT_PLAYLIST', $camp_opt )) {
			echo '<br>Specific Playlist:'.$camp_general['cg_yt_playlist'];

			$search_url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=".$camp_general['cg_yt_playlist']."&key=".trim($wp_automatic_yt_tocken)."&maxResults=50";

		}else{
			$camp_yt_user = $camp->camp_yt_user;
			$search_url.= "&channelId=".trim($camp_yt_user);
		}
			
			


	} else {

		//no user just search
			
	}

	//check nextpagetoken
	$nextPageToken = get_post_meta($camp->camp_id,'wp_automatic_yt_nt_'.md5($keyword),true);

	if(  in_array( 'OPT_YT_CACHE' , $camp_opt )){
			
		if(trim($nextPageToken) != ''  ){
			echo '<br>nextPageToken:'.$nextPageToken;
			$search_url.= '&pageToken='.$nextPageToken;
		}else{
			echo '<br>No page token let it the first page';
		}
			
	}

	echo '<br>Search URL:'.$search_url;

	//process request
	curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
	curl_setopt($this->ch, CURLOPT_URL, trim($search_url));
	$exec=curl_exec($this->ch);
	$x=curl_error($this->ch);

	//verify reply
	if(!stristr($exec, '"kind"')){
		echo '<br>Not valid reply from Youtube:'.$exec.$x;
		return false;
	}

	$json_exec = json_decode($exec);

	//check nextpage token
	if(isset($json_exec->nextPageToken) && trim($json_exec->nextPageToken)!='' ){
		$newnextPageToken = $json_exec->nextPageToken;
		echo '<br>New page token:'.$newnextPageToken;
		update_post_meta($camp->camp_id, 'wp_automatic_yt_nt_'.md5($keyword), $newnextPageToken);
	}else{
		//delete the token
		echo '<br>No next page token';
		delete_post_meta($camp->camp_id, 'wp_automatic_yt_nt_'.md5($keyword));
			
		//set start to -1 exhausted
		$query = "update {$this->wp_prefix}automatic_keywords set keyword_start = -1 where keyword_id=$kid";
		$this->db->query ( $query );
			
		//deactivate for 60 minutes
		$this->deactivate_key($camp->camp_id, $keyword);
			
	}

	//get items
	$search = array();
	$search = $json_exec->items;

	// disable keyword if no new items
	if (count ( $search ) == 0) {
		echo '<br>No more vids for this keyword deactivating it ..';
		$query = "update {$this->wp_prefix}automatic_keywords set keyword_start = -1 where keyword_id=$kid";
		$this->db->query ( $query );
			
		//deactivate for 60 minutes
		$this->deactivate_key($camp->camp_id, $keyword);
			
		return;
	}

	echo '<ol>';

	//reversing?
	if(in_array('OPT_YT_REVERSE', $camp_opt)){
		echo '<br>Reversing vids list order.';
		$search = array_reverse($search);
	}

	foreach ( $search as $itm ) {
			
			
		//general added details
		$general = array();
			
		//get vid id from response
		if( stristr($search_url,'playlistItems' ) ){
			$vid_id = $itm->snippet->resourceId->videoId;
		}else{
			$vid_id = $itm->id->videoId;
		}
			
		//vid url
		$link_url = 'https://www.youtube.com/watch?v='.$vid_id;
		$httplink_url =  'http://www.youtube.com/watch?v='.$vid_id;
			
		//vid thumbnail
		$link_img = $itm->snippet->thumbnails->high->url;
			
		//get largest size
		//$link_img = str_replace('hqdefault', 'hqdefault', $link_img);
			
		//get item title
		$link_title = addslashes ( $itm->snippet->title );
			
		//get item description
		$link_desc = addslashes ( $itm->snippet->description );

		//channel title
		$general['vid_author_title']= $itm->snippet->channelTitle;

		//channel id
		$author = addslashes ( $itm->snippet->channelId );
			
		//link time
		$link_time = strtotime($itm->snippet->publishedAt);

		//Clear these values and generate at runtime to save costs of api requests
		$link_player = ''  ;
			
		//needs a separate request with v3 api
		$link_views = '';
		$link_rating = '';
		$link_duration = '';
			
		echo '<li>' . $link_title . '</li>';
			
		//echo 'Published:'. date('Y-m-d',$itm['time']).' ';
			
		if( $this->is_execluded($camp->camp_id, $link_url) ){
			echo '<-- Execluded';
			continue;
		}
			
		//check if older than minimum date
		if(in_array('OPT_YT_DATE', $camp_opt)   && in_array ( 'OPT_YT_PLAYLIST', $camp_opt )  ){

			if( $this->is_link_old($camp->camp_id,  $link_time  ) ){
				echo '<--old post execluding...';
				continue;
			}
				
		}

		//serializing general
		$general = base64_encode(serialize($general));
			
			
		if ( ! $this->is_duplicate($link_url) && ! $this->is_duplicate($httplink_url) )  {
			$query = "INSERT INTO {$this->wp_prefix}automatic_youtube_links ( link_url , link_title , link_keyword  , link_status , link_desc ,link_time,link_rating ,link_views,link_player,link_img,link_author,link_duration, link_general ) VALUES ( '$link_url', '$link_title', '{$camp->camp_id}_$keyword', '0' ,'$link_desc','$link_time','$link_rating','$link_views','$link_player','$link_img','$author','$link_duration','$general')";
			$this->db->query ( $query );
		} else {
			echo ' <- duplicated <a href="'.get_edit_post_link($this->duplicate_id).'">#'.$this->duplicate_id.'</a>';
		}
	}
	echo '</ol>';
}
	
/*
 * ---* youtube post ---
 */
function youtube_get_post($camp) {
	$camp_opt = unserialize ( $camp->camp_options );
	$keywords = explode  ( ',', $camp->camp_keywords );
	if( stristr($camp->camp_general, 'a:') ) $camp->camp_general=base64_encode($camp->camp_general);
	$camp_general = unserialize ( base64_decode( $camp->camp_general ) );
	$camp_general=array_map('stripslashes', $camp_general);
	$camp_post_content = $camp->camp_post_content;
	$camp_post_custom_v = implode(',', unserialize ( $camp->camp_post_custom_v ) );

	foreach ( $keywords as $keyword ) {
			
		$keyword = trim($keyword);
			
		if (trim ( $keyword ) != '') {

			echo '<br>Keyword:'.$keyword;

			//update last keyword
			update_post_meta($camp->camp_id, 'last_keyword', trim($keyword));

			// getting links from the db for that keyword
			$query = "select * from {$this->wp_prefix}automatic_youtube_links where link_keyword='{$camp->camp_id}_$keyword' and link_status ='0'";
			$res = $this->db->get_results ( $query );



			// when no links lets get new links
			if (count ( $res ) == 0) {
				$this->youtube_fetch_links ( $keyword, $camp );
				// getting links from the db for that keyword
					
				$res = $this->db->get_results ( $query );
			}


			//deleting duplicated items
			$res_count = count($res);
			for($i=0;$i< $res_count;$i++){

				$t_row = $res[$i];
				$t_link_url=$t_row->link_url;

				if( $this->is_duplicate($t_link_url) ){
						
					//duplicated item let's delete
					unset($res[$i]);
						
					echo '<br>Vid ('. $t_row->link_title .') found cached but duplicated <a href="'.get_permalink($this->duplicate_id).'">#'.$this->duplicate_id.'</a>'  ;
						
					//delete the item
					$query = "delete from {$this->wp_prefix}automatic_youtube_links where link_id='{$t_row->link_id}'";
					$this->db->query ( $query );
						
				}else{
					break;
				}

			}

			// check again if valid links found for that keyword otherwise skip it
			if (count ( $res ) > 0) {
					
				// lets process that link
				$ret = $res [$i];

					
				echo '<br>Link:'.$ret->link_url;
					
				//extract video id
				$temp_ex=explode('v=', $ret->link_url);
				$vid_id=$temp_ex[1];
					
				//set used url
				$this->used_link = trim($ret->link_url);
					
				$temp ['vid_title'] = trim($ret->link_title);
				$temp ['vid_url'] = trim($ret->link_url);
				$temp ['source_link'] = trim($ret->link_url);
					
				//generate player
				$width = $camp_general['cg_yt_width'];
				$height = $camp_general['cg_yt_height'];
				if(trim($width) == '') $width=580;
				if(trim($height) == '') $height=385;

					
					
				$embedsrc= "https://www.youtube.com/embed/".$vid_id;
					
				if (in_array('OPT_YT_SUGGESTED', $camp_opt) && in_array('OPT_YT_AUTO', $camp_opt) ){

					$embedsrc.= '?rel=0&autoplay=1';
						
				}elseif( in_array('OPT_YT_SUGGESTED', $camp_opt) ){

					$embedsrc.= '?rel=0';

				}elseif( in_array('OPT_YT_AUTO', $camp_opt) ){

					$embedsrc.= '?autoplay=1';

				}
					
					
				$temp ['vid_player'] =  '<iframe width="'.$width.'" height="'.$height.'" src="'.$embedsrc.'" frameborder="0" allowfullscreen></iframe>';
					
				//ini get video details flag if true will request yt again for new data
				$get_vid_details = false;
				$get_vid_details_parts = array();
					
				//statistics part
				$temp ['vid_views'] = trim($ret->link_views);
				$temp ['vid_rating'] = trim($ret->link_rating);
					
				//general
				$general =  unserialize( base64_decode ($ret->link_general) );
				$temp ['vid_author_title'] = $general['vid_author_title'];
					
				//merging post content with custom fields values to check what tags
				$camp_post_content_original = $camp_post_content;
				$camp_post_content = $camp_post_custom_v . $camp_post_content;
					
				if ( stristr($camp_post_content, 'vid_views') || stristr($camp_post_content, 'vid_rating') || stristr($camp_post_content, 'vid_likes') || stristr($camp_post_content, 'vid_dislikes') || PARENT_THEME =='truemag' || PARENT_THEME =='newstube' ){
					$get_vid_details = true;
					$get_vid_details_parts[] = 'statistics';
				}
					
					
				//contentdetails part
				$temp ['vid_duration'] =  trim($ret->link_duration);
					
				if ( stristr($camp_post_content, 'vid_duration')){
					$get_vid_details = true;
					$get_vid_details_parts[] = 'contentDetails';
				}

				//snippet part full content
				$temp ['vid_desc'] = trim($ret->link_desc);
					
				//if full description from youtube or tags let's get them
				if(in_array('OPT_YT_FULL_CNT', $camp_opt)  ){
					$get_vid_details = true;
					$get_vid_details_parts[] = 'snippet';

				}
					
					
				//restore the content
				$camp_post_content = $camp_post_content_original   ;
					
				//now get the video details again if active
				if($get_vid_details){

					echo '<br>Getting more details from youtube for the vid..';

					//token
					$wp_automatic_yt_tocken = trim(get_option('wp_automatic_yt_tocken',''));

					//curl get
					$x='error';
					$ccurl='https://www.googleapis.com/youtube/v3/videos?key='.$wp_automatic_yt_tocken.'&part='.implode(',', $get_vid_details_parts).'&id='.$vid_id;

					echo '<br>yt link:'.$ccurl;

					curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
					curl_setopt($this->ch, CURLOPT_URL, trim($ccurl));
					$exec=curl_exec($this->ch);
					$x=curl_error($this->ch);

						
					if(stristr($exec, 'kind')){
							
						$json_exec = json_decode($exec);
						$theItem = $json_exec->items[0];
							
						//check snippet
						if( isset($theItem->snippet) ){
							//setting full content
							$temp ['vid_desc'] =  $theItem->snippet->description;
							echo '<br>Full description set';
						}
							
						//check contentdetails details
						if( isset($theItem->contentDetails)){
							$temp ['vid_duration'] = $theItem->contentDetails->duration;

							$temp ['vid_duration'] = str_replace('PT', '', $temp ['vid_duration']);
							$temp ['vid_duration'] = str_replace('M', ':', $temp ['vid_duration']);
							$temp ['vid_duration'] = str_replace('H', ':', $temp ['vid_duration']);
							$temp ['vid_duration'] = str_replace('S', '', $temp ['vid_duration']);

						}
							
						//check statistics details
						if( isset($theItem->statistics)){
							$temp ['vid_views'] = $theItem->statistics->viewCount;

							$likeCount=$theItem->statistics->likeCount;
							$dislikeCount = $theItem->statistics->dislikeCount;

							$rating = $likeCount/($likeCount + $dislikeCount);
							$rating = $rating  * 5;
							$rating = number_format($rating,2);

							$temp ['vid_rating'] = $rating;
							$temp ['vid_likes'] = $theItem->statistics->likeCount;
							$temp ['vid_dislikes'] = $theItem->statistics->dislikeCount;

								
						}

					}else{
						echo '<br>no valid reply from youtube ';
					}
						

				}
					

					
				$temp ['vid_img'] = trim($ret->link_img);
				$temp ['vid_author'] = trim($ret->link_author);
				$temp ['vid_time'] = trim($ret->link_time);
				$temp ['vid_id'] =trim($vid_id);
				$this->used_keyword = $ret->link_keyword;
					

					
				//if vid_image contains markup extract the source only
				if(stristr($temp['vid_img'], '<img')){
					preg_match_all('/src\="(.*?)"/',$temp['vid_img'],$matches);
					$temp['vid_img'] = $matches[1][0];
				}
					
					

				//curl get
				$x='error';
				$url=$this->used_link;
					
				curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
				curl_setopt($this->ch, CURLOPT_URL, trim($url));
				$exec=curl_exec($this->ch);
				$x=curl_error($this->ch);

					
				if(trim($x) != '') echo '<br>'.$x;

				//tags
				if(in_array('OPT_YT_TAG', $camp_opt)){

					//extracting tags
					echo '<br>Extracting youtube video tags from youtube ';

					//<meta name="keywords" content="wordpress plugin, spin, rewriter, rewrite, auto rewrite posts, auto rewrite articles, wordpress rewriter, wordpress spinner, spinrewriter, spin rewwriter">
					if(stristr($exec, 'name="keywords"')){
						//extract it
						preg_match_all('/keywords" content="(.*?)"/', $exec,$matches);

						$tags= $matches[1][0];

							
						if(stristr($tags, ',')){
							$tag_count=count(explode(',', $tags));
							echo '<br>Found '.$tag_count . ' tags ';
								
							$this->used_tags=$tags ;
								
						}

					}else{
						echo '<br>Can not find keywords meta tag';
					}

				}



				// update the link status to 1
				$query = "update {$this->wp_prefix}automatic_youtube_links set link_status='1' where link_id=$ret->link_id";
				$this->db->query ( $query );
					
				// if cache not active let's delete the cached videos and reset indexes
				if (! in_array ( 'OPT_YT_CACHE', $camp_opt )) {
					echo '<br>Cache disabled claring cache ...';
					$query = "delete from {$this->wp_prefix}automatic_youtube_links where link_keyword='{$camp->camp_id}_$keyword' and link_status ='0'";
					//$query = "update {$this->wp_prefix}automatic_youtube_links set link_status ='1' where link_keyword='{$camp->camp_id}_$keyword' and link_status ='0'";

					$this->db->query ( $query );

					// reset index
					$query = "update {$this->wp_prefix}automatic_keywords set keyword_start =1 where keyword_camp={$camp->camp_id}";
					$this->db->query ( $query );
				}
					
				return $temp;
			} else {
					
				echo '<br>No links found for this keyword';
			}
		} // if trim
	} // foreach keyword
}

}