<?php

// Main class to inherit wp_automatic
require_once 'core.php';

// Specific articles class
Class WpAutomaticArticles extends wp_automatic{

/*
 * ---* article base get links for a keyword ---
 */
function article_base_getlinks($keyword, $camp) {
		
	// get associated page num from the keyword and camp id from wp_automatic_articles_keys
	$query = "select * from {$this->wp_prefix}automatic_articles_keys where keyword = '$keyword' and camp_id  = '$camp->camp_id'";
	$camp_key = $this->db->get_results ( $query );
	$camp_key = $camp_key [0];
		

	if (count ( $camp_key ) == 0){
		echo '<br>Keyword record not found';
		return false;
	}
		
	$page = $camp_key->page_num;
	
	if (   $page == - 1) {

		//check if it is reactivated or still deactivated
		if($this->is_deactivated($camp->camp_id, $keyword)){
				
			$page = '0000';

		}else{
			//still deactivated
				
			return false;
		}

	}
		
	//Make sure start is 0,1,2 for yandex
	if( ! stristr($page, '1994') ){
		$page = 0;
	}else{
		$page = str_replace('1994', '', $page);
	}
	 
		
	echo '<br>Trying to call EA for new links start from page:' . $page;
	
	$keywordenc = urlencode ( 'site:ezinearticles.com '. trim($keyword) .' inurl:id'  );
	 	
	$curlurl="https://www.yandex.com/search/?text=$keywordenc&lr=20991&p=$page&numdoc=50";
	
	echo '<br>Yandex url:'.$curlurl;
	
	 //curl get
	 $x='error';
	 curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
	 curl_setopt($this->ch, CURLOPT_URL, trim($curlurl));
	 $exec=$this->curl_exec_follow($this->ch);
	 $x=curl_error($this->ch);
	  
	  
	//no content and 302 header exists
	if(trim($exec) == ''){
		echo '<br>Empty results from Yandex page';
		return false;
	}
		
	if(stristr($exec, 'no results')   ){
		echo '<br>Yandex No results found';
		$this->deactivate_key($camp->camp_id, $keyword);
		return false;
	}
		
	$exec = str_replace('&amp;', '&', $exec );
	
	// Articles links
	preg_match_all('{<a class="link serp-item__title-link.*?href="(.*?)"}s', $exec , $matchsArr);
	$rawUrls = $matchsArr[1];
	$foundUrls = array();
	
	// Cache urls hghltd.yandex
	preg_match_all('{href="(http://hghltd\.yandex\.net.*?)"}s', $exec , $matchsArr2);
	$cacheLinksArr = $matchsArr2[1];
		
	// Verify valid article link 	
	foreach ($rawUrls as $ezineUrl){
		
		if(trim($ezineUrl) != '' && stristr($ezineUrl, 'ezinearticles.com')){
			$foundUrls[] = $ezineUrl;
		}
		
	}
	
	// No links? return if yes	
	if(count($foundUrls) == 0 ){
		echo '<br> no matching results found for this keyword';
		$query = "update {$this->wp_prefix}automatic_articles_keys set page_num = '-1'  where keyword = '$keyword' and camp_id  = '$camp->camp_id'";
		$this->db->query ( $query );

		//deactivate for 60 minutes
		$this->deactivate_key($camp->camp_id, $keyword);
		return false;
	}
		
	// Report links count
	echo '<br>Links got from EA:' . count ( $foundUrls );
	$this->log ( 'links found', count ( $foundUrls ) . ' New Links added from ezine articles to post articles from' );
		
	
	echo '<ol>';
	$i = 0;
	foreach ( $foundUrls as $link ) {

		// verify id in link
		echo '<li>Link:'.($link);
		$link_url = $link;
			
		if (stristr ( $link, 'id=' )) {
				
			// verify uniqueness
			if( $this->is_execluded($camp->camp_id, $link_url) ){
				echo '<-- Execluded';
				continue;
			}
				

			if ( ! $this->is_duplicate($link_url) )  {
				
				$title = '';
				$cache = '';
				
				// cache link
				$urlEncoded = urlencode($link_url);
				
				foreach ($cacheLinksArr as $cacheLink){
					if( strpos($cacheLink, $urlEncoded)){
						$cache = $cacheLink;
						break;
					}
				}
				
				$query = "insert into {$this->wp_prefix}automatic_articles_links (link,keyword,page_num,title,bing_cache) values('$link' ,'$keyword','$page','$title','$cache')";
				$this->db->query ( $query );
				$freshlinks = 1;
			} else {
				echo ' <- duplicated <a href="'.get_edit_post_link($this->duplicate_id).'">#'.$this->duplicate_id.'</a>';
			}
				
			echo '</li>';

			// incrementing i
				
		} // if contain id
		$i ++;
	} // foreach link

	echo '</ol>';
		
	// updating page num
	$page = $page + 1;
		
	//check if this page exists
	if(stristr($exec, ';p='.$page)){
		echo '<br>Next Page exists starts at: '.$page;
	}else{

		//echo $exec;

		echo '<br>Last page reached resetting search index...';
		$page = -1;
		$this->deactivate_key($camp->camp_id, $keyword);

	}
	
	if($page != -1)
	$page= "1994$page";
	
	$query = "update {$this->wp_prefix}automatic_articles_keys set page_num = $page  where keyword = '$keyword' and camp_id  = '$camp->camp_id' ";
	$this->db->query ( $query );
		
	//last page check


	return;
}
	
/*
 * ---* articlebase process camp ---
 */
function articlebase_get_post($camp) {
	$keywords = $camp->camp_keywords;
	$keywords = explode ( ",", $keywords );

	foreach ( $keywords as $keyword ) {
			
		$keyword = trim($keyword);
			
		if (trim ( $keyword ) != '') {
				
				
			//update last keyword
			update_post_meta($camp->camp_id, 'last_keyword', trim($keyword));

			// check if keyword exhausted to skip
			$query = "select * from {$this->wp_prefix}automatic_articles_keys where keyword = '$keyword' and camp_id='$camp->camp_id'";
			$key = $this->db->get_results ( $query );
			$key = $key [0];

				
			// process feed
			echo '<br><b>Getting article for Keyword:</b>' . $keyword;
				
			// get links to fetch and post on the blogs
			$query = "select * from {$this->wp_prefix}automatic_articles_links where keyword = '$keyword' and status =0 and link like '%ezinearticles.com%'";
			$links = $this->db->get_results ( $query );
				
			// when no links available get some links
			if (count ( $links ) == 0) {

				$this->article_base_getlinks ( $keyword, $camp );
				// get links to fetch and post on the blogs
				$query = "select * from {$this->wp_prefix}automatic_articles_links where keyword = '$keyword' and status =0 and link like '%ezinearticles.com%'";
				$links = $this->db->get_results ( $query );
			}
				
			// if no links then return
			if (count ( $links ) != 0) {

				foreach ( $links as $link ) {
						
					// updating status of the link to posted or 1
					$query = "update {$this->wp_prefix}automatic_articles_links set status = '1' where id = '$link->id'";
					$this->db->query ( $query );
						
					// processing page and getting content
					$url = htmlspecialchars_decode($link->link) ;

					$title = $link->title;

						
					echo '<br>Processing Article :' . urldecode($url);

					$binglink =  "http://webcache.googleusercontent.com/search?q=cache:".urlencode($url);

					curl_setopt ( $this->ch, CURLOPT_HTTPGET, 1 );
					curl_setopt ( $this->ch, CURLOPT_URL, trim (  ( $binglink ) ) );
					curl_setopt ( $this->ch, CURLOPT_REFERER, 'http://ezinearticles.com' );
					$exec = curl_exec ( $this->ch );
					$x = curl_error($this->ch);
						

					$cacheLoadSuccess = false; // success flag
					
					if(stristr($exec,'comments')){
						//valid google cache
						echo '<br>Successfully loaded the page from Google Cache';
						$cacheLoadSuccess = true;
					}else{
						
						// Yandex cache
						$cacheLink = $link->bing_cache;
						
						if(trim($cacheLink) != ''){
							
							echo '<br>Google cache failed Loading from Yandex cache...';
							
							curl_setopt ( $this->ch, CURLOPT_URL, trim (  $cacheLink  ) );
							$exec = curl_exec ( $this->ch );
							
							if(stristr($exec,'comments')){
								//valid google cache
								echo '<br>Successfully loaded the page from Yandex Cache';
								$cacheLoadSuccess = true;
							} 
							 	
						}
						
						if(!$cacheLoadSuccess){
							
							
							// Direct call
							echo '<br>Google cache didnot return valid result direct call to ezine '.$x;
							curl_setopt ( $this->ch, CURLOPT_URL, trim (  ( urldecode( $url ) ) ) );
							curl_setopt ( $this->ch, CURLOPT_REFERER, 'http://ezinearticles.com' );
							$exec = curl_exec ( $this->ch );
	
							if(stristr($exec, 'comments')){
								echo '<br>Ezinearticles returned the article successfully ';
							}else{
								if(stristr($exec,'excessive amount')){
									echo '<br>Ezinearticles says there is excessive amount of traffic';
									return false ;
								}else{
									echo '<br>Ezinearticles did not return the article we called';
									return false ;
								}
							}
							
						}
 	
					}
						

						
					// extracting articles
					$arr = explode ( 'article-content">', $exec );
					$lastpart = $arr [1];
						
					unset ( $arr );
					$newarr = explode ( '<div id="article-resource', $lastpart );
						
					$cont = '<div>' . $newarr [0];

					//striping js
					$cont = preg_replace('{<script.*?script>}s', '', $cont);
					$cont = preg_replace('{<div class="mobile-ad-container">.*?</div>}s', '', $cont);

					// get the title <title>Make Money With Google Profit Kits Exposed - Don't Get Ripped Off!</title>
					@preg_match_all ( "{<title>(.*?)</title>}", $exec, $matches, PREG_PATTERN_ORDER );
					@$res = $matches [1];
					@$ttl = $res [0];
						
					if (isset ( $ttl )) {
						$title = $ttl;
					}
						
					// get author name and author link <a href="/?expert=Naina_Jain" rel="author" class="author-name" title="EzineArticles Expert Author Naina Jain"> Naina Jain </a>
					@preg_match_all ( '{<a href="(.*?)" rel="author.*?>(.*?)</a>}', $exec, $matches, PREG_PATTERN_ORDER );
						
					$author_link = 'http://ezinearticles.com' . $matches [1] [0];

					$author_name = trim ( $matches [2] [0] );
						
						
						
					$ret ['cont'] = $cont;
					$ret ['title'] = $title;
					$ret ['original_title'] = $title;
					$ret ['source_link'] = urldecode($url);
					$ret ['author_name'] = $author_name;
					$ret ['author_link'] = $author_link;
					$ret ['matched_content'] = $cont;
					$this->used_keyword=$link->keyword;
					if( trim($ret['cont']) == '' ) echo ' exec:'.$exec;
						
						
					return $ret;
				} // foreach link
			} // if count(links)
				
		} // if keyword not ''
	} // foreach keyword
}

}