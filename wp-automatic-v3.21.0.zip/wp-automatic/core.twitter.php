<?php

// Main Class
require_once 'core.php';

Class WpAutomaticTwitter extends wp_automatic{


function twitter_fetch_items($keyword,$camp ){

	//report
	echo "<br>So I should now get some tweets from Twitter for Search :" . $keyword;

	//verify twitter token
	$wp_automatic_tw_consumer = trim( get_option('wp_automatic_tw_consumer',''));
	$wp_automatic_tw_secret = trim( get_option('wp_automatic_tw_secret',''));

	if( ($wp_automatic_tw_consumer) == '' || $wp_automatic_tw_consumer == ''){
		echo '<br>Twitter consumer key and secret key are required, please visit the settings page and add it';
		return false;
	}
		
	// ini options
	$camp_opt = unserialize ( $camp->camp_options );
	if( stristr($camp->camp_general, 'a:') ) $camp->camp_general=base64_encode($camp->camp_general);
	$camp_general = unserialize ( base64_decode( $camp->camp_general ) );
	$camp_general=array_map('stripslashes', $camp_general);
		

	// get start-index for this keyword
	$query = "select keyword_start ,keyword_id from {$this->wp_prefix}automatic_keywords where keyword_name='$keyword' and keyword_camp={$camp->camp_id}";
	$rows = $this->db->get_results ( $query );
	$row = $rows [0];
	$kid = $row->keyword_id;
	$start = $row->keyword_start;
	if ($start == 0)
		$start = 1;

	if ($start == - 1) {
		echo '<- exhausted keyword';

		if( ! in_array( 'OPT_IT_CACHE' , $camp_opt )){
			$start =1;
			echo '<br>Cache disabled resetting index to 1';
		}else{

			//check if it is reactivated or still deactivated
			if($this->is_deactivated($camp->camp_id, $keyword)){
				$start =1;
			}else{
				//still deactivated
				return false;
			}

		}

	}


	//generating token if not exists
	$wp_automatic_tw_token = get_option('wp_automatic_tw_token','');

	if(trim($wp_automatic_tw_token) == ''){
			
		echo '<br>Generating a new twitter access token...';
			
		$concated = urlencode($wp_automatic_tw_consumer) . ':'. urlencode($wp_automatic_tw_secret);
			
		$concatedBase64 = base64_encode($concated);

		//curl get
		$x='error';
		$url='https://api.twitter.com/oauth2/token';
			
		curl_setopt($this->ch,CURLOPT_HTTPHEADER,array("Authorization:Basic $concatedBase64" , "Content-Type:application/x-www-form-urlencoded;charset=UTF-8."));
			
		//curl post
		curl_setopt($this->ch, CURLOPT_URL, $url);
		curl_setopt($this->ch, CURLOPT_POST, true);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
		$exec=curl_exec($this->ch);
		$x=curl_error($this->ch);
			
		if(stristr($exec, 'bearer')){

			$token_json = json_decode($exec);
			$wp_automatic_tw_token = $token_json->access_token;

			if(trim($wp_automatic_tw_token) == ''){
				echo '<br>Can not extract twitter token from twitter response:'.$exec;
			}else{
				update_option('wp_automatic_tw_token', $wp_automatic_tw_token);
			}


		}else{
			echo '<br>Response from twitter does not contain the expected token:'.$exec;
			return false;
		}
			
	}

	//good we now have a valid twitter token
	echo ' index:' . $start;

	// update start index to start+1
	$nextstart = $start + 1;
	$query = "update {$this->wp_prefix}automatic_keywords set keyword_start = $nextstart where keyword_id=$kid ";
	$this->db->query ( $query );

		
	 
	//building the twitter url
	$url='https://api.twitter.com/1.1/search/tweets.json?q='.urlencode(trim($keyword));

	//language
	if(in_array('OPT_TW_COUNTRY', $camp_opt)){
			
		$cg_tw_lang = $camp_general['cg_tw_lang'];
			
		if(trim($cg_tw_lang) != ''){
			$url.='&lang='.trim($cg_tw_lang);
		}
	}

		

	//pagination
	// get requrest url from the zero index
	if( $start == 1 ){

		//use first base query


	}else{

		//not first page get the bookmark
		$wp_tw_next_max_id = get_post_meta ($camp->camp_id,'wp_twitter_next_max_id'.md5($keyword),1);

		if(trim($wp_tw_next_max_id) == ''){
			echo '<br>No new page max id';
				
		}else{
			echo '<br>max_id:'.$wp_tw_next_max_id;
			$url = $url ."&max_id=".$wp_tw_next_max_id ;
		}

	}



	//report url
	echo '<br>Twitter url:'.$url;
		
	//skip ssl
	curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);

	//authorize
	curl_setopt($this->ch,CURLOPT_HTTPHEADER,array("Authorization: Bearer $wp_automatic_tw_token"));

	curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
	curl_setopt($this->ch, CURLOPT_URL, trim($url));

	$exec=curl_exec($this->ch);
	$x=curl_error($this->ch);

		
		
	//validating reply
	if(stristr($exec, 'search_metadata')){
		//valid reply

		//handle pins
		$arr = json_decode($exec);

		$items = $arr->statuses;


			
			
		//reverse
		if(in_array('OPT_PT_REVERSE', $camp_opt)){
			echo '<br>Reversing order';
			$items = array_reverse($items);
		}
			
		echo '<ol>';

		//loop pins
		$i = 0;
		foreach ($items as $item){


			//report
			echo '<li>http://twitter.com/statuses/'.$item->id_str;

				
			//build item
			$itm['item_id']  = $item->id;
			$itm['item_url'] = 'http://twitter.com/statuses/'.$item->id_str ;
			$itm['item_description'] = $item->text;
			$itm['item_description'] =  $this->hyperlink_this( $itm['item_description']);
				
			//check images
			if(isset($item->entities->media[0])){

				$media_img =$item->entities->media[0];

				if($media_img->type == 'photo'){
					//good let's append it
					$itm['item_description'] = '<img src="'.$media_img->media_url.'" /><br><br>'.$itm['item_description'];
				}
					
			}
				
			$itm['item_retweet_count'] = $item->retweet_count;
			$itm['item_favorite_count'] = $item->favorite_count;
			$itm['item_author_id'] = $item->user->id_str;
			$itm['item_author_name'] = $item->user->name;
			$itm['item_author_description'] = $item->user->description;
			$itm['item_author_url'] = $item->user->url;
				
			if(trim($itm['item_author_url']) == ''){
				$itm['item_author_url'] = 'https://twitter.com/intent/user?user_id='.$itm['item_author_id'];
			}
				
			$itm['item_author_profile_image'] = str_replace('normal', '200x200', $item->user->profile_image_url  )  ;
				
			$itm['item_author_profile_background_image'] = $item->user->profile_background_image_url;
				
				
			$itm['item_created_at'] = $item->created_at;

			$data = base64_encode(serialize ( $itm ));

			if( $this->is_execluded($camp->camp_id, $itm['item_url']) ){
				echo '<-- Execluded';
				continue;
			}

			if ( ! $this->is_duplicate($itm['item_url']) )  {
				$query = "INSERT INTO {$this->wp_prefix}automatic_general ( item_id , item_status , item_data ,item_type) values (    '{$itm['item_id']}', '0', '$data' ,'tw_{$camp->camp_id}_$keyword')  ";
				$this->db->query ( $query );
			} else {
				echo ' <- duplicated <a href="'.get_edit_post_link($this->duplicate_id).'">#'.$this->duplicate_id.'</a>';
			}

			echo '</li>';
			$i++;

		}

		echo '</ol>';

		echo '<br>Total '. $i .' Tweets found & cached';

		//check if nothing found so deactivate
		if($i == 0 ){
			echo '<br>No new tweets found ';
			echo '<br>Keyword have no more tweets deactivating...';
			$query = "update {$this->wp_prefix}automatic_keywords set keyword_start = -1 where keyword_id=$kid ";
			$this->db->query ( $query );
			$this->deactivate_key($camp->camp_id, $keyword);
				
			//delete bookmark value
			delete_post_meta($camp->camp_id, 'wp_twitter_next_max_id'.md5($keyword));
		}else{

			//get max id
			if(isset($arr->search_metadata->next_results)){

				//extracting max id
				$next_res = $arr->search_metadata->next_results;
					
				preg_match('{max_id\=(\d*?)\&}', $next_res ,$matchmax);

				$next_max = $matchmax[1];
					
				if(trim($next_max) !=''){

					echo '<br>Updating max_id:'.$next_max;
					update_post_meta($camp->camp_id, 'wp_twitter_next_max_id'.md5($keyword), $next_max ) ;

				}else{
					echo '<br>Can not extract next max';
				}
					
					
					
			}else{
				echo '<br>No pagination found deleting next page index';
				delete_post_meta($camp->camp_id, 'wp_twitter_next_max_id'.md5($keyword));
			}

		}

	}else{
			
		//no valid reply
		echo '<br>No Valid reply for twitter search <br>'.$exec;
			
	}



}
	
//Twitter
function twitter_get_post($camp){
		
	//ini keywords
	$camp_opt = unserialize ( $camp->camp_options );
	$keywords = explode ( ',', $camp->camp_keywords );
	$camp_general=unserialize(base64_decode($camp->camp_general));
		
	//looping keywords
	foreach ( $keywords as $keyword ) {
			
		$keyword = trim($keyword);
			
		//update last keyword
		update_post_meta($camp->camp_id, 'last_keyword', trim($keyword));
			
		//when valid keyword
		if (trim ( $keyword ) != '') {
				
			//record current used keyword
			$this->used_keyword=$keyword;
				
				
			// getting links from the db for that keyword
			$query = "select * from {$this->wp_prefix}automatic_general where item_type=  'tw_{$camp->camp_id}_$keyword' and item_status ='0'";
			$res = $this->db->get_results ( $query );
				
			// when no links lets get new links
			if (count ( $res ) == 0) {
					
				//get new links
				$this->twitter_fetch_items( $keyword, $camp );
					
				// getting links from the db for that keyword
				$res = $this->db->get_results ( $query );
			}
				
			//check if already duplicated
			//deleting duplicated items
			$res_count = count($res);
			for($i=0;$i< $res_count;$i++){
					
				$t_row = $res[$i];
					
				$t_data =  unserialize (base64_decode( $t_row->item_data) );
					
				$t_link_url=$t_data['item_url'];
					
				if( $this->is_duplicate($t_link_url) ){
						
					//duplicated item let's delete
					unset($res[$i]);
						
					echo '<br>Tweet ('. $t_data ['item_title'] .') found cached but duplicated <a href="'.get_permalink($this->duplicate_id).'">#'.$this->duplicate_id.'</a>'  ;
						
					//delete the item
					$query = "delete from {$this->wp_prefix}automatic_general where item_id='{$t_row->item_id}' and item_type=  'it_{$camp->camp_id}_$keyword'";
					$this->db->query ( $query );
						
				}else{
					break;
				}
					
			}
				
			// check again if valid links found for that keyword otherwise skip it
			if (count ( $res ) > 0) {
					
				// lets process that link
				$ret = $res [$i];
					
				$temp = unserialize ( base64_decode($ret->item_data ));
					
				//generating title
				if(   @trim($temp['item_title']) == '' ){
						
					if(in_array('OPT_IT_AUTO_TITLE', $camp_opt)){
							
						echo '<br>No title generating...';
							
						$cg_it_title_count = $camp_general['cg_it_title_count'];
						if(! is_numeric($cg_it_title_count)) $cg_it_title_count = 80;

						$cleanContent = $this->removeEmoji( $this->strip_urls( strip_tags($temp['item_description']) ));
							
							
							
						if(function_exists('mb_substr')){
							$newTitle = ( mb_substr($cleanContent , 0,$cg_it_title_count));
						}else{
							$newTitle = ( substr( $cleanContent , 0,$cg_it_title_count));
						}
							
						// Clean RT's RT @GoogleStreetArt:
						if( stristr($newTitle, 'RT') && in_array('OPT_IT_TITLE_CLEAN', $camp_opt)){
							echo '<br>Cleaning RT';
							$newTitle = preg_replace('{RT @.*?: }', '', $newTitle);
						}
							
						$temp['item_title'] = ($newTitle).'...';
							
						echo '<br>Generated title:'.$temp['item_title'];
							
							
					}else{
							
						$temp['item_title'] = '(notitle)';
							
					}
						
				}
					
					
				//report link
				echo '<br>Found Link:'.$temp['item_url'] ;
					
				// update the link status to 1
				$query = "update {$this->wp_prefix}automatic_general set item_status='1' where item_id='$ret->item_id' and item_type='tw_{$camp->camp_id}_$keyword' ";
				$this->db->query ( $query );
					
				// if cache not active let's delete the cached items and reset indexes
				if (! in_array ( 'OPT_IT_CACHE', $camp_opt )) {
					echo '<br>Cache disabled claring cache ...';
					$query = "delete from {$this->wp_prefix}automatic_general where item_type='tw_{$camp->camp_id}_$keyword' and item_status ='0'";
					$this->db->query ( $query );
						
						
						
					// reset index
					$query = "update {$this->wp_prefix}automatic_keywords set keyword_start =1 where keyword_camp={$camp->camp_id}";
					$this->db->query ( $query );
						
					delete_post_meta($camp->camp_id, 'wp_instagram_next_max_id'.md5($keyword));
				}
					

				//if card OPT_TW_CARDS
				if(in_array('OPT_TW_CARDS', $camp_opt) || stristr($camp->camp_post_content, 'item_embed') ){

					$item_id = $temp['item_id'];

					//getting card embed https://api.twitter.com/1/statuses/oembed.json?url=https://twitter.com/zzz/status/463440424141459456

					echo '<br>Getting embed code from twitter...';

					//curl get
					$x='error';
					$url='https://api.twitter.com/1/statuses/oembed.json?url=https://twitter.com/zzz/status/463440424141459456';
					$url= str_replace('463440424141459456', $item_id, $url);

					curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
					curl_setopt($this->ch, CURLOPT_URL, trim($url));

					$exec=curl_exec($this->ch);
					$x=curl_error($this->ch);

					if(stristr($exec, 'widgets.js')){

						$json_embed = json_decode($exec);
							
						$embed_html = $json_embed->html;
							
						if(trim($embed_html) !=''){
							
							$temp['item_embed']=$embed_html;
							
							if(in_array('OPT_TW_CARDS', $camp_opt) ) {
								$temp['item_description']=$embed_html;
							}
							
							
						}else{
							echo '<br>Can not extract embed html.';
						}
							
							
					}else{
						echo '<br>Non expected embed reply.';
					}
						
						



				}
					
					
				return $temp;
					
					
			} else {
					
				echo '<br>No links found for this keyword';
			}
		} // if trim
	} // foreach keyword
		
		
		
}

}