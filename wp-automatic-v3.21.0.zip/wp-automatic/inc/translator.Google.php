<?php
/**
 * Class:Microsoft Translator to translate using Google
 * @author sweetheatmn (sweetheatmn@gmail.com)
 * @version 1.0.0
 */

class GoogleTranslator{
	
	public $ch; //curl handler to use 
	
	/**
	 * Constructor to recieve curl handler
	 * @param curl $ch
	 */
	function __construct(&$ch){
		$this->ch = $ch;
	}
	
	/**
	 * Translate text using Google Post request to google translate 
	 * @param unknown $sourceText
	 * @param unknown $fromLanguage
	 * @param unknown $toLanguage
	 * @return string translated text
	 */
	
	function translateText($sourceText , $fromLanguage ,$toLanguage){
		
		// Post 
		$curlurl="https://translate.google.com/";
		$curlpost="sl=$fromLanguage&tl=$toLanguage&js=n&prev=_t&hl=$fromLanguage&ie=UTF-8&text=".urlencode($sourceText)."&file=&edit-text=";
		curl_setopt($this->ch, CURLOPT_URL, $curlurl);
		curl_setopt($this->ch, CURLOPT_POST, true);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $curlpost);
	    curl_setopt($this->ch, CURLOPT_REFERER, "https://translate.google.com/" );
	     

		$exec=curl_exec($this->ch);
		$x=curl_error($this->ch);
		
		// Empty response check 
		if(trim($exec) == ''){
			throw new Exception('Empty translator reply with possible curl error '.$x);
		}
		
		// Validate response result box 
		if( !  stristr($exec, 'result_box') ){
			throw new Exception('Got the reply from Google but no Translated content');
		}
		
		// Extract results 
		$doc = new DOMDocument;
		@$doc->loadHTML($exec);
		
		// xPath object
		$xpath = new DOMXPath($doc);
		
		$xpathMatches = $xpath->query("//span[@id='result_box']");
		$resultBox = $xpathMatches->item(0);
		
		return  $resultBox->nodeValue ;
		
	}
	
}