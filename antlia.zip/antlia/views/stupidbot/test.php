<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">
 
    <h2>Test Campaign</h2>
	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>
	<?php if (array_filter($success)): ?>
	<?php foreach ($success as $message) { ?>
	<div class="updated notice is-dismissible">
		<p><?php echo $message;?></p>
	</div>
	<?php } ?>
	<?php endif; ?>

	<p>This will test your campaign and publish a real post.</p>
	<p>Some keyword(s) will be taken from yout campaign's keyword list</p>
	<form action="" method="post">
        <?php wp_nonce_field( 'sbp_test_campaign', 'sbp_test_campaign' ); ?>
		<?php submit_button('Start Test'); ?>
    </form>
</div><!-- /.wrap -->
