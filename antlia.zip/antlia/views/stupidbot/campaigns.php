<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">
 
    <h2>Campaigns <a href="?page=stupidbot-new" class="add-new-h2">Add New</a></h2>
    <p>A listing of all StupidBot campaign. Hover the row to show action link</p>
    <?php
    	$wp_list_table = new StupidBot_List_Table();
		$wp_list_table->prepare_items();
		$wp_list_table->views();
		$wp_list_table->display();
    ?>
</div><!-- /.wrap -->
