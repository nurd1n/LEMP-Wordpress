<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Add New Campaign</h2>

	<form action="" method="post">
        <?php wp_nonce_field( 'sbp_add_campaign', 'sbp_add_campaign' ); ?>
        <table class="form-table">
        	<tbody>
				<tr>
					<th scope="row">Name</th>
					<td>
						<input class="regular-text" name="new_campaign[name]" value="" type="text" required>
						<p class="description">Your campaign name. Treat this as something like grouping.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Keywords</th>
					<td>
						<textarea cols="40" rows="5" class="regular-text" name="new_campaign[keywords]"></textarea>
						<p class="description" >Put your keywords here, separated by newline. 500-1000 keywords</p>
					</td>
				</tr>
        		<tr>
        			<th scope="row">Template</th>
        			<td>
        				<select name="new_campaign[template]" id="new_campaign[template]" class="postform">
                            <?php foreach($templates as $template):?>
                            <option value="<?php echo pathinfo($template, PATHINFO_FILENAME); ?>"><?php echo basename($template); ?></option>
                            <?php endforeach;?>
                        </select>
						<p class="description">Choose a template for the post</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Hack</th>
					<td>
						<input class="regular-text" name="new_campaign[hack]" value="" type="text">
						<p class="description">i.e. filetype:pdf to filter only pdf file <br>
						site:amazon.com to filter only from amazon.com site <br>
						Leave empty if you don't want to use this</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Post Per Request</th>
					<td>
						<input class="regular-text" name="new_campaign[post_per_run]" value="" type="text" required>
						<p class="description">How many post created everytime campaign is run?</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Category</th>
					<td>
						<?php echo wp_dropdown_categories("show_option_none=Select category&show_count=0&hide_empty=0&orderby=name&echo=0&name=new_campaign[category_id]"); ?>
						<p class="description">Pick a category</p>
					</td>
				</tr>
        		<tr>
        			<th scope="row">Schedule</th>
        			<td>
        				<select name="new_campaign[schedule]" id="new_campaign[schedule]" class="postform">
							<option value="daily">Daily</option>
							<option value="hourly">Hourly</option>
							<option value="twicedaily">Twice a Day</option>
						</select>
						<p class="description">Schedule your post</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Active</th>
					<td>
						<fieldset>
							<label for="new_campaign[active]">
								<input name="new_campaign[active]" id="new_campaign[active]" type="checkbox">
								Make this active
							</label>
						</fieldset>
					</td>
				</tr>
			</tbody>
		</table>
		<?php submit_button('Create Campaign'); ?>
    </form>
</div><!-- /.wrap -->
