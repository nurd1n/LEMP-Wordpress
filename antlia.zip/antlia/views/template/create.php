<div class="wrap">
	<h2>New Template</h2>

	<form name="template" id="template" action="" method="post">
		<?php wp_nonce_field( 'spp_template_editor' ); ?>
		<table class="form-table">
        	<tbody>
        		<tr>
        			<th style="padding: 10px 10px 10px 0px;" scope="row">Template type: </th>
        			<td style="padding: 5px 10px;">
        				<select name="tpltype" id="tpltype" class="postform" style="width:15em">
							<option value="papercut" >Papercut</option>
							<option value="stupidpie" >StupidPie</option>
						</select>
					</td>
				</tr>
				<tr>
					<th style="padding: 10px 10px 20px 0px;" scope="row">Filename: </th>
					<td style="padding: 5px 10px 15px 10px;">
						<input class="regular-text" name="template-filename" value="" type="text" required>.html</big>
					</td>
				</tr>
			</tbody>
		</table>
		<div>
			<textarea cols="70" rows="20" name="template-edit" id="template-edit" aria-describedby="template-edit-description"></textarea>
		</div>

		<?php submit_button('Save Template'); ?>
	</form>
	<br class="clear">
</div>
