<div class="wrap">
	<h2>Edit Template <a href="?page=spp-template-new" class="add-new-h2">New Template</a></h2>

	<div class="fileedit-sub">
		<div class="alignleft">
			<big>Editing <strong><?php echo $filename; ?></strong></big>
		</div>
		<div class="alignright">
			<form action="admin.php?page=spp-template-editor" method="post">
				<strong>
					<label for="plugin"><?php _e('Select template type to edit:'); ?> </label>
				</strong>
				<select name="tpltype" id="tpltype">
					<option value="papercut" <?php selected('papercut', $tpltype); ?>>Papercut</option>
					<option value="stupidpie" <?php selected('stupidpie', $tpltype); ?>>StupidPie</option>
				</select>
				<?php submit_button( __( 'Select' ), 'button', 'Submit', false ); ?>
			</form>
		</div>
		<br class="clear">
	</div>

	<div id="templateside">
		<h3>Template Files</h3>

		<ul>
			<?php foreach ($templates as $template): ?>
				<li>
					<a href="?page=spp-template-editor&amp;file=<?php echo basename($template); ?>&amp;template=<?php echo $tpltype; ?>">
						<?php if (basename($template) == $filename) echo '<span class="highlight">'; ?>
						<?php echo basename($template); ?>
						<?php if (basename($template) == $filename) echo '</span>'; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<form name="template" id="template" action="" method="post">
		<?php wp_nonce_field( 'spp_template_editor' ); ?>
		<input name="tpltype" id="tpltype" type="hidden" value="<?php echo $tpltype; ?>">
		<div>
			<textarea cols="70" rows="20" name="template-edit" id="template-edit" aria-describedby="template-edit-description"><?php echo stripslashes_deep($output); ?></textarea>
		</div>

		<?php
		if ( is_writeable($real_file) ) {
			submit_button();
		} else {
			echo "You need to make this file writable before you can save your changes.";
		}
		?>
	</form>
	<br class="clear">
</div>
