<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Edit Redirect</h2>

	<?php if(!empty($success)): ?>
	<div class="updated notice is-dismissible">
		<p><?php echo $success;?></p>
	</div>
	<?php endif; ?>

	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>

	<?php if(!empty($urlerror)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $urlerror;?></p>
	</div>
	<?php endif; ?>

	<?php if(!empty($rulerror)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $rulerror;?></p>
	</div>
	<?php endif; ?>

	<form action="" method="post">
        <?php wp_nonce_field( 'redirect_edit_redirect', 'redirect_edit_redirect' ); ?>
        <table class="form-table">
        	<tbody>
				<tr>
					<th scope="row">Target Url</th>
					<td>
						<input class="regular-text" name="rdr_edit_redirect[url]" value="<?php echo $redirect->url; ?>" type="text" placeholder="http://example.com" required>
						<p class="description">The url where you will redirect your traffic to. Add http/https</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Rule</th>
					<td>
						<input class="regular-text" name="rdr_edit_redirect[rule]" value="<?php echo $redirect->rule; ?>" type="text" placeholder="e.g.: {{ first_word }}/{{ term }}.html" required>
						<p class="description">The permalink structure of your target website. Available variable: {{ first_word }}, {{ term }}, {{ random }}.<br>
						e.g.: {{ random }}/{{ term }}.html
						</p>
					</td>
				</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
    </form>
</div><!-- /.wrap -->
