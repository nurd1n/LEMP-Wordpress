<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Redirects <a href="?page=redirector-new" class="add-new-h2">Add New</a></h2>
    <p>A listing of all redirects. Hover the row to show action link. Don't forget to enable it <a href="?page=stupidpie">here</a></p>
    <?php
    	$wp_list_table = new Redirect_List_Table();
		$wp_list_table->prepare_items();
		$wp_list_table->views();
		$wp_list_table->display();
    ?>
</div><!-- /.wrap -->
