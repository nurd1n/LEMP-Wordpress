<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Test Campaign</h2>
	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>
	<?php if (!empty($success)): ?>
	<div class="updated notice is-dismissible">
		<p><?php echo $success;?></p>
	</div>
	<?php endif; ?>

	<p>This will test your campaign and publish a real post.</p>
	<p>Do you want to continue?</p>
	<form action="" method="post">
        <?php wp_nonce_field( 'ppc_test_campaign', 'ppc_test_campaign' ); ?>
		<?php submit_button('Start Test'); ?>
    </form>
</div><!-- /.wrap -->
