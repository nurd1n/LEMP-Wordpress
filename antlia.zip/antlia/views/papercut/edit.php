<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Edit Campaign</h2>

	<?php if(!empty($success)): ?>
	<div class="updated notice is-dismissible">
		<p><?php echo $success;?></p>
	</div>
	<?php endif; ?>

	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>

	<form action="" method="post">
        <?php wp_nonce_field( 'papercut_edit_campaign', 'papercut_edit_campaign' ); ?>
        <table class="form-table">
        	<tbody>
				<tr>
					<th scope="row">Keyword</th>
					<td>
						<input class="regular-text" name="ppc_edit_campaign[keyword]" value="<?php echo $campaign->keyword; ?>" type="text" required>
						<p class="description">i.e Flower</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Size</th>
					<td>
						<select name="ppc_edit_campaign[imgsize]" id="ppc_edit_campaign[imgsize]" class="postform">
							<option value="wallpaper" <?php selected( $campaign->imgsize, 'wallpaper' ); ?>>Wallpaper</option>
							<option value="small" <?php selected( $campaign->imgsize, 'small' ); ?>>Small</option>
							<option value="medium" <?php selected( $campaign->imgsize, 'medium' ); ?>>Medium</option>
							<option value="large" <?php selected( $campaign->imgsize, 'large' ); ?>>Large</option>
						</select>
						<p class="description">Picture size</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Image Per Post</th>
					<td>
						<input class="regular-text" name="ppc_edit_campaign[post_per_run]" value="<?php echo $campaign->post_per_run; ?>" type="text" required>
						<p class="description">How many image per post will be posted when campaign is run?</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Category</th>
					<td>
						<?php echo wp_dropdown_categories("show_option_none=Select category&show_count=0&hide_empty=0&orderby=name&echo=0&name=ppc_edit_campaign[category_id]&selected=".$campaign->category_id); ?>
						<p class="description">Pick a category</p>
					</td>
				</tr>
        		<tr>
        			<th scope="row">Schedule</th>
        			<td>
        				<select name="ppc_edit_campaign[schedule]" id="ppc_edit_campaign[schedule]" class="postform">
							<option value="daily" <?php selected( $campaign->schedule, 'daily' ); ?>>Daily</option>
							<option value="hourly" <?php selected( $campaign->schedule, 'hourly' ); ?>>Hourly</option>
							<option value="twicedaily" <?php selected( $campaign->schedule, 'twicedaily' ); ?>>Twice a Day</option>
						</select>
						<p class="description">Schedule your post</p>
					</td>
				</tr>
        		<tr>
        			<th scope="row">Template</th>
        			<td>
        				<select name="ppc_edit_campaign[template]" id="ppc_edit_campaign[template]" class="postform">
                            <?php foreach($templates as $template):?>
                            <option value="<?php echo pathinfo($template, PATHINFO_FILENAME); ?>" <?php selected( $campaign->template, pathinfo($template, PATHINFO_FILENAME) ); ?>><?php echo basename($template); ?></option>
                            <?php endforeach;?>
                        </select>
						<p class="description">Choose a template for the post</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Active</th>
					<td>
						<fieldset>
							<label for="ppc_edit_campaign[active]">
								<input name="ppc_edit_campaign[active]" id="ppc_edit_campaign[active]" value="1" type="checkbox" <?php checked( $campaign->active, 1 ); ?>>
								Make this active
							</label>
						</fieldset>
					</td>
				</tr>
			</tbody>
		</table>
		<?php submit_button(); ?>
    </form>
</div><!-- /.wrap -->
