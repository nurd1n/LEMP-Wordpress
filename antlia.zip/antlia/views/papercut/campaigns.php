<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Campaigns <a href="?page=papercut-new" class="add-new-h2">Add New</a></h2>
    <p>A listing of all Papercut campaign. Hover the row to show action link</p>
    <?php
    	$wp_list_table = new Papercut_List_Table();
		$wp_list_table->prepare_items();
		$wp_list_table->views();
		$wp_list_table->display();
    ?>
</div><!-- /.wrap -->
