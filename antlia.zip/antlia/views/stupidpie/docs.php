<div class="wrap">

    <h2>StupidPie Documentation</h2>

    <h2 class="nav-tab-wrapper">
        <a href="?page=stupidpie-help&amp;tab=basic" class="nav-tab <?php echo $active_tab == 'basic' ? 'nav-tab-active' : ''; ?>">Basic Usage</a>
        <a href="?page=stupidpie-help&amp;tab=advanced" class="nav-tab <?php echo $active_tab == 'advanced' ? 'nav-tab-active' : ''; ?>">Advanced</a>
        <a href="?page=stupidpie-help&amp;tab=support" class="nav-tab <?php echo $active_tab == 'support' ? 'nav-tab-active' : ''; ?>">Support</a>
    </h2>

    <?php if( $active_tab == 'basic' ) { ?>
    <h3>Basic penggunaan StupidPie</h3>
    <ol>
        <li>Upload dan aktifkan pluginnya</li>
        <li>Isi keywords di menu StupidPie > Keywords</li>
        <li>
            Kopi paste kode
            <pre>&lt;?php echo spp(get_search_query()); ?&gt;</pre>
            taruh pada file search.php themes wordpress Anda. Masukkan kode diatas sebelum code
            <pre>if have_post();</pre>
        </li>
        <li>
            Kopi paste kode
            <pre>[spp_random_terms count=3]</pre>
            di sidebar wordpress, widget text.
        </li>
        <li>
            Secara default kode
            <pre>&lt;?php echo spp(get_search_query()); ?&gt;</pre>
            memanggil template default.html check pada folder (StupidPie\templates\default.html)
        </li>
    </ol>

    <?php } else if( $active_tab == 'advanced' ) { ?>
    <h3>Advanced</h3>
    <p>Secara default, spp memanggil parameter keyword, template dan hack:</p>
<pre>&lt;?php
    $keyword = get_search_query();
    $template = 'default';
    $hack = '';
    echo spp($keyword, $template, $hack);
    // bisa disingkat echo spp($keyword);
?&gt;</pre>

    <h4>Keyword</h4>
    <p>Keyword adalah satu-satunya parameter yang wajib diisi. Karena beda tempat beda cara dapatkan keywordnya. </p>
    <p>Sebagai contoh, di single.php keyword bisa didapatkan dengan cara:</p>
    <pre>$keyword = single_post_title( '', false );</pre>
    Kalau di halaman search.php:
    <pre>$keyword = get_search_query();</pre>

    <h4>Template</h4>
    <p>Template adalah tempat kita mengatur tampilan hasil ambil data. Lokasinya di folder StupidPie/templates. Kita bisa membuat template sendiri atau memodifikasi dari yang sudah ada. Template StupidPie memakai standar h2o template engine jadi kalau ada waktu untuk mempelajari syntax templatenya, bisa melihat dokumentasi lebih jelas untuk <a target="_blank" title="h2o template engine" href="http://www.h2o-template.org/">template h2o</a>.</p>
    <p>Untuk memanggil template, bisa dimasukkan ke parameter kedua. Misal:</p>
<pre>&lt;?php
    $keyword = get_search_query();
    $template = 'video';
    $hack = '';
    echo spp($keyword, $template, $hack);
?&gt;</pre>
    <p>Catatan: mulai versi 2.0 ke atas, cukup memasukkan nama template tanpa ekstensi html.</p>

    <h4>Hack</h4>
    <p>Hack adalah parameter ketiga yang jarang dipakai namun cukup keren. Dengan memanfaatkan hack, kita bisa membuat hampir semua jenis AGC. Misal, pdf, ppt, doc, amazon, ehow, dll. Fungsinya sendiri semacam filter. Sebagai contoh:</p>
<pre>&lt;?php
    $keyword = get_search_query();
    $template = 'wiki'; // semisal kita bikin template sendiri untuk wikipedia
    $hack = 'site:en.wikipedia.org'; // hack ini akan menampilkan konten HANYA dari en.wikipedia.org
    echo spp($keyword, $template, $hack);
?&gt;</pre>

    <p>Contoh lain untuk pdf search engine:</p>
<pre>&lt;?php
    $keyword = get_search_query();
    $template = 'pdf'; // semisal kita bikin template sendiri untuk pdf
    $hack = 'filetype:pdf'; // hack ini akan menampilkan konten HANYA yang berakhiran .pdf
    echo spp($keyword, $template, $hack);
?&gt;</pre>
    <?php } else if( $active_tab == 'support' ) { ?>
    <h3>Support</h3>
    <ul>
        <li>
            Untuk support dan tutorial bisa membuka website support dojo: <br/>
            <a href="http://dojo.support/" target="_blank">http://dojo.support/</a>
        </li>
        <li>
            Jika ada pertanyaan lain yang ingin ditanyakan bisa membuka forum kami: <br/>
            <a href="http://dojo.social/" target="_blank">http://dojo.social/</a>
        </li>
        <li>
            Untuk tips, trik dan lain lain: <br/>
            <a href="http://dojo.tips/" target="_blank">http://dojo.tips/</a>
        </li>
        <li>
            Join grup dojo: <br/>
            <a href="https://www.facebook.com/groups/ninjaplugins/" target="_blank">https://www.facebook.com/groups/ninjaplugins/</a>
        </li>
    </ul>
    <?php } ?>

</div><!-- /.wrap -->
