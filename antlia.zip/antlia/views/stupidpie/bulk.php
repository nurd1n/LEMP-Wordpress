<div class="wrap">
	<h2>Bulk Post Creator</h2>

	<?php if(!empty($updated)): ?>
	<div class="updated notice is-dismissible">
		<p><?php echo $updated;?></p>
	</div>
	<?php endif; ?>
	
	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>
	
	<?php if(!empty($errdate)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $errdate;?></p>
	</div>
	<?php endif; ?>
	
	<?php if(!empty($errintval)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $errintval;?></p>
	</div>
	<?php endif; ?>

	<form method="post">
		<?php wp_nonce_field('bulk-post-creator', 'bpc-submit'); ?>
		<table class="form-table">
        	<tbody>
				<tr>
					<th scope="row">Enter your list of titles, one per line</th>
					<td>
						<textarea cols="50" rows="10" class="regular-text" name="bulk_posts[titles]"></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row">Post Type</th>
					<td>
						<select name="bulk_posts[post_type]" id="bulk_post_type" class="postform">
							<option value="post" >Post</option>
							<option value="page" >Page</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">Post Status</th>
					<td>
						<select name="bulk_posts[post_status]" id="bulk_posts[post_status]" class="postform">
							<option value="draft" >Draft</option>
							<option value="publish" >Published</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">Category</th>
					<td>
						<?php echo wp_dropdown_categories("show_option_none=Select category&show_count=0&hide_empty=0&orderby=name&echo=0&name=bulk_posts[category_id]&id=bulkcat"); ?>
					</td>
				</tr>
				<tr>
					<th scope="row">Start Date</th>
					<td>
						<input id="bpc-datepicker" class="regular-text" name="bulk_posts[startdate]" value="" type="text">
					</td>
				</tr>
				<tr>
					<th scope="row">Interval</th>
					<td>
						<input class="regular-text" name="bulk_posts[interval_value]" value="" type="text" style="width:40px;">
						<select name="bulk_posts[interval_type]">
							<option value="days">Day</option>
							<option value="hours">Hour</option>
							<option value="minutes">Minute</option>
							<option value="seconds">Second</option>
						</select>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button("Publish Posts"); ?>
	</form>
</div>
