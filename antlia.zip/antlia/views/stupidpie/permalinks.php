<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">
 
    <h2>StupidPie Permalinks</h2>
    <p>A listing of available StupidPie permalinks. Hover the row to show action link</p>
    
    <?php
    	$wp_list_table = new StupidPie_List_Table();
		$wp_list_table->prepare_items();
		$wp_list_table->display();
    ?>
     
</div><!-- /.wrap -->
