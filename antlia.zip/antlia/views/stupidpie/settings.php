<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>StupidPie Options</h2>
    <?php settings_errors(); ?>

    <form action='options.php' method='post'>

        <?php
        settings_fields( 'stupidpie' );
        do_settings_sections( 'stupidpie' );
        submit_button();
        ?>

    </form>

</div><!-- /.wrap -->
