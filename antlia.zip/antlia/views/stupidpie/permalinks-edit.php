<!-- Create a header in the default WordPress 'wrap' container -->
<div class="wrap">

    <h2>Edit Permalinks</h2>

	<?php if(!empty($success)): ?>
	<div class="updated notice is-dismissible">
		<p><?php echo $success;?></p>
	</div>
	<?php endif; ?>

	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>

    <form action='' method='post'>
        <?php wp_nonce_field( 'spp_edit_permalinks', 'spp_edit' ); ?>
        <table class="form-table">
        	<tbody>
        		<tr>
        			<th scope="row">Name</th>
        			<td>
        				<input class="regular-text" name="spp_permalinks[name]" value="<?php echo $rule->name; ?>" type="text" required>
					</td>
				</tr>
				<tr>
					<th scope="row">Separator</th>
					<td>
						<input class="regular-text" name="spp_permalinks[separatorp]" value="<?php echo $rule->separatorp; ?>" type="text" required>
					</td>
				</tr>
				<tr>
					<th scope="row">Rule</th>
					<td>
						<input class="regular-text" name="spp_permalinks[rule]" value="<?php echo $rule->rule; ?>" type="text" required>
					</td>
				</tr>
				<tr>
					<th scope="row">Index</th>
					<td>
						<input class="regular-text" name="spp_permalinks[indexp]" value="<?php echo $rule->indexp; ?>" type="text" required>
					</td>
				</tr>
				<tr>
					<th scope="row">Permalink</th>
					<td>
						<input class="regular-text" name="spp_permalinks[permalink]" value="<?php echo $rule->permalink; ?>" type="text" required>
					</td>
				</tr>
			</tbody>
		</table>

        <?php submit_button(); ?>
    </form>

</div><!-- /.wrap -->
