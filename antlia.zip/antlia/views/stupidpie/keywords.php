<div class="wrap">
	<h2>Keywords.txt Editor (Term Inject)</h2>

	<?php if(!empty($error)): ?>
	<div class="error notice is-dismissible">
		<p><?php echo $error;?></p>
	</div>
	<?php endif; ?>

	<form method="post">
		<?php wp_nonce_field('stupidpie-keywords'); ?>
		<fieldset class="form-table">
			<label for="keywords">
				<textarea id="keywords" class="regular-text" cols="90" rows="20" name="keywords"><?php echo $output;?></textarea>
			</label>
		</fieldset>

		<?php submit_button(); ?>
	</form>
</div>
