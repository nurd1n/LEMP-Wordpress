jQuery(document).ready(function(){
	jQuery('#bpc-datepicker').datepicker();
});
