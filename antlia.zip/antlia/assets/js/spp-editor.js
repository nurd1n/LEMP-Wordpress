jQuery(document).ready(function() {
    'use strict';

    var newcontent = jQuery('#template-edit');
    newcontent.parent().attr('id', 'editor');
    newcontent.after('<div id="wp-ace-editor"></div>');

    var editor = ace.edit('wp-ace-editor');
    ace.require("ace/ext/language_tools");

    var textarea = document.getElementById('template-edit');
    textarea.style.display = 'none';
    editor.setValue(textarea.value);


    jQuery('#template').submit(function () {
        textarea.value = editor.getValue();
        return true;
    });

    jQuery(window).resize(function() { editor.resize(); });

    editor.resize();
    editor.focus();
    editor.selection.clearSelection();
    editor.selection.moveCursorFileStart();

    editor.setOptions({
        animatedScroll: true,
        autoScrollEditorIntoView: true,
        mode: 'ace/mode/twig',
        theme: 'ace/theme/eclipse',
        showInvisibles: false,
        showPrintMargin: false,
        showGutter: true,
        enableEmmet: true,
        enableBasicAutocompletion: true,
        enableSnippets: false,
        enableLiveAutocompletion: true
    });
})
