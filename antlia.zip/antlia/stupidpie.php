<?php 
/* Plugin Name: Antlia
Plugin URI: http://www.antlia.com
Description: antlia
Author: antlia
Version: 1.0.0
Author URI: http://www.antlia.com
*/

if ( ! defined( 'WPINC' ) ) {
	die;
}

define('SPP_VERSION', '2.0.8');
define('SPP_PATH',  trailingslashit(dirname(__FILE__)));
define('SPP_ASSETS_URL', plugins_url('assets', __FILE__));
define('SPP_BASENAME', plugin_basename(__FILE__));
define('AMEMBER_URL', 'http://members.dojo.cc');

if ( ! function_exists( 'exif_imagetype' ) ) {
    function exif_imagetype ( $filename ) {
        if ( ( list($width, $height, $type, $attr) = getimagesize( $filename ) ) !== false ) {
            return $type;
        }
		return false;
    }
}

if(!class_exists('Google_Client') && !class_exists('Google_Service_YouTube')){
	require_once SPP_PATH . 'lib/google/autoload.php';
}

if(!class_exists('H2o')){
    require_once SPP_PATH . 'lib/h2o/h2o.php';
}

if(!class_exists('phpQuery')){
    require_once SPP_PATH. 'lib/phpquery/phpQuery.php';
}

foreach (glob(SPP_PATH . "includes/h2o-tags/*.php") as $tag) {
    require_once $tag;
}

require_once SPP_PATH . 'includes/h2o-filters/all_filters.php';

function activate_stupidpie($networkwide) {
	require_once SPP_PATH . 'includes/stupidpie-activator.php';
	global $wpdb;

    if (function_exists('is_multisite') && is_multisite()) {
        if ($networkwide) {
            $old_blog = $wpdb->blogid;
            $blogids = $wpdb->get_col("SELECT blog_id FROM $wpdb->blogs");
            foreach ($blogids as $blog_id) {
                switch_to_blog($blog_id);
                $activator = new StupidPie_Activator();
				$activator->activate();

            }
            switch_to_blog($old_blog);
            return;
        }
    }
    $activator = new StupidPie_Activator();
	$activator->activate();

}

function deactivate_stupidpie($networkwide) {
	require_once SPP_PATH . 'includes/stupidpie-deactivator.php';
	global $wpdb;

    if (function_exists('is_multisite') && is_multisite()) {
        if ($networkwide) {
            $old_blog = $wpdb->blogid;
            $blogids = $wpdb->get_col("SELECT blog_id FROM {$wpdb->blogs}");
            foreach ($blogids as $blog_id) {
                switch_to_blog($blog_id);
                $deactivator = new StupidPie_Deactivator();
				$deactivator->deactivate();
            }
            switch_to_blog($old_blog);
            return;
        }
    }

	$deactivator = new StupidPie_Deactivator();
	$deactivator->deactivate();
}

register_deactivation_hook( __FILE__, 'deactivate_stupidpie' );

if (isset($_GET['action'], $_GET['plugin']) && 'deactivate' == $_GET['action'] && plugin_basename(__FILE__) == $_GET['plugin'])
	return;

register_activation_hook( __FILE__, 'activate_stupidpie' );


add_action( 'wpmu_new_blog', 'spp_new_blog', 10, 6);

function spp_new_blog($blog_id, $user_id, $domain, $path, $site_id, $meta ) {
    require_once SPP_PATH . 'includes/stupidpie-activator.php';
    global $wpdb;

    if (is_plugin_active_for_network(SPP_BASENAME)) {
        $old_blog = $wpdb->blogid;
        switch_to_blog($blog_id);
        $activator = new StupidPie_Activator();
		$activator->activate();
        switch_to_blog($old_blog);
    }
}



require SPP_PATH . 'includes/stupidpie-main.php';

include SPP_PATH . 'includes/stupidpie-loader.php';
