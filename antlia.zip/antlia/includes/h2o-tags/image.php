<?php
class Image_Tag extends H2o_Node {var $term, $cacheKey;
function __construct($argstring, $parser, $pos=0) {list($this->term, $this->hack) = explode(' ', "$argstring ");}
function is_single_image()
{return (stripos($_SERVER['REQUEST_URI'], 'images/') !== false);}
function have_images($feed) {return (empty($feed)) ? false : true;}
function fetch($context) {$spp_settings = get_option( 'spp_settings' );
$images = array();
$bad_urls = explode("\n", $spp_settings['spp_bad_urls']);
$bad_urls = array_map('trim', $bad_urls);
$term   = $context->resolve(':term');
if (empty($term)) {$images[] = array('mediaurl' => '', 'link' => '', 'title' => '', 'size' => '');
return $images;}
$query  = $term . " " . $context->resolve(':hack');
$url= "http://www.bing.com/images/search?q=" . urlencode($query) . "&qft=" . $spp_settings['spp_ppc_license'] . "&adlt=strict";
$doc= @file_get_contents($url);
phpQuery::newDocument($doc);
foreach(pq('div.item') as $item){$mediaurl = pq('a.thumb', $item)->attr('href');
$found = false;
foreach ($bad_urls as $bad_url) {if(stripos($mediaurl, $bad_url) !== false){$found = true;}}
if(!$found){$image['mediaurl']  = pq('a.thumb', $item)->attr('href');
$image['link']  = pq('a.tit', $item)->attr('href');
$image['title'] = pq('div.des', $item)->html();
$image['size']  = pq('div.fileInfo', $item)->html();
$images[] = $image;}}
if (empty($images)) {$images[] = array('mediaurl' => '', 'link' => '', 'title' => '', 'size' => '');}
return $images;}
function render($context, $stream) {$cache  = h2o_cache($context->options);
$feed   = $this->fetch($context);
$context->set("images", $feed);
$context->set("is_single_image", $this->is_single_image());
$context->set("have_images", $this->have_images($feed));}}
h2o::addTag('image');
