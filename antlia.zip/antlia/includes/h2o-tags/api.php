<?php
class Api_Tag extends H2o_Node {
    var $term, $cacheKey;

    function __construct($argstring, $parser, $pos=0) {
        list($this->term, $this->hack) = explode(' ', "$argstring ");
    }

    function have_results($feed) {
        return (empty($feed)) ? false : true;
    }

   function fetch($context) {
        $spp_settings = get_option( 'spp_settings' );

        $results = array();

        $bad_urls = explode("\n", $spp_settings['spp_bad_urls']);
        $bad_urls = array_map('trim', $bad_urls);

        $term = $context->resolve(':term');

        if (empty($term)) {
            $results[] = array('title' => '', 'link' => '', 'description' => '', 'pubDate' => '', 'slug' => '');
            return $results;
        }

        $query  = $term . " " . $context->resolve(':hack');
        $url    = "http://www.bing.com/search?q=" . urlencode($query) . "&format=rss";

        $feed   = @file_get_contents($url);
        $feed   = @simplexml_load_string($feed);

        $items  = @$feed->xpath('//channel/item');

        if (empty($items)) {

            $results[] = array('title' => '', 'link' => '', 'description' => '', 'pubDate' => '', 'slug' => '');

        } else {

            foreach ($items as $item) {
                $found = false;

                foreach ($bad_urls as $bad_url) {
                    if(stripos($item->link, $bad_url) !== false){
                        $found = true;
                    }
                }

                if(!$found){
                    $results[] = array('title' => $item->title, 'link' => $item->link, 'description' => $item->description, 'pubDate' => $item->pubDate, 'slug' => sanitize_title($item->title), 'filter_host' => host($item->link));
                }
            }

            if (empty($results)) {
                $results[] = array('title' => '', 'link' => '', 'description' => '', 'pubDate' => '', 'slug' => '');
            }
        }

        return $results;
    }

    function render($context, $stream) {
        $cache = h2o_cache($context->options);

        $feed  = $this->fetch($context);

        $context->set("api", $feed);
        $context->set("api_url", $url);
        $context->set("have_results", $this->have_results($feed));
    }

}
h2o::addTag('api');
