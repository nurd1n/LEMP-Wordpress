<?php
class Spp_Tag extends H2o_Node {var $args;
function __construct($argstring, $parser, $pos=0) {$this->args = explode(' ', $argstring);}
   function fetch($context) {$term = ($this->args[0][0] == ':') ? $context->resolve($this->args[0]) : $this->args[0];
$template = isset($this->args[1]) ? $this->args[1] : 'default';
$hack = isset($this->args[2]) ? $this->args[2] : '';
return spp2($term, $template, $hack);}
function render($context, $stream) {$feed  = $this->fetch($context);
$context->set("spp", $feed);}}
h2o::addTag('spp');
