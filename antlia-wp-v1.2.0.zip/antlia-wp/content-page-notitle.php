<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package WPBisnis
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php do_action( 'wpbisnis_entry_content_page_before' ); ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php wpbisnis_link_pages(); ?>
		<?php edit_post_link( __( 'Edit', 'antlia-wp' ), '<span class="edit-link">', '</span>' ); ?>
	</div>

	<?php do_action( 'wpbisnis_entry_content_page_after' ); ?>
	
</article>
