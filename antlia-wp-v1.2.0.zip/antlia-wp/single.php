<?php
/**
 * The template for displaying all single posts.
 *
 * @package WPBisnis
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'wpbisnis_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'wpbisnis_entry_'.get_post_type().'_before' ); ?>

			<?php get_template_part( 'content-single', get_post_type() ); ?>

			<?php do_action( 'wpbisnis_entry_'.get_post_type().'_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'wpbisnis_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
