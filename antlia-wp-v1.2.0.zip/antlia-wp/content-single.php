<?php
/**
 * @package WPBisnis
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">

		<?php do_action( 'wpbisnis_entry_header_'.get_post_type().'_before' ); ?>

		<?php if ( get_theme_mod( 'wpbisnis_post_image', '1' ) ) echo wpbisnis_get_image( array( 'alt' => get_the_title(), 'link' => 'image', 'fallback' => 'attachment' ) ); ?>

		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<div class="entry-meta">
			<?php echo wpbisnis_get_entry_meta(); ?>
		</div>

		<?php do_action( 'wpbisnis_entry_header_'.get_post_type().'_after' ); ?>

	</header>

	<?php do_action( 'wpbisnis_entry_content_'.get_post_type().'_before' ); ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php wpbisnis_link_pages(); ?>
	</div>

	<?php do_action( 'wpbisnis_entry_content_'.get_post_type().'_after' ); ?>

	<?php echo wpbisnis_get_the_term_list( get_the_ID(), 'post_tag', '<footer class="entry-footer"><div class="entry-meta"><span>'.__( 'Tags:', 'antlia-wp' ).'</span> ', ' ', '</div></footer>' ); ?>

</article>
