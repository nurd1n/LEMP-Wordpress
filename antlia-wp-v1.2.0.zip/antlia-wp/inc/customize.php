<?php 

function wpbisnis_sanitize_checkbox( $checked ) {
	return ( ( isset( $checked ) && true == $checked ) ? true : false );
}

function wpbisnis_sanitize_css( $css ) {
	return wp_strip_all_tags( $css );
}

function wpbisnis_sanitize_dropdown_pages( $page_id, $setting ) {
	$page_id = absint( $page_id );
	return ( 'publish' == get_post_status( $page_id ) ? $page_id : $setting->default );
}

function wpbisnis_sanitize_email( $email, $setting ) {
	$email = sanitize_email( $email );
	return ( ! null( $email ) ? $email : $setting->default );
}

function wpbisnis_sanitize_hex_color( $hex_color, $setting ) {
	$hex_color = sanitize_hex_color( $hex_color );
	return ( ! null( $hex_color ) ? $hex_color : $setting->default );
}

function wpbisnis_sanitize_html( $html ) {
	return wp_filter_post_kses( $html );
}

function wpbisnis_sanitize_image( $image, $setting ) {
    $mimes = array(
        'jpg|jpeg|jpe' => 'image/jpeg',
        'gif'          => 'image/gif',
        'png'          => 'image/png',
        'bmp'          => 'image/bmp',
        'tif|tiff'     => 'image/tiff',
        'ico'          => 'image/x-icon'
    );
    $file = wp_check_filetype( $image, $mimes );
    return ( $file['ext'] ? $image : $setting->default );
}

function wpbisnis_sanitize_nohtml( $nohtml ) {
	return wp_filter_nohtml_kses( $nohtml );
}

function wpbisnis_sanitize_number_absint( $number, $setting ) {
	$number = absint( $number );
	return ( $number ? $number : $setting->default );
}

function wpbisnis_sanitize_number_range( $number, $setting ) {
	$number = absint( $number );
	$atts = $setting->manager->get_control( $setting->id )->input_attrs;
	$min = ( isset( $atts['min'] ) ? $atts['min'] : $number );
	$max = ( isset( $atts['max'] ) ? $atts['max'] : $number );
	$step = ( isset( $atts['step'] ) ? $atts['step'] : 1 );
	return ( $min <= $number && $number <= $max && is_int( $number / $step ) ? $number : $setting->default );
}

function wpbisnis_sanitize_select( $input, $setting ) {
	$input = sanitize_key( $input );
	$choices = $setting->manager->get_control( $setting->id )->choices;
	return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
}

function wpbisnis_sanitize_url( $url ) {
	return esc_url_raw( $url );
}

function wpbisnis_sanitize_ads( $html ) {
	// if ( current_user_can('unfiltered_html') )
	// 	return $html;
	// else
	// 	return wp_filter_post_kses( $html );
	return $html;
}

add_action( 'customize_register', 'wpbisnis_customize_register', 10 );
/**
 * This function incorporates code from the Kirki Customizer Framework.
 * 
 * The Kirki Customizer Framework, Copyright Aristeides Stathopoulos (@aristath),
 * is licensed under the terms of the GNU GPL, Version 2 (or later).
 * 
 * @link http://kirki.org
 */
function wpbisnis_customize_register( $wp_customize ){

	if ( ! isset( $wp_customize ) ) {
		return;
	}

	class WPBisnis_Customize_Slider_Control extends WP_Customize_Control {

		public $type = 'slider';

		public function enqueue() {

			wp_enqueue_script( 'jquery-ui' );
			wp_enqueue_script( 'jquery-ui-slider' );

		}

		public function render_content() { ?>
			<label>

				<span class="customize-control-title">
					<?php echo esc_attr( $this->label ); ?>
					<?php if ( ! empty( $this->description ) ) : ?>
						<?php // The description has already been sanitized in the Fields class, no need to re-sanitize it. ?>
						<span class="description customize-control-description"><?php echo $this->description; ?></span>
					<?php endif; ?>
				</span>

				<input type="text" class="" id="input_<?php echo $this->id; ?>" value="<?php echo esc_attr( $this->value() ); ?>" <?php $this->link(); ?>/>

			</label>

			<div id="slider_<?php echo $this->id; ?>" class="ss-slider"></div>
			<script>
			jQuery(document).ready(function($) {
				$( '[id="slider_<?php echo $this->id; ?>"]' ).slider({
						value : <?php echo esc_attr( $this->value() ); ?>,
						min   : <?php echo $this->choices['min']; ?>,
						max   : <?php echo $this->choices['max']; ?>,
						step  : <?php echo $this->choices['step']; ?>,
						slide : function( event, ui ) { $( '[id="input_<?php echo $this->id; ?>"]' ).val(ui.value).keyup(); }
				});
				$( '[id="input_<?php echo $this->id; ?>"]' ).val( $( '[id="slider_<?php echo $this->id; ?>"]' ).slider( "value" ) );

				$( '[id="input_<?php echo $this->id; ?>"]' ).change(function() {
					$( '[id="slider_<?php echo $this->id; ?>"]' ).slider({
						value : $( this ).val()
					});
				});

			});
			</script>
			<?php

		}
	}
	
	class WPBisnis_Customize_Radio_Buttonset_Control extends WP_Customize_Control {

		public $type = 'radio-buttonset';

		public function enqueue() {
			wp_enqueue_script( 'jquery-ui-button' );
		}

		public function render_content() {

			if ( empty( $this->choices ) ) {
				return;
			}

			$name = '_customize-radio-'.$this->id;

			?>
			<span class="customize-control-title">
				<?php echo esc_attr( $this->label ); ?>
				<?php if ( ! empty( $this->description ) ) : ?>
					<?php // The description has already been sanitized in the Fields class, no need to re-sanitize it. ?>
					<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
			</span>

			<div id="input_<?php echo $this->id; ?>" class="buttonset">
				<?php foreach ( $this->choices as $value => $label ) : ?>
					<input type="radio" value="<?php echo esc_attr( $value ); ?>" name="<?php echo esc_attr( $name ); ?>" id="<?php echo $this->id.esc_attr( $value ); ?>" <?php $this->link(); checked( $this->value(), $value ); ?>>
						<label for="<?php echo $this->id.esc_attr( $value ); ?>">
							<?php echo esc_html( $label ); ?>
						</label>
					</input>
				<?php endforeach; ?>
			</div>
			<script>jQuery(document).ready(function($) { $( '[id="input_<?php echo $this->id; ?>"]' ).buttonset(); });</script>
			<?php
		}

	}

	class WPBisnis_Customize_Radio_Image_Control extends WP_Customize_Control {

		public $type = 'radio-image';

		public function enqueue() {
			wp_enqueue_script( 'jquery-ui-button' );
		}

		public function render_content() {

			if ( empty( $this->choices ) ) {
				return;
			}

			$name = '_customize-radio-'.$this->id;

			?>
			<span class="customize-control-title">
				<?php echo esc_attr( $this->label ); ?>
				<?php if ( ! empty( $this->description ) ) : ?>
					<?php // The description has already been sanitized in the Fields class, no need to re-sanitize it. ?>
					<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
			</span>
			<div id="input_<?php echo $this->id; ?>" class="image">
				<?php foreach ( $this->choices as $value => $label ) : ?>
					<input class="image-select" type="radio" value="<?php echo esc_attr( $value ); ?>" name="<?php echo esc_attr( $name ); ?>" id="<?php echo $this->id.esc_attr( $value ); ?>" <?php $this->link(); checked( $this->value(), $value ); ?>>
						<label for="<?php echo $this->id.esc_attr( $value ); ?>">
							<img src="<?php echo esc_html( $label ); ?>">
						</label>
					</input>
				<?php endforeach; ?>
			</div>
			<script>jQuery(document).ready(function($) { $( '[id="input_<?php echo $this->id; ?>"]' ).buttonset(); });</script>
			<?php
		}

	}

	class WPBisnis_Customize_Dropdown_Categories_Control extends WP_Customize_Control {

		public $type = 'dropdown-categories';

		public function render_content() {
			?>
			<label>
			<?php if ( ! empty( $this->label ) ) : ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<?php endif;
			if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo $this->description; ?></span>
			<?php endif; ?>

			<?php $dropdown = wp_dropdown_categories(
				array(
					'name'              => '_customize-dropdown-categories-' . $this->id,
					'echo'              => 0,
					'show_option_none'  => __( '&mdash; Select &mdash;', 'antlia-wp' ),
					'option_none_value' => '0',
					'selected'          => $this->value(),
				)
			);

			// Hackily add in the data link parameter.
			$dropdown = str_replace( '<select', '<select ' . $this->get_link(), $dropdown );
			echo $dropdown;
			?>
			</label>
			<?php
		}

	}

	class WPBisnis_Customize_Custom_CSS_Control extends WP_Customize_Control {

		public $type = 'custom-css';

		public function render_content() {
			?>
			<label>
				<?php if ( ! empty( $this->label ) ) : ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif;
				if ( ! empty( $this->description ) ) : ?>
					<span class="description customize-control-description"><?php echo $this->description; ?></span>
				<?php endif; ?>
				<textarea rows="20" <?php $this->link(); ?> style="width:100%;resize:vertical;">
					<?php echo esc_textarea( $this->value() ); ?>
				</textarea>
			</label>
			<?php
		}

	}

	$fields = apply_filters( 'wpbisnis_customize_controls', array() );

	if ( ! empty( $fields ) ) {
		foreach ( $fields as $field ) {

			$defaults = array(
				'setting'				=> '',
				'section'				=> '',
				'type'					=> '',
				'priority'				=> 10,
				'label'					=> '',
				'description'			=> '',
				'choices'				=> array(),
				'input_attrs'			=> array(),
				'default'				=> '',
				'capability'			=> 'edit_theme_options',
				'sanitize_callback'		=> '',
			);

			$field = wp_parse_args( $field, $defaults );

			if ( $field['setting'] && $field['section'] && $field['type'] ) {
				$wp_customize->add_setting(
					$field['setting'],
					array(
						'default'			=> $field['default'],
						'type'				=> 'theme_mod',
						'capability'		=> $field['capability'],
						'sanitize_callback'	=> $field['sanitize_callback'],
					)
				);
				if ( in_array( $field['type'], array( 'checkbox', 'dropdown-pages', 'text', 'textarea', 'email', 'number', 'tel', 'url' ) ) ) {
					$wp_customize->add_control(
						$field['setting'],
						array(
							'settings'		=> $field['setting'],
							'section'		=> $field['section'],
							'type'			=> $field['type'],
							'priority'		=> $field['priority'],
							'label'			=> $field['label'],
							'description'	=> $field['description'],
						)
					);
				}
				elseif ( in_array( $field['type'], array( 'radio', 'select' ) ) && !empty( $field['choices'] ) ) {
					$wp_customize->add_control(
						$field['setting'],
						array(
							'settings'		=> $field['setting'],
							'section'		=> $field['section'],
							'type'			=> $field['type'],
							'priority'		=> $field['priority'],
							'label'			=> $field['label'],
							'description'	=> $field['description'],
							'choices'		=> $field['choices'],
						)
					);
				}
				elseif ( 'color' == $field['type'] ) {
					$wp_customize->add_control(
						new WP_Customize_Color_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
							)
						)
					);
				}
				elseif ( 'image' == $field['type'] ) {
					$wp_customize->add_control(
						new WP_Customize_Image_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
							)
						)
					);
				}
				elseif ( 'slider' == $field['type'] ) {
					$wp_customize->add_control(
						new WPBisnis_Customize_Slider_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
								'choices'		=> $field['choices'],
							)
						)
					);
				}
				elseif ( 'radio-buttonset' == $field['type'] ) {
					$wp_customize->add_control(
						new WPBisnis_Customize_Radio_Buttonset_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
								'choices'		=> $field['choices'],
							)
						)
					);
				}
				elseif ( 'radio-image' == $field['type'] ) {
					$wp_customize->add_control(
						new WPBisnis_Customize_Radio_Image_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
								'choices'		=> $field['choices'],
							)
						)
					);
				}
				elseif ( 'dropdown-categories' == $field['type'] ) {
					$wp_customize->add_control(
						new WPBisnis_Customize_Dropdown_Categories_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
								'choices'		=> $field['choices'],
							)
						)
					);
				}
				elseif ( 'custom-css' == $field['type'] ) {
					$wp_customize->add_control(
						new WPBisnis_Customize_Custom_CSS_Control( 
							$wp_customize,
							$field['setting'],
							array(
								'settings'		=> $field['setting'],
								'section'		=> $field['section'],
								'priority'		=> $field['priority'],
								'label'			=> $field['label'],
								'description'	=> $field['description'],
								'choices'		=> $field['choices'],
							)
						)
					);
				}
			}
		}
	}
}

add_action( 'customize_controls_print_styles', 'wpbisnis_customize_controls_print_styles' );
/**
 * This function incorporates CSS from the Kirki Customizer Framework.
 * 
 * The Kirki Customizer Framework, Copyright Aristeides Stathopoulos (@aristath),
 * is licensed under the terms of the GNU GPL, Version 2 (or later).
 * 
 * @link http://kirki.org
 */
function wpbisnis_customize_controls_print_styles() { 
?>
<style>
.customize-control-slider input[type="text"] {
	background: none;
	border: none;
	text-align: center;
	padding: 0;
	margin: 0;
	font-size: 12px;
	box-shadow: none;
	color: #333;
	width: 100%;
}
.customize-control-slider .ui-slider {
	position: relative;
	text-align: left;
	height: 7px;
	border-radius: 3px;
	background: #f7f7f7;
	border: 1px solid #ccc;
	box-shadow: 0 1px 0 #ccc;
	margin-top: 10px;
	margin-bottom: 20px; 
}
.customize-control-slider .ui-slider .ui-slider-handle {
	position: absolute;
	z-index: 2;
	width: 15px;
	height: 15px;
	top: -5px;
	border-radius: 50%;
	cursor: default;
	-ms-touch-action: none;
	touch-action: none;
	background: #555;
	border: 1px solid #555;
	margin-left: -8px;
}
.customize-control-slider .ui-slider .ui-slider-range {
	position: absolute;
	z-index: 1;
	font-size: 0.7em;
	display: block;
	border: 0;
	background-position: 0 0; 
}
.customize-control-radio-buttonset label {
	padding: 5px 10px;
	background: #f7f7f7;
	border: 1px solid #ccc;
	border-left: 0;
	line-height: 35px;
	box-shadow: 0 1px 0 #ccc;
}
.customize-control-radio-buttonset label.ui-state-active {
	background: #555;
	color: #fff;
}
.customize-control-radio-buttonset label.ui-corner-left {
	border-radius: 3px 0 0 3px;
	border-left: 1px solid #ccc;
}
.customize-control-radio-buttonset label.ui-corner-right {
	border-radius: 0 3px 3px 0;
}
.customize-control-radio-image .image.ui-buttonset input[type=radio] {
	height: auto; 
}
.customize-control-radio-image .image.ui-buttonset label {
	border: 1px solid transparent;
	display: inline-block;
	margin-right: 5px;
	margin-bottom: 5px; 
}
.customize-control-radio-image .image.ui-buttonset label.ui-state-active {
	background: none;
	border-color: #333; 
}
</style>
<?php
}
