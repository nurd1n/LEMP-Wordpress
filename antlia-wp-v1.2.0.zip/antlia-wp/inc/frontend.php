<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package WPBisnis
 */

function wpbisnis_get_nav_menu( $args = array() ) {

	if ( !isset( $args['theme_location'] ) )
		return;

	$transient_active = apply_filters( "wpbisnis_transient", false );

	$args['echo'] = false;

	$transient_name = 'wpbisnis_menu_'.$args['theme_location'];
	
	$html = $transient_active ? get_transient( $transient_name  ) : false;

	if( false === $html ) {
		if ( has_nav_menu( $args['theme_location'] ) ) {
			$html = wp_nav_menu( $args );
			if ( $transient_active ) {
				set_transient( $transient_name, $html, DAY_IN_SECONDS );
			}
		}
	}

	return $html;
}

add_action( 'excerpt_more', 'wpbisnis_excerpt_more' );
function wpbisnis_excerpt_more( $html ) {
	return ' &hellip;';
}

function wpbisnis_get_paginate_links( $query = '' ) { 

	if ( !$query ) {
		global $wp_query;
		$query = $wp_query;
	}

	if( isset( $query->max_num_pages ) && $query->max_num_pages <= 1 ) 
		return;

	$big = 999999999; // need an unlikely integer
	$links = paginate_links( array(
		'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages,
		'type' => 'list',
		'prev_next' => true,
		'prev_text' => __('&laquo; Previous', 'antlia-wp'),
		'next_text' => __('Next &raquo;', 'antlia-wp'),
	) );

	if ( $links )
		$links = '<nav class="navigation posts-navigation">'.$links.'</nav>';

	return apply_filters( "wpbisnis_posts_navigation", $links );
}

function wpbisnis_get_the_post_navigation() {
	
	$links = get_the_post_navigation();

	$links = str_replace( ' role="navigation"', '', $links );

	return apply_filters( "wpbisnis_post_navigation", $links );
}


function wpbisnis_get_entry_meta() {

	$meta = '';

	$time_string = '<span class="time-link"><time class="entry-date published updated" datetime="%1$s">%2$s</time></span>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<span class="time-link"><time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time></span>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$meta .= $time_string;

	if ( get_theme_mod( 'wpbisnis_post_comment' ) ) {
		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			$meta .= '<span class="meta-sep">&middot;</span>';
			$meta .= '<span class="comments-link">';
			ob_start();
			comments_popup_link( __( 'Leave a comment', 'antlia-wp' ), __( '1 Comment', 'antlia-wp' ), __( '% Comments', 'antlia-wp' ) );
			$meta .= ob_get_clean();
			$meta .= '</span>';
		}
	}

	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( __( ', ', 'antlia-wp' ) );
		if ( $categories_list ) {
			$categories_list = str_replace( 'rel="category tag"', '', $categories_list );
			$meta .= '<span class="meta-sep">&middot;</span>';
			$meta .= '<span class="cat-links">' . $categories_list . '</span>';
		}
	}

	ob_start();
	edit_post_link( __( 'Edit', 'antlia-wp' ), '<span class="meta-sep">&middot;</span><span class="edit-link">', '</span>' );
	$meta .= ob_get_clean();

	return apply_filters( "wpbisnis_entry_meta", $meta );
}

function wpbisnis_get_the_term_list( $id, $taxonomy = 'post_tag', $before = '', $sep = '', $after = '' ) {
	$terms = get_the_terms( $id, $taxonomy );

	if ( is_wp_error( $terms ) )
		return $terms;

	if ( empty( $terms ) )
		return false;

	$links = array();

	foreach ( $terms as $term ) {
		$link = get_term_link( $term, $taxonomy );
		if ( is_wp_error( $link ) ) {
			return $link;
		}
		$links[] = '<a href="' . esc_url( $link ) . '">#' . $term->name . '</a>';
	}

	$term_links = apply_filters( "term_links-$taxonomy", $links );

	return $before . join( $sep, $term_links ) . $after;
}

if ( ! function_exists( 'wpbisnis_link_pages' ) ) :
function wpbisnis_link_pages() {
	add_filter( 'wp_link_pages_link', 'wpbisnis_link_pages_link' );
	wp_link_pages( array(
		'before' => '<nav class="page-links"><ul><li class="label">' . esc_html__( 'Pages:', 'antlia-wp' ) . '</li>',
		'after'  => '</ul></nav>',
	) );
	remove_filter( 'wp_link_pages_link', 'wpbisnis_link_pages_link' );
}
endif;

if ( ! function_exists( 'wpbisnis_link_pages_link' ) ) :
function wpbisnis_link_pages_link( $link ) {
	if ( strpos($link, '</a>') === false ) 
		return '<li class="current"><span>' . $link . '</span></li>';
	else
		return '<li>' . $link . '</li>';
}
endif;

function wpbisnis_get_related_posts( $post_id ) {
	if ( !$post_id )
		return;

	global $wpdb, $post;

	$transient_active = apply_filters( "wpbisnis_transient", false );

	$transient_name = 'wpbisnis_related_' . $post_id;

	$related_posts  = $transient_active ? get_transient( $transient_name ) : false;

	// We want to query related posts if they are not cached
	if ( false === $related_posts ) {

		$number = 10;

		// Related products are found from category and tag
		$tags_array = array(0);
		$cats_array = array(0);
		$tags = '';
		$cats = '';

		// Get tags
		$terms = wp_get_post_terms($post_id, 'post_tag');
		foreach ($terms as $term) {
			$tags_array[] = $term->term_id;
		}
		$tags = implode(',', $tags_array);

		$terms = wp_get_post_terms($post_id, 'category');
		foreach ($terms as $term) {
			$cats_array[] = $term->term_id;
		}
		$cats = implode(',', $cats_array);

		$q = "
			SELECT p.ID
			FROM $wpdb->term_taxonomy AS tt, $wpdb->term_relationships AS tr, $wpdb->posts AS p
			WHERE 
				p.ID != $post_id
				AND p.post_status = 'publish'
				AND p.post_type = 'post'
				AND
				(
					(
						tt.taxonomy ='category'
						AND tt.term_taxonomy_id = tr.term_taxonomy_id
						AND tr.object_id  = p.ID
						AND tt.term_id IN ($cats)
					)
					OR 
					(
						tt.taxonomy ='post_tag'
						AND tt.term_taxonomy_id = tr.term_taxonomy_id
						AND tr.object_id  = p.ID
						AND tt.term_id IN ($tags)
					)
				)
			GROUP BY tr.object_id
			ORDER BY RAND()
			LIMIT $number;";

		$related_posts = $wpdb->get_col($q);

		if ( $transient_active ) {
			set_transient( $transient_name, $related_posts, DAY_IN_SECONDS );
		}
	}

	return $related_posts;
}

add_action( 'init', 'wpbisnis_page_search', 99 );
function wpbisnis_page_search() {
	global $wp_post_types;
	if ( post_type_exists( 'page' ) ) {
		$wp_post_types['page']->exclude_from_search = true;
	}
}

add_filter('wp_nav_menu_items','wpbisnis_header_searchform', 10, 2);
function wpbisnis_header_searchform($items, $args) {
	if( get_theme_mod('wpbisnis_menu_search', '1') && $args->theme_location == 'header' ) {
		$form = get_search_form( false );
		$form = str_replace( ' role="search"', '', $form );
		$items .= '<li class="header-searchform">' . $form . '</li>';
	}
	return $items;
}

add_filter('prepend_attachment', 'wpbisnis_prepend_image');
function wpbisnis_prepend_image( $p ) {
	$post = get_post();

	if ( wp_attachment_is( 'image', $post ) ) {
		$p = '<p class="attachment">';
		$p .= wp_get_attachment_link(0, 'post-thumbnail', false);
		$p .= '</p>';
	}

	return $p;
}

function wpbisnis_get_image( $args = array() ) {
	$defaults = apply_filters( 'wpbisnis_get_image_defaults', array(
		'post_id' => null,
		'image_id' => null,
		'size' => 'post-thumbnail',
		'fallback' => null,
		'class' => 'entry-image',
		'alt' => null,
		'link' => false,
		'before' => '',
		'after' => '',
	) );

	$args = wp_parse_args( $args, $defaults );

	extract( $args );

	global $post;

	$html = '';
	$link_to = '';
	$link_class = $class ? $class.'-link' : '';

	$attr = array( 'class' => $class );
	if ( $alt ) {
		$attr['alt'] = $alt;
	}

	if ( !$post_id && $image_id ) {
		$html = wp_get_attachment_image( $image_id, $size, false, $attr );
	}
	else {
		if ( !$post_id ) {
			$post_id = $post->ID;
		}
		if ( has_post_thumbnail( $post_id ) ) {
			$html = get_the_post_thumbnail( $post_id, $size, $attr );
		}
		if ( $link == 'attachment' ) {
			$image_id = get_post_thumbnail_id();
		}
	}

	if ( !$html && get_post_type( $post_id ) == 'post' && $fallback == 'attachment' ) {
		$image_ids = array_keys(
			get_children(
				array(
					'post_parent'    => $post->ID,
					'post_type'	     => 'attachment',
					'post_mime_type' => 'image',
					'orderby'        => 'menu_order',
					'order'	         => 'ASC',
				)
			)
		);
		if ( isset( $image_ids[0] ) ) {
			$image_id = $image_ids[0];
		}

		if ( $image_id ) {
			$html = wp_get_attachment_image( $image_id, $size, false, $attr );

			/* auto featured image */
			// if ( get_post_type() == 'post' ) {
			// 	set_post_thumbnail( $post, $id );
			// }
		}
	}

	if ( $html ) {

		if ( $link ) {
			if ( $link == 'post' ) {
				$link_to = $post_id ? get_permalink( $post_id ) : get_permalink();
			}
			elseif ( $link == 'attachment' ) {
				$link_to = $image_id ? get_permalink( $image_id ) : get_permalink();
			}
			elseif ( $link == 'image' ) {
				if ( $image_id ) {
					$link_to = wp_get_attachment_image_url( $image_id, 'full' );
				}
				elseif ( $post_id ) {
					$link_to = get_the_post_thumbnail_url( $post_id, 'full' );
				}
			}
			else {
				$link_to = esc_url( $link );
			}
		}

		if ( $link_to ) {
			$html = sprintf( '%s<a href="%s" class="%s">%s</a>%s', $before, $link_to, $link_class, $html, $after );
		}
		else {
			$html = sprintf( '%s %s %s', $before, $html, $after );
		}

	}

	return $html;
}

add_filter( 'get_the_archive_title', 'wpbisnis_get_the_archive_title' );
function wpbisnis_get_the_archive_title( $output ) {
	$output = str_replace( 'Category: ', '', $output );
	return $output;
}

add_action( 'wp_head', 'wpbisnis_output_style', 25 );
function wpbisnis_output_style() {
	$style = apply_filters( "wpbisnis_style", '' );
	if ( $style ) {
		echo '<style type="text/css">'."\n".$style."\n".'</style>'."\n";
	}
}

add_filter( 'wpbisnis_style', 'wpbisnis_style_header_image' );
function wpbisnis_style_header_image( $style ) {
	$placement = get_theme_mod( 'wpbisnis_header_placement' );
	if ( $placement && 'background' != $placement ) 
		return $style;
	$image = get_header_image();
	if ( $image ) {
		$image = preg_replace( '#^(://|[^/])+#', '', $image );
		$style .= '.site-branding{background-image:url('.esc_url($image).')}';
	}
	return $style;
}

add_filter( 'wpbisnis_style', 'wpbisnis_style_customize' );
function wpbisnis_style_customize( $style ) {
	$fields = apply_filters( 'wpbisnis_customize_controls', array() );
	if ( ! empty( $fields ) ) {
		foreach ( $fields as $field ) {
			$defaults = array(
				'setting'				=> '',
				'type'					=> '',
				'default'				=> '',
				'style'					=> '',
			);
			$field = wp_parse_args( $field, $defaults );
			if ( in_array( $field['type'], array( 'color', 'slider' ) ) && $field['setting'] && !empty( $field['style'] ) ) {
				if ( $value = get_theme_mod( $field['setting'], $field['default'] ) ) {
					$style .= str_replace( '[value]', $value, $field['style'] );
				}
			}
			elseif ( in_array( $field['type'], array( 'radio', 'select', 'radio-buttonset', 'radio-image' ) ) && $field['setting'] && !empty( $field['style'] ) ) {
				if ( $value = get_theme_mod( $field['setting'], $field['default'] ) ) {
					if ( isset( $field['style'][$value] ) ) {
						$style .= $field['style'][$value];
					}
				}
			}
			elseif ( in_array( $field['type'], array( 'custom-css' ) ) && $field['setting'] ) {
				if ( $value = get_theme_mod( $field['setting'], $field['default'] ) ) {
					if ( function_exists( 'wpbisnis_minify_css' ) ) {
						$style .= wpbisnis_minify_css( $value );
					}
					else {
						$style .= $value;
					}
				}
			}
		}
	}
	return $style;
}

add_action( 'wp_footer', 'wpbisnis_output_script', 99 );
function wpbisnis_output_script() {
	$script = apply_filters( "wpbisnis_script", '' );
	if ( $script ) {
		if ( function_exists( 'wpbisnis_minify_js' ) ) {
			$script = wpbisnis_minify_js( $script );
		}
		echo '<script type="text/javascript">'."\n".$script."\n".'</script>'."\n";
	}
}

add_action( 'wp_head', 'wpbisnis_script_header', 99 );
function wpbisnis_script_header() {
	if ( !get_theme_mod('wpbisnis_script_header') )
		return;

	echo get_theme_mod('wpbisnis_script_header');
}

add_action( 'wp_footer', 'wpbisnis_script_footer', 99 );
function wpbisnis_script_footer() {
	if ( !get_theme_mod('wpbisnis_script_footer') )
		return;
	
	echo get_theme_mod('wpbisnis_script_footer');
}

function wpbisnis_get_contact_form() {
	$args = array(
		'email' => get_bloginfo('admin_email'),
		'subject' => __( 'Message via the contact form', 'antlia-wp' ),
		'sendcopy' => 'yes',
		'question' => '',
		'answer' => '',
		'button_text' => __( 'Submit', 'antlia-wp' )
	);
	extract( $args );
	if( trim($email) == '' )
		$email = get_bloginfo('admin_email');
	
	$html = '';
	$error_messages = array();
	$notification = false;
	$email_sent = false;
	if ( ( count( $_POST ) > 3 ) && isset( $_POST['submitted'] ) ) {
		if ( isset ( $_POST['checking'] ) && $_POST['checking'] != '' )
			$error_messages['checking'] = 1;
		if ( isset ( $_POST['contact-name'] ) && $_POST['contact-name'] != '' )
			$message_name = $_POST['contact-name'];
		else 
			$error_messages['contact-name'] = __( 'Please enter your name', 'antlia-wp' );
		if ( isset ( $_POST['contact-email'] ) && $_POST['contact-email'] != '' && is_email( $_POST['contact-email'] ) )
			$message_email = $_POST['contact-email'];
		else 
			$error_messages['contact-email'] = __( 'Please enter your email address (and please make sure it\'s valid)', 'antlia-wp' );
		if ( isset ( $_POST['contact-message'] ) && $_POST['contact-message'] != '' )
			$message_body = $_POST['contact-message'] . "\n\r\n\r";
		else 
			$error_messages['contact-message'] = __( 'Please enter your message', 'antlia-wp' );
		if ( $question && $answer ) {
			if ( isset ( $_POST['contact-quiz'] ) && $_POST['contact-quiz'] != '' ) {
				$message_quiz = $_POST['contact-quiz']; 
				if ( esc_attr( $message_quiz ) != esc_attr( $answer ) )
					$error_messages['contact-quiz'] = __( 'Your answer was wrong!', 'antlia-wp' );
			}
			else {
				$error_messages['contact-quiz'] = __( 'Please enter your answer', 'antlia-wp' );
			}
		}
		if ( count( $error_messages ) ) {
			$notification = '<p class="contact-error">' . __( 'There were one or more errors while submitting the form.', 'antlia-wp' ) . '</p>';
		} 
		else {
			$ipaddress = '';
			if (isset($_SERVER['HTTP_CLIENT_IP']) && $_SERVER['HTTP_CLIENT_IP'])
				$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
			else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'])
				$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
			else if(isset($_SERVER['HTTP_X_FORWARDED']) && $_SERVER['HTTP_X_FORWARDED'])
				$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
			else if(isset($_SERVER['HTTP_FORWARDED_FOR']) && $_SERVER['HTTP_FORWARDED_FOR'])
				$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
			else if(isset($_SERVER['HTTP_FORWARDED']) && $_SERVER['HTTP_FORWARDED'])
				$ipaddress = $_SERVER['HTTP_FORWARDED'];
			else if(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'])
				$ipaddress = $_SERVER['REMOTE_ADDR'];
			else
				$ipaddress = 'UNKNOWN';
			$useragent = $_SERVER['HTTP_USER_AGENT'];
			$message_body = __( 'Email:', 'antlia-wp' ) . ' '. $message_email . "\r\n\r\n" . $message_body;
			$message_body = __( 'Name:', 'antlia-wp' ) . ' '. $message_name . "\r\n" . $message_body;
			$message_body = $message_body."\r\n\r\n".__( 'IP Address:', 'antlia-wp' ).$ipaddress . "\r\n" . __( 'User Agent:', 'antlia-wp' ).$useragent;
			
			$headers = array();
			$headers[] = 'From: '.$message_name.' <' . $email . '>';
			$headers[] = 'Reply-To: '.$message_email;
			$email_sent = wp_mail($email, $subject, $message_body, $headers);
			
			if ( $sendcopy == 'yes' ) {
				// Send a copy of the e-mail to the sender, if specified.
				if ( isset( $_POST['send-copy'] ) && $_POST['send-copy'] == 'true' ) {
					$subject = __( '[COPY]', 'antlia-wp' ) . ' ' . $subject;
					$headers = array();
					$headers[] = 'From: '.get_bloginfo('name').' <' . $email . '>';
					$headers[] = 'Reply-To: '.$email;
					$email_sent = wp_mail($message_email, $subject, $message_body, $headers);
				}
			}
			
			if( $email_sent == true ) {
				$notification = '<p class="contact-error">' . __( 'Your email was successfully sent.', 'antlia-wp' ) . '</p>';
			}
			else {
				$notification = '<p class="contact-error">' . __( 'There were technical error while submitting the form. Sorry for the inconvenience.', 'antlia-wp' ) . '</p>';
			}
	
		}
	}

	if( $email_sent == true ) {
		$html .= $notification;
	}
	else {
	
		$html .= '<div class="contact-form">' . "\n";
		$html .= $notification;
		if ( $email == '' ) {
			$html .= '<p class="contact-error">' . __( 'E-mail has not been setup properly. Please add your contact e-mail!', 'antlia-wp' ) . '</p>';
		} 
		else {
			$html .= '<form action="" id="contact-form" method="post">' . "\n";
			$html .= '<fieldset class="forms">' . "\n";
			$contact_name = '';
			if( isset( $_POST['contact-name'] ) ) { $contact_name = $_POST['contact-name']; }
			$contact_email = '';
			if( isset( $_POST['contact-email'] ) ) { $contact_email = $_POST['contact-email']; }
			$contact_message = '';
			if( isset( $_POST['contact-message'] ) ) { $contact_message = stripslashes( $_POST['contact-message'] ); }
			
			$html .= '<p class="field-contact-name">' . "\n";
			$html .= '<input placeholder="' . __( 'Your Name', 'antlia-wp' ) . '" type="text" name="contact-name" id="contact-name" value="' . esc_attr( $contact_name ) . '" class="txt requiredField" />' . "\n";
			if( array_key_exists( 'contact-name', $error_messages ) ) {
				$html .= '<span class="contact-error">' . $error_messages['contact-name'] . '</span>' . "\n";
			}
			$html .= '</p>' . "\n";

			$html .= '<p class="field-contact-email">' . "\n";
			$html .= '<input placeholder="' . __( 'Your Email', 'antlia-wp' ) . '" type="text" name="contact-email" id="contact-email" value="' . esc_attr( $contact_email ) . '" class="txt requiredField email" />' . "\n";
			if( array_key_exists( 'contact-email', $error_messages ) ) {
				$html .= '<span class="contact-error">' . $error_messages['contact-email'] . '</span>' . "\n";
			}
			$html .= '</p>' . "\n";

			$html .= '<p class="field-contact-message">' . "\n";
			$html .= '<textarea placeholder="' . __( 'Your Message', 'antlia-wp' ) . '" name="contact-message" id="contact-message" rows="10" cols="30" class="textarea requiredField">' . esc_textarea( $contact_message ) . '</textarea>' . "\n";
			if( array_key_exists( 'contact-message', $error_messages ) ) {
				$html .= '<span class="contact-error">' . $error_messages['contact-message'] . '</span>' . "\n";
			}
			$html .= '</p>' . "\n";

			if ( $question && $answer ) {
				$html .= '<p class="field-contact-quiz">' . "\n";
				$html .= $question.'<br/>' . "\n";
				$html .= '<input placeholder="' . __( 'Your Answer', 'antlia-wp' ) . '" type="text" name="contact-quiz" id="contact-quiz" value="" class="txt requiredField quiz" />' . "\n";
				if( array_key_exists( 'contact-quiz', $error_messages ) ) {
					$html .= '<span class="contact-error">' . $error_messages['contact-quiz'] . '</span>' . "\n";
				}
				$html .= '</p>' . "\n";
			}
			
			if ( $sendcopy == 'yes' ) {
				$send_copy = '';
				if(isset($_POST['send-copy']) && $_POST['send-copy'] == true) {
					$send_copy = ' checked="checked"';
				}
				$html .= '<p class="inline"><input type="checkbox" name="send-copy" id="send-copy" value="true"' . $send_copy . ' />&nbsp;&nbsp;<label for="send-copy">' . __( 'Send a copy of this email to you', 'antlia-wp' ) . '</label></p>' . "\n";
			}

			$checking = '';
			if(isset($_POST['checking'])) {
				$checking = $_POST['checking'];
			}

			$html .= '<p class="screen-reader-text"><label for="checking" class="screen-reader-text">' . __('If you want to submit this form, do not enter anything in this field', 'antlia-wp') . '</label><input type="text" name="checking" id="checking" class="screen-reader-text" value="' . esc_attr( $checking ) . '" /></p>' . "\n";

			$html .= '<p class="buttons"><input type="hidden" name="submitted" id="submitted" value="true" /><input id="contactSubmit" type="submit" value="' . $button_text . '" /></p>';

			$html .= '</fieldset>' . "\n";
			$html .= '</form>' . "\n";

			$html .= '</div><!--/.post .contact-form-->' . "\n";

		}
	}
	return $html;
}
/**
 * Disable recent comments styling
 * http://www.narga.net/how-to-remove-or-disable-comment-reply-js-and-recentcomments-from-wordpress-header
 */
add_action( 'widgets_init', 'wpbisnis_remove_recent_comments_style' );
function wpbisnis_remove_recent_comments_style() {
	global $wp_widget_factory;
	remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
}

add_action('init', 'wpbisnis_deregister_wp_embed');
function wpbisnis_deregister_wp_embed() {
	if (!is_admin()) {
		wp_deregister_script('wp-embed');
	}
}

add_action( 'wpbisnis_content_before', 'wpbisnis_output_page_header' );
function wpbisnis_output_page_header() {
	if ( is_archive() ) {
		echo wpbisnis_get_breadcrumb();
		echo '<header class="page-header">';
		the_archive_title( '<h1 class="page-title">', '</h1>' );
		the_archive_description( '<div class="taxonomy-description">', '</div>' );
		echo '</header>';
	}
	elseif ( is_search() ) {
		echo wpbisnis_get_breadcrumb();
		echo '<header class="page-header">';
		echo '<h1 class="page-title">'.sprintf( __( 'Search Results for: %s', 'antlia-wp' ), '<span>' . get_search_query() . '</span>' ).'</h1>';
		echo '</header>';
	}
	else {
		echo wpbisnis_get_breadcrumb();
	}	
}

add_action( 'wpbisnis_entry_header_post_after', 'wpbisnis_output_share_social', 10 );
add_action( 'wpbisnis_entry_header_page_after', 'wpbisnis_output_share_social', 10 );
add_action( 'wpbisnis_entry_header_attachment_after', 'wpbisnis_output_share_social', 10 );
add_action( 'wpbisnis_entry_content_post_after', 'wpbisnis_output_share_social', 20 );
add_action( 'wpbisnis_entry_content_page_after', 'wpbisnis_output_share_social', 20 );
add_action( 'wpbisnis_entry_content_attachment_after', 'wpbisnis_output_share_social', 20 );
function wpbisnis_output_share_social() {

	$filter = current_filter();

	$show = false;
	if ( 'wpbisnis_entry_header_post_after' == $filter && get_theme_mod('wpbisnis_post_share_before', '1') ) {
		$show = true;
	}
	elseif ( 'wpbisnis_entry_content_post_after' == $filter && get_theme_mod('wpbisnis_post_share_after', '1') ) {
		$show = true;
	}
	elseif ( 'wpbisnis_entry_header_page_after' == $filter && get_theme_mod('wpbisnis_page_share_before', '0') ) {
		$show = true;
	}
	elseif ( 'wpbisnis_entry_content_page_after' == $filter && get_theme_mod('wpbisnis_page_share_after', '0') ) {
		$show = true;
	}
	elseif ( 'wpbisnis_entry_header_attachment_after' == $filter && get_theme_mod('wpbisnis_attachment_share_before', '0') ) {
		$show = true;
	}
	elseif ( 'wpbisnis_entry_content_attachment_after' == $filter && get_theme_mod('wpbisnis_attachment_share_after', '0') ) {
		$show = true;
	}

	if ( !$show ) {
		return;
	}

	$share_url = get_permalink();
	$share_title = get_the_title();
	$share_via = get_bloginfo( 'name' );
	$share_image = get_the_post_thumbnail_url( null, 'full' );

	echo '<div class="share-social">';
	echo '<span class="share-label">'.__( 'Share on', 'antlia-wp' ).' </span>';
	echo '<a class="share-link share-facebook" rel="nofollow" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u='.esc_url($share_url).'">Facebook</a>';
	echo '<a class="share-link share-twitter" rel="nofollow" target="_blank" href="https://twitter.com/intent/tweet?text='.urlencode($share_title).'&amp;url='.esc_url($share_url).'&amp;via='.urlencode($share_via).'">Twitter</a>';
	echo '<a class="share-link share-googleplus" rel="nofollow" target="_blank" href="https://plus.google.com/share?url='.esc_url($share_url).'">Google+</a>';
	if ( $share_image ) {
		echo '<a class="share-link share-pinterest" rel="nofollow" target="_blank" href="https://pinterest.com/pin/create/button/?url='.esc_url($share_url).'&amp;media='.esc_url($share_image).'&amp;description='.urlencode($share_title).'">Pin It</a>';
	}
	echo '<a class="share-link share-buffer" rel="nofollow" target="_blank" href="https://bufferapp.com/add?url='.esc_url($share_url).'&amp;text='.urlencode($share_title).'">Buffer</a>';
	echo '</div>';
}

add_action( 'wpbisnis_entry_post_after', 'wpbisnis_output_related', 10 );
add_action( 'wpbisnis_entry_attachment_after', 'wpbisnis_output_related', 10 );
function wpbisnis_output_related() {
	if ( get_theme_mod( 'wpbisnis_'.get_post_type().'_related', '1' ) ) {
		get_template_part( 'related' );
	}
}

add_action( 'wpbisnis_entry_page_after', 'wpbisnis_output_comments', 20 );
add_action( 'wpbisnis_entry_post_after', 'wpbisnis_output_comments', 20 );
add_action( 'wpbisnis_entry_attachment_after', 'wpbisnis_output_comments', 20 );
function wpbisnis_output_comments() {
	if ( get_theme_mod( 'wpbisnis_'.get_post_type().'_comments', '1' ) ) {
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	}
}

add_action( 'wpbisnis_site_content_before', 'wpbisnis_output_ads', 10 );
add_action( 'wpbisnis_site_content_after', 'wpbisnis_output_ads', 10 );
add_action( 'wpbisnis_entry_content_post_before', 'wpbisnis_output_ads', 10 );
add_action( 'wpbisnis_entry_content_post_after', 'wpbisnis_output_ads', 10 );
add_action( 'wpbisnis_entry_after_row1', 'wpbisnis_output_ads', 10 );
add_action( 'wpbisnis_entry_after_row2', 'wpbisnis_output_ads', 10 );
add_action( 'wpbisnis_entry_after_row3', 'wpbisnis_output_ads', 10 );
function wpbisnis_output_ads() {

	$output = '';
	$class = 'marketing-unit';
	$filter = current_filter();

	if ( 'wpbisnis_site_content_before' == $filter ) {
		$output = get_theme_mod('wpbisnis_ad_site_content_before');
		$class .= ' marketing-site-content-top';
	}
	elseif ( 'wpbisnis_site_content_after' == $filter ) {
		$output = get_theme_mod('wpbisnis_ad_site_content_after');
		$class .= ' marketing-site-content-bottom';
	}
	elseif ( 'wpbisnis_entry_content_post_before' == $filter ) {
		$output = get_theme_mod('wpbisnis_ad_post_content_before');
		$class .= ' marketing-post-content-top';
	}
	elseif ( 'wpbisnis_entry_content_post_after' == $filter ) {
		$output = get_theme_mod('wpbisnis_ad_post_content_after');
		$class .= ' marketing-post-content-bottom';
	}
	elseif ( 'wpbisnis_entry_after_row1' == $filter && !is_search() ) {
		$output = get_theme_mod('wpbisnis_ad_archive_row1_after');
		$class .= ' marketing-post-row';
	}
	elseif ( 'wpbisnis_entry_after_row2' == $filter && !is_search() ) {
		$output = get_theme_mod('wpbisnis_ad_archive_row2_after');
		$class .= ' marketing-post-row';
	}
	elseif ( 'wpbisnis_entry_after_row3' == $filter && !is_search() ) {
		$output = get_theme_mod('wpbisnis_ad_archive_row3_after');
		$class .= ' marketing-post-row';
	}

	if ( $output ) {
		printf( '<div class="%s">%s</div>', $class, $output );
	}

}

add_filter( 'post_class', 'wpbisnis_post_class', 50 );
function wpbisnis_post_class( $classes ) {
	if ( in_array( 'hentry', $classes ) ) {
		$classes = array_diff( $classes, array( 'hentry' ) );
		$classes[] = 'entry';
	}
	$image_opt = get_theme_mod( 'wpbisnis_archive_image', 'featured' );
	$content_opt = get_theme_mod( 'wpbisnis_archive_content' );	
	if ( !is_singular() && ( 'thumb-left' == $image_opt || 'thumb-right' == $image_opt ) && 'excerpt' == $content_opt ) {
		$classes[] = 'entry-summary';
	}
	return $classes;
}

add_action( 'wpbisnis_content_before', 'wpbisnis_frontpage_slider' );
function wpbisnis_frontpage_slider() {
	if ( !get_theme_mod('wpbisnis_frontpage_slider') )
		return;
	if ( !is_front_page() )
		return;
	get_template_part('slider');
	global $wpbisnis_slider_js; 
	if ( $wpbisnis_slider_js ) {
		wp_enqueue_script('wallop');
		add_filter( 'wpbisnis_script', 'wpbisnis_print_frontpage_slider_script', 99 );
	}
}

function wpbisnis_print_frontpage_slider_script( $script ) {
	$script .= '
var slider_container = document.querySelector(\'.slider-container\');
var slider_object = new Wallop(slider_container, {
	buttonPreviousClass: \'slider-button-prev\',
	buttonNextClass: \'slider-button-next\',
	itemClass: \'slider-item\',
	currentItemClass: \'slider-item-current\',
	showPreviousClass: \'slider-item-show-previous\',
	showNextClass: \'slider-item-show-next\',
	hidePreviousClass: \'slider-item-hide-previous\',
	hideNextClass: \'slider-item-hide-next\'
});
slider_autoplay(4000);
function slider_autoplay(interval) {
	var lastTime = 0;  
	function frame(timestamp) {
		var update = timestamp - lastTime >= interval;
		if (update) {
			slider_object.next();
			lastTime = timestamp;
		}
		requestAnimationFrame(frame);
	}
	requestAnimationFrame(frame);
};
	';
    return $script;
}

remove_action('wp_head', 'print_emoji_detection_script', 7 );
remove_action('wp_print_styles', 'print_emoji_styles' );
remove_action('wp_head', 'rest_output_link_wp_head', 10 );
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10 );
remove_action('wp_head', 'wp_generator');

if (!function_exists('remove_wp_open_sans')) :
  function remove_wp_open_sans() {
    wp_deregister_style( 'open-sans' );
    wp_register_style( 'open-sans', false );
  }
  add_action('wp_enqueue_scripts', 'remove_wp_open_sans');
  // Uncomment below to remove from admin
  // add_action('admin_enqueue_scripts', 'remove_wp_open_sans');
endif;

add_filter( 'wp_calculate_image_srcset_meta', '__return_null' );

add_action( 'wp', 'wpbisnis_simple_postviews_hits' );
function wpbisnis_simple_postviews_hits() {
 	if ( class_exists('AJAX_Hits_Counter') )
 		return;
 	if ( !is_singular() )
 		return;
	$post_ID = get_the_ID(); 	
    $count_key = 'hits'; 
    $count = get_post_meta($post_ID, $count_key, true);
    if ( '' == $count ){
        $count = 0;
        delete_post_meta($post_ID, $count_key);
        add_post_meta($post_ID, $count_key, '0');
    }
    else {
        $count++;
        update_post_meta($post_ID, $count_key, $count);
    }
}

function wpbisnis_is_page_fullwidth() {
	$fullwidth = get_theme_mod( 'wpbisnis_page_fullwidth' );
	$fullwidth = apply_filters( 'wpbisnis_page_fullwidth', $fullwidth );
	return $fullwidth;
}

add_action( 'body_class', 'wpbisnis_body_class_fullwidth_page' );
function wpbisnis_body_class_fullwidth_page( $classes ) {
	if ( is_page() && wpbisnis_is_page_fullwidth() ) {
		$classes[] = 'page-fullwidth';
	}
	return $classes;
}

add_filter( 'wpbisnis_style', 'wpbisnis_style_googlefonts' );
function wpbisnis_style_googlefonts( $style ) {
	$font_body = get_theme_mod('wpbisnis_font_body');
	$font_heading = get_theme_mod('wpbisnis_font_heading');
	if ( $font_body && $font_body != 'default' ) {
		$font_body = str_replace( ')', '', $font_body );
		$font_body = explode( ' (', $font_body );
		if ( is_array( $font_body ) && 2 == count($font_body) ) {
			if ( in_array( $font_body[1], array( 'serif', 'sans-serif' ) ) ) {
				$style .= 'body,.site-description{font-family:"'.$font_body[0].'", '.$font_body[1].';}';
			}
			else {
				$style .= 'body,.site-description{font-family:"'.$font_body[0].'";}';
			}
		}
	}
	if ( $font_heading && $font_heading != 'default' ) {
		$font_heading = str_replace( ')', '', $font_heading );
		$font_heading = explode( ' (', $font_heading );
		if ( is_array( $font_heading ) && 2 == count($font_heading) ) {
			if ( in_array( $font_heading[1], array( 'serif', 'sans-serif' ) ) ) {
				$style .= 'h1,h2,h3,h4,h5,h6,.site-title{font-family:"'.trim($font_heading[0]).'", '.$font_heading[1].';}';
			}
			else {
				$style .= 'h1,h2,h3,h4,h5,h6,.site-title{font-family:"'.trim($font_heading[0]).'";}';
			}
		}
	}
	return $style;
}

add_action( 'wp_head', 'wpbisnis_enqueue_googlefonts' );
function wpbisnis_enqueue_googlefonts() {
	$font_body = get_theme_mod('wpbisnis_font_body');
	$font_heading = get_theme_mod('wpbisnis_font_heading');
	$fonts = array();
	if ( $font_body && $font_body != 'default' ) {
		$font_body = str_replace( ')', '', $font_body );
		$font_body = explode( ' (', $font_body );
		if ( is_array( $font_body ) && 2 == count($font_body) ) {
			$fonts[] = urlencode( trim( $font_body[0] ) );
		}
	}
	if ( $font_heading && $font_heading != 'default' ) {
		$font_heading = str_replace( ')', '', $font_heading );
		$font_heading = explode( ' (', $font_heading );
		if ( is_array( $font_heading ) && 2 == count($font_heading) ) {
			$fonts[] = urlencode( trim( $font_heading[0] ) );
		}
	}
	if ( !empty( $fonts ) ) {
		$fonts = implode( '|', $fonts );
		echo '<link href="https://fonts.googleapis.com/css?family='.$fonts.'" rel="stylesheet" type="text/css">';
	}
}
