<?php

function wpbisnis_optimizer_scripts() {
    wp_dequeue_style( 'style-parent' );
	wp_dequeue_style( 'style' );
	wp_dequeue_script( 'script' );
	global $wpbisnis_comment_reply_js; 
	if ( $wpbisnis_comment_reply_js ) {
		wp_dequeue_script( 'comment-reply' );
	}
    wp_deregister_script( 'wallop' );
}
add_action( 'wp_enqueue_scripts', 'wpbisnis_optimizer_scripts', 999 );

add_filter( 'wpbisnis_style', 'wpbisnis_print_style', 1 );
function wpbisnis_print_style( $style ) {
    if ( is_child_theme() ) {
    	$path = get_template_directory() . '/style.css';
    	if ( file_exists($path) ) {
    		$output = file_get_contents($path);
    		$output = wpbisnis_minify_css($output);
    		$style .= $output;
    	}
    }
    $path = get_stylesheet_directory() . '/style.css';
    if ( file_exists($path) ) {
        $output = file_get_contents($path);
        $output = wpbisnis_minify_css($output);
        $style .= $output;
    }
	return $style;
}

add_filter( 'wpbisnis_script', 'wpbisnis_print_script', 10 );
function wpbisnis_print_script( $script ) {
	$path = get_template_directory() . '/js/script.js';
	if ( file_exists($path) ) {
		$script .= wpbisnis_minify_js( file_get_contents($path) );
	}
	global $wpbisnis_comment_reply_js; 
	if ( $wpbisnis_comment_reply_js ) {
		$path = ABSPATH . '/wp-includes/js/comment-reply.min.js';
		if ( file_exists($path) ) {
			$script .= file_get_contents($path);
		}
	}
    global $wpbisnis_slider_js; 
    if ( $wpbisnis_slider_js ) {
    	$path = get_template_directory() . '/js/wallop.min.js';
        if ( file_exists($path) ) {
            $script .= file_get_contents($path);
        }
    }
    return $script;
}

/**
 * -----------------------------------------------------------------------------------------
 * Based on `https://gist.github.com/tovic/d7b310dea3b33e4732c0`
 * Based on `https://github.com/mecha-cms/mecha-cms/blob/master/system/kernel/converter.php`
 * -----------------------------------------------------------------------------------------
 */

// CSS Minifier => http://ideone.com/Q5USEF + improvement(s)
function wpbisnis_minify_css($input) {
    if(trim($input) === "") return $input;
    return preg_replace(
        array(
            // Remove comment(s)
            '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')|\/\*(?!\!)(?>.*?\*\/)|^\s*|\s*$#s',
            // Remove unused white-space(s)
            '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/))|\s*+;\s*+(})\s*+|\s*+([*$~^|]?+=|[{};,>~+]|\s*+-(?![0-9\.])|!important\b)\s*+|([[(:])\s++|\s++([])])|\s++(:)\s*+(?!(?>[^{}"\']++|"(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')*+{)|^\s++|\s++\z|(\s)\s+#si',
            // Replace `0(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)` with `0`
            '#(?<=[\s:])(0)(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)#si',
            // Replace `:0 0 0 0` with `:0`
            '#:(0\s+0|0\s+0\s+0\s+0)(?=[;\}]|\!important)#i',
            // Replace `background-position:0` with `background-position:0 0`
            '#(background-position):0(?=[;\}])#si',
            // Replace `0.6` with `.6`, but only when preceded by `:`, `,`, `-` or a white-space
            '#(?<=[\s:,\-])0+\.(\d+)#s',
            // Minify string value
            '#(\/\*(?>.*?\*\/))|(?<!content\:)([\'"])([a-z_][a-z0-9\-_]*?)\2(?=[\s\{\}\];,])#si',
            '#(\/\*(?>.*?\*\/))|(\burl\()([\'"])([^\s]+?)\3(\))#si',
            // Minify HEX color code
            '#(?<=[\s:,\-]\#)([a-f0-6]+)\1([a-f0-6]+)\2([a-f0-6]+)\3#i',
            // Replace `(border|outline):none` with `(border|outline):0`
            '#(?<=[\{;])(border|outline):none(?=[;\}\!])#',
            // Remove empty selector(s)
            '#(\/\*(?>.*?\*\/))|(^|[\{\}])(?:[^\s\{\}]+)\{\}#s'
        ),
        array(
            '$1',
            '$1$2$3$4$5$6$7',
            '$1',
            ':0',
            '$1:0 0',
            '.$1',
            '$1$3',
            '$1$2$4$5',
            '$1$2$3',
            '$1:0',
            '$1$2'
        ),
    $input);
}

// JavaScript Minifier
function wpbisnis_minify_js($input) {
    if(trim($input) === "") return $input;
    return preg_replace(
        array(
            // Remove comment(s)
            '#\s*("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')\s*|\s*\/\*(?!\!|@cc_on)(?>[\s\S]*?\*\/)\s*|\s*(?<![\:\=])\/\/.*(?=[\n\r]|$)|^\s*|\s*$#',
            // Remove white-space(s) outside the string and regex
            '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/)|\/(?!\/)[^\n\r]*?\/(?=[\s.,;]|[gimuy]|$))|\s*([!%&*\(\)\-=+\[\]\{\}|;:,.<>?\/])\s*#s',
            // Remove the last semicolon
            '#;+\}#',
            // Minify object attribute(s) except JSON attribute(s). From `{'foo':'bar'}` to `{foo:'bar'}`
            '#([\{,])([\'])(\d+|[a-z_][a-z0-9_]*)\2(?=\:)#i',
            // --ibid. From `foo['bar']` to `foo.bar`
            '#([a-z0-9_\)\]])\[([\'"])([a-z_][a-z0-9_]*)\2\]#i'
        ),
        array(
            '$1',
            '$1$2',
            '}',
            '$1$3',
            '$1.$3'
        ),
    $input);
}
