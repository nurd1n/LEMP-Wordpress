<?php
/**
 * WPBisnis Theme Customizer
 *
 * @package WPBisnis
 */

add_action( 'customize_register', 'wpbisnis_customize_settings' );
function wpbisnis_customize_settings( $wp_customize ) {

	// title_tagline = 20
	// colors = 40
	// header_image = 60
	// background_image = 80
	// static_front_page = 120

	$wp_customize->add_panel( 'wpbisnis_ads', array(
		'title'    => __( 'Advertisements', 'antlia-wp' ),
		'priority' => 10
	) );

	$wp_customize->add_section( 'wpbisnis_ads_sitewide', array(
		'title'    => __( 'Sitewide', 'antlia-wp' ),
		'panel'    => 'wpbisnis_ads',
		'priority' => 5
	) );

	$wp_customize->add_section( 'wpbisnis_ads_home', array(
		'title'    => __( 'Home / Front Page', 'antlia-wp' ),
		'panel'    => 'wpbisnis_ads',
		'priority' => 10
	) );

	$wp_customize->add_section( 'wpbisnis_ads_archive', array(
		'title'    => __( 'Blog / Archive / Category Page', 'antlia-wp' ),
		'panel'    => 'wpbisnis_ads',
		'priority' => 20
	) );

	$wp_customize->add_section( 'wpbisnis_ads_post', array(
		'title'    => __( 'Single Post', 'antlia-wp' ),
		'panel'    => 'wpbisnis_ads',
		'priority' => 30
	) );

	$wp_customize->add_section( 'wpbisnis_ads_page', array(
		'title'    => __( 'Page', 'antlia-wp' ),
		'panel'    => 'wpbisnis_ads',
		'priority' => 40
	) );

	$wp_customize->add_section( 'wpbisnis_ads_image', array(
		'title'    => __( 'Image Attachment', 'antlia-wp' ),
		'panel'    => 'wpbisnis_ads',
		'priority' => 50
	) );

	$wp_customize->get_section( 'background_image' )->priority = 25;
	$wp_customize->get_section( 'background_image' )->title = __( 'Background', 'antlia-wp' );
	$wp_customize->get_control( 'background_color' )->section = 'background_image';

	$wp_customize->add_section( 'wpbisnis_fonts', array(
		'title'    => __( 'Fonts (Typography)', 'antlia-wp' ),
		'priority' => 29
	) );

	$wp_customize->get_section( 'colors' )->priority = 30;
	$wp_customize->get_section( 'colors' )->title = __( 'Colors', 'antlia-wp' );

	$wp_customize->add_section( 'wpbisnis_customcss', array(
		'title'    => __( 'Custom CSS', 'antlia-wp' ),
		'priority' => 31
	) );

	$wp_customize->add_panel( 'wpbisnis_structure', array(
		'title'    => __( 'Header &amp; Footer', 'antlia-wp' ),
		'priority' => 35
	) );

	$wp_customize->add_section( 'wpbisnis_header_script', array(
		'title'    => __( 'Header Script', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 10
	) );

	$wp_customize->get_section( 'header_image' )->panel = 'wpbisnis_structure';
	$wp_customize->get_section( 'header_image' )->priority = 20;
	$wp_customize->remove_control( 'header_textcolor' );
	$wp_customize->remove_control( 'display_header_text' );
	$wp_customize->get_control( 'header_image' )->section = 'wpbisnis_header';
	$wp_customize->get_control( 'header_image' )->priority = 5;

	$wp_customize->add_section( 'wpbisnis_header', array(
		'title'    => __( 'Header', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 30
	) );

	$wp_customize->add_section( 'wpbisnis_header_menu', array(
		'title'    => __( 'Header Menu', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 40
	) );

	$wp_customize->add_section( 'wpbisnis_breadcrumb', array(
		'title'    => __( 'Breadcrumb', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 50
	) );

	$wp_customize->add_section( 'wpbisnis_footer_widgets', array(
		'title'    => __( 'Footer Widgets', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 100
	) );

	$wp_customize->add_section( 'wpbisnis_footer', array(
		'title'    => __( 'Footer', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 110
	) );

	$wp_customize->add_section( 'wpbisnis_footer_script', array(
		'title'    => __( 'Footer Script', 'antlia-wp' ),
		'panel'    => 'wpbisnis_structure',
		'priority' => 120
	) );

	$wp_customize->add_panel( 'wpbisnis_templates', array(
		'title'    => __( 'Template Settings', 'antlia-wp' ),
		'priority' => 40
	) );

	$wp_customize->add_section( 'wpbisnis_template_home', array(
		'title'    => __( 'Home / Front Page', 'antlia-wp' ),
		'panel'    => 'wpbisnis_templates',
		'priority' => 10
	) );

	$wp_customize->add_section( 'wpbisnis_template_archive', array(
		'title'    => __( 'Blog / Archive / Category Page', 'antlia-wp' ),
		'panel'    => 'wpbisnis_templates',
		'priority' => 20
	) );

	$wp_customize->add_section( 'wpbisnis_template_post', array(
		'title'    => __( 'Single Post', 'antlia-wp' ),
		'panel'    => 'wpbisnis_templates',
		'priority' => 30
	) );

	$wp_customize->add_section( 'wpbisnis_template_page', array(
		'title'    => __( 'Page', 'antlia-wp' ),
		'panel'    => 'wpbisnis_templates',
		'priority' => 40
	) );

	$wp_customize->add_section( 'wpbisnis_template_attachment', array(
		'title'    => __( 'Attachment', 'antlia-wp' ),
		'panel'    => 'wpbisnis_templates',
		'priority' => 50
	) );

}

function wpbisnis_customize_controls( $controls ) {

	$controls[] = array(
		'type'     => 'select',
		'setting'  => 'wpbisnis_font_body',
		'label'    => __( 'Body Font', 'antlia-wp' ),
		'section'  => 'wpbisnis_fonts',
		'default'  => '',
		'choices'  => wpbisnis_get_googlefonts(),
	);

	$controls[] = array(
		'type'     => 'select',
		'setting'  => 'wpbisnis_font_heading',
		'label'    => __( 'Heading Font', 'antlia-wp' ),
		'section'  => 'wpbisnis_fonts',
		'default'  => '',
		'choices'  => wpbisnis_get_googlefonts(),
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_text_color',
		'label'    => __( 'Text Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'body, button, input, select, textarea { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_heading_color',
		'label'    => __( 'Heading Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'h1,h2,h3,h4,h5 { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_link_color',
		'label'    => __( 'Link Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'a, a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_link_color_hover',
		'label'    => __( 'Link Color (Hover)', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'a:hover { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_post_title_color',
		'label'    => __( 'Post Title Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => '.entry .entry-title, .entry .entry-title a, .entry .entry-title a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_post_meta_color',
		'label'    => __( 'Post Meta Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => '.entry-meta, .entry-meta a, .entry-meta a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_label_color',
		'label'    => __( 'Form Label Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'label, .comment-form label { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_input_background',
		'label'    => __( 'Form Input/Textarea Background', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], textarea { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_input_color',
		'label'    => __( 'Form Input/Textarea Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], textarea { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_input_border',
		'label'    => __( 'Form Input/Textarea Border', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], textarea { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_button_background',
		'label'    => __( 'Form Button Background', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'button, input[type=button], input[type=reset], input[type=submit] { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_button_border',
		'label'    => __( 'Form Button Border', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'button, input[type=button], input[type=reset], input[type=submit] { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_button_color',
		'label'    => __( 'Form Button Color', 'antlia-wp' ),
		'section'  => 'colors',
		'default'  => '',
		'style'    => 'button, input[type=button], input[type=reset], input[type=submit] { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_script_header',
		'label'    => __( 'Header Script', 'antlia-wp' ),
		'description' => __( 'Useful for third party scripts, for example Google Analytics, Histats, Facebook Pixel, etc', 'antlia-wp' ),
		'section'  => 'wpbisnis_header_script',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'radio',
		'setting'  => 'wpbisnis_header_placement',
		'label'    => __( 'Header Image Placement', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => 'background',
		'choices'  => array(
			'background' => __( 'Behind title and description (background image)', 'antlia-wp' ),
			'image' => __( 'Instead of title and description (image only)', 'antlia-wp' ),
			'image_title_top' => __( 'Have site title and description placed before the image', 'antlia-wp' ),
			'image_title_bottom' => __( 'Have site title and description placed after the image', 'antlia-wp' ),
			'image_desc_bottom' => __( 'Have site description placed after the image', 'antlia-wp' ),
		),
		'priority' => 6,
	);

	$controls[] = array(
		'type'     => 'radio-buttonset',
		'setting'  => 'wpbisnis_header_alignment',
		'label'    => __( 'Header Alignment', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => 'center',
		'choices'  => array(
			'left' => __( 'Left', 'antlia-wp' ),
			'center' => __( 'Center', 'antlia-wp' ),
			'right' => __( 'Right', 'antlia-wp' ),
		),
		'style'  => array(
			'left' => '.site-branding{text-align:left;}',
			'center' => '.site-branding{text-align:center;}',
			'right' => '.site-branding{text-align:right;}',
		),
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_header_background',
		'label'    => __( 'Header Background Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => '',
		'style'    => '.site-branding { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'slider',
		'setting'  => 'wpbisnis_header_paddingtop',
		'label'    => __( 'Header Top Padding', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => 80,
		'choices'  => array(
			'min' => 30,
			'max' => 120,
			'step' => 5,
		),
		'style'    => '.site-branding { padding-top: [value]px }',
	);

	$controls[] = array(
		'type'     => 'slider',
		'setting'  => 'wpbisnis_header_paddingbottom',
		'label'    => __( 'Header Bottom Padding', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => 65,
		'choices'  => array(
			'min' => 30,
			'max' => 120,
			'step' => 5,
		),
		'style'    => '.site-branding { padding-bottom: [value]px }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_header_title_color',
		'label'    => __( 'Site Title Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => '',
		'style'    => '.site-title a, .site-title a:visited, .site-title { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_header_desc_color',
		'label'    => __( 'Site Description Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_header',
		'default'  => '',
		'style'    => '.site-description { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'radio-buttonset',
		'setting'  => 'wpbisnis_menu_alignment',
		'label'    => __( 'Menu Alignment', 'antlia-wp' ),
		'section'  => 'wpbisnis_header_menu',
		'default'  => 'left',
		'choices'  => array(
			'left' => __( 'Left', 'antlia-wp' ),
			'center' => __( 'Center', 'antlia-wp' ),
			'right' => __( 'Right', 'antlia-wp' ),
		),
		'style'  => array(
			'left' => '',
			'center' => '.main-navigation {text-align:center; } .main-navigation ul.menu{ display:inline-block;vertical-align:top;} .main-navigation a,.main-navigation a:visited,.main-navigation li.header-searchform {padding-left:10px;padding-right:10px;}',
			'right' => '.main-navigation {text-align:right; } .main-navigation ul.menu{ display:inline-block;vertical-align:top;} .main-navigation a,.main-navigation a:visited,.main-navigation li.header-searchform {padding-left:20px;padding-right:0;}',
		),
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_menu_search',
		'label'    => __( 'Show search form', 'antlia-wp' ),
		'section'  => 'wpbisnis_header_menu',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_menu_background',
		'label'    => __( 'Menu Background Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_header_menu',
		'default'  => '',
		'style'    => '.main-navigation, .main-navigation ul ul { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_menu_link_color',
		'label'    => __( 'Menu Link Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_header_menu',
		'default'  => '',
		'style'    => '.main-navigation a, .main-navigation a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_menu_link_color_hover',
		'label'    => __( 'Menu Link Color (Hover)', 'antlia-wp' ),
		'section'  => 'wpbisnis_header_menu',
		'default'  => '',
		'style'    => '.main-navigation a:hover { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_breadcrumb',
		'label'    => __( 'Show Breadcrumb', 'antlia-wp' ),
		'section'  => 'wpbisnis_breadcrumb',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_breadcrumb_color',
		'label'    => __( 'Breadcrumb Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_breadcrumb',
		'default'  => '',
		'style'    => '.breadcrumb { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_breadcrumb_link_color',
		'label'    => __( 'Breadcrumb Link Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_breadcrumb',
		'default'  => '',
		'style'    => '.breadcrumb a, .breadcrumb a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_footer_widgets',
		'label'    => __( 'Show Footer Widgets', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_background',
		'label'    => __( 'Footer Widgets Background Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.site-footer-widgets { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_border',
		'label'    => __( 'Footer Widgets Border Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.site-footer-widgets { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_title_color',
		'label'    => __( 'Footer Widgets Title Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.footer-widget.widget .widget-title { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_color',
		'label'    => __( 'Footer Widgets Text Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.footer-widget.widget { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_link_color',
		'label'    => __( 'Footer Widgets Link Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.footer-widget.widget a, .footer-widget.widget a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_link_color_hover',
		'label'    => __( 'Footer Widgets Link Color (Hover)', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.footer-widget.widget a:hover { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_widgets_line_color',
		'label'    => __( 'Footer Widgets Line Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_widgets',
		'default'  => '',
		'style'    => '.footer-widget.widget .widget-title, .footer-widget.widget li, .footer-widget.widget ul ul { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_footer_text',
		'label'    => __( 'Footer Text', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer',
		'sanitize_callback' => 'wp_kses_post',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_background',
		'label'    => __( 'Footer Background Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer',
		'default'  => '',
		'style'    => '.site-footer { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_text_color',
		'label'    => __( 'Footer Text Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer',
		'default'  => '',
		'style'    => '.site-footer { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_link_color',
		'label'    => __( 'Footer Link Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer',
		'default'  => '',
		'style'    => '.site-footer a, .site-footer a:visited { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_footer_link_color_hover',
		'label'    => __( 'Footer Link Color (Hover)', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer',
		'default'  => '',
		'style'    => '.site-footer a:hover { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_script_footer',
		'label'    => __( 'Footer Script', 'antlia-wp' ),
		'description' => __( 'Useful for third party scripts, for example Google Analytics, Histats, Facebook Pixel, etc', 'antlia-wp' ),
		'section'  => 'wpbisnis_footer_script',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_frontpage_slider',
		'label'    => __( 'Show frontpage slider', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_home',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'number',
		'setting'  => 'wpbisnis_frontpage_slider_number',
		'label'    => __( 'Slider: Number of posts to show', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_home',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'dropdown-categories',
		'setting'  => 'wpbisnis_frontpage_slider_cat',
		'label'    => __( 'Slider: Select posts from a category', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_home',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'select',
		'setting'  => 'wpbisnis_archive_image',
		'label'    => __( 'Show featured image', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => 'featured',
		'choices'  => array(
			'featured' => __( 'Featured Image', 'antlia-wp' ),
			'thumb-left' => __( 'Left Thumbnail', 'antlia-wp' ),
			'thumb-right' => __( 'Right Thumbnail', 'antlia-wp' ),
			'none' => __( 'No Image', 'antlia-wp' ),
		),
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_archive_meta',
		'label'    => __( 'Show post meta', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'radio-buttonset',
		'setting'  => 'wpbisnis_archive_content',
		'label'    => __( 'Show content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => 'content',
		'choices'  => array(
			'content' => __( 'Full Content', 'antlia-wp' ),
			'excerpt' => __( 'Summary', 'antlia-wp' ),
		),
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_archive_morelink',
		'label'    => __( 'Show "Continue Reading" link on post summary', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_pagination_background',
		'label'    => __( 'Pagination Background', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => '',
		'style'    => '.posts-navigation li span, .posts-navigation li a, .page-links li span, .page-links li a { background-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_pagination_border',
		'label'    => __( 'Pagination Border', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => '',
		'style'    => '.posts-navigation li span, .posts-navigation li a, .page-links li span, .page-links li a { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_pagination_text_color',
		'label'    => __( 'Pagination Text Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => '',
		'style'    => '.posts-navigation li span, .page-links li span { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_pagination_link_color',
		'label'    => __( 'Pagination Link Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_archive',
		'default'  => '',
		'style'    => '.posts-navigation li a, .page-links li a { color: [value] }',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_post_image',
		'label'    => __( 'Show featured image', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_post_share_before',
		'label'    => __( 'Show social share before content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_post_share_after',
		'label'    => __( 'Show social share after content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_post_related',
		'label'    => __( 'Show related posts', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_post_related_image',
		'label'    => __( 'Show related post images', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_post_comments',
		'label'    => __( 'Show comments', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_post_share_label_color',
		'label'    => __( 'Social Share Label Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '',
		'style'    => '.share-label { color: [value]; border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_post_related_separator_color',
		'label'    => __( 'Related Post Separator Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '',
		'style'    => '.related-posts li { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'color',
		'setting'  => 'wpbisnis_post_comments_box_border',
		'label'    => __( 'Comment Box Border Color', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_post',
		'default'  => '',
		'style'    => '.comment-body { border-color: [value] }',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_page_share_before',
		'label'    => __( 'Show social share before content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_page',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_page_share_after',
		'label'    => __( 'Show social share after content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_page',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_page_comments',
		'label'    => __( 'Show comments', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_page',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_attachment_share_before',
		'label'    => __( 'Show social share before content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_attachment',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_attachment_share_after',
		'label'    => __( 'Show social share after content', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_attachment',
		'default'  => '',
	);

	$controls[] = array(
		'type'     => 'checkbox',
		'setting'  => 'wpbisnis_attachment_comments',
		'label'    => __( 'Show comments', 'antlia-wp' ),
		'section'  => 'wpbisnis_template_attachment',
		'default'  => '1',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_site_content_before',
		'label'    => __( 'Ad - Before site content', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_sitewide',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_site_content_after',
		'label'    => __( 'Ad - After site content', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_sitewide',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_archive_row1_after',
		'label'    => __( 'Ad - After first post row', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_archive',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_archive_row2_after',
		'label'    => __( 'Ad - After second post row', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_archive',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_archive_row3_after',
		'label'    => __( 'Ad - After third post row', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_archive',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_post_content_before',
		'label'    => __( 'Ad - Before post content', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_post',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	$controls[] = array(
		'type'     => 'textarea',
		'setting'  => 'wpbisnis_ad_post_content_after',
		'label'    => __( 'Ad - After post content', 'antlia-wp' ),
		'section'  => 'wpbisnis_ads_post',
		'sanitize_callback' => 'wpbisnis_sanitize_ads',
	);

	return $controls;
}
add_filter( 'wpbisnis_customize_controls', 'wpbisnis_customize_controls' );

function wpbisnis_customize_controls_customcss( $controls ) {

	$controls[] = array(
		'type'     => 'custom-css',
		'setting'  => 'wpbisnis_customcss',
		'label'    => __( 'Custom CSS', 'antlia-wp' ),
		'section'  => 'wpbisnis_customcss',
		'default'  => '',
		'sanitize_callback' => 'wpbisnis_sanitize_css',
	);

	return $controls;
}
add_filter( 'wpbisnis_customize_controls', 'wpbisnis_customize_controls_customcss', 999 );

