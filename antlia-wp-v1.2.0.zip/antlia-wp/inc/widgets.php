<?php

add_action( 'widgets_init', function(){
	register_widget( 'WPBisnis_Widget_Posts_List' );
});

class WPBisnis_Widget_Posts_List extends WP_Widget {

	public function __construct() {
		$widget_ops = array(
			'classname' => 'widget_posts_list',
			'description' => __( 'Your site&#8217;s posts list.', 'antlia-wp' ),
			'customize_selective_refresh' => false,
		);
		parent::__construct( 'posts-list', '::WPBisnis:: '.__( 'Posts List', 'antlia-wp' ), $widget_ops );
		$this->alt_option_name = 'widget_posts_list';
	}

	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		$title = $instance['title'];

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$orderby = 'date';
		if ( isset( $instance['orderby'] ) && in_array( $instance['orderby'], array( 'date', 'view', 'comment_count', 'rand', 'title', 'id' ) ) )
			$orderby = $instance['orderby'];

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number )
			$number = 5;
		$show_image = isset( $instance['show_image'] ) ? $instance['show_image'] : false;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;
		$show_excerpt = isset( $instance['show_excerpt'] ) ? $instance['show_excerpt'] : false;

		$post_title_class = ( $show_image || $show_date || $show_excerpt ) ? 'post-title-alt' : 'post-title';

		$query_args = array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true
		);

		if ( 'comment_count' == $orderby ) {
			$query_args['orderby'] = 'comment_count';
			$query_args['order'] = 'DESC';
		}
		elseif ( 'rand' == $orderby ) {
			$query_args['orderby'] = 'rand';
			$query_args['order'] = 'DESC';
		}
		elseif ( 'view' == $orderby ) {
			$query_args['meta_key'] = 'hits';
			$query_args['meta_value_num'] = '0';
			$query_args['meta_compare'] = '>';
			$query_args['orderby'] = 'meta_value_num';
			$query_args['order'] = 'DESC';
		}
		elseif ( 'title' == $orderby ) {
			$query_args['orderby'] = 'title';
			$query_args['order'] = 'ASC';
		}
		elseif ( 'id' == $orderby ) {
			$query_args['orderby'] = 'ID';
			$query_args['order'] = 'ASC';
		}
		else {
			$query_args['orderby'] = 'date';
			$query_args['order'] = 'DESC';
		}

		$r = new WP_Query( $query_args );

		if ($r->have_posts()) :
		?>
		<?php echo $args['before_widget']; ?>
		<?php if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
		<ul>
		<?php while ( $r->have_posts() ) : $r->the_post(); ?>
			<li>
			<?php if ( $show_image ) : ?>
				<?php echo wpbisnis_get_image( array( 'size' => 'medium-thumbnail', 'class' => 'post-image', 'alt' => get_the_title(), 'link' => 'post', 'fallback' => 'attachment' ) ); ?>
			<?php endif; ?>
			<a href="<?php the_permalink(); ?>" class="<?php echo esc_attr( $post_title_class ); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a>
			<?php if ( $show_date ) : ?>
				<span class="post-date"><?php echo get_the_date(); ?></span>
			<?php endif; ?>
			<?php if ( $show_excerpt ) : ?>
				<?php the_excerpt(); ?>
			<?php endif; ?>
			</li>
		<?php endwhile; ?>
		</ul>
		<?php echo $args['after_widget']; ?>
		<?php
		// Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();

		endif;
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );

		$instance['orderby'] = 'date';
		if ( in_array( $new_instance['orderby'], array( 'date', 'view', 'comment_count', 'rand', 'title', 'id' ) ) )
			$instance['orderby'] = $new_instance['orderby'];

		$instance['number'] = (int) $new_instance['number'];
		$instance['show_image'] = isset( $new_instance['show_image'] ) ? (bool) $new_instance['show_image'] : false;
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$instance['show_excerpt'] = isset( $new_instance['show_excerpt'] ) ? (bool) $new_instance['show_excerpt'] : false;
		return $instance;
	}

	public function form( $instance ) {
		$title        = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$orderby      = isset( $instance['orderby'] ) ? esc_attr( $instance['orderby'] ) : '';
		$number       = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_image   = isset( $instance['show_image'] ) ? (bool) $instance['show_image'] : false;
		$show_date    = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
		$show_excerpt = isset( $instance['show_excerpt'] ) ? (bool) $instance['show_excerpt'] : false;
?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'antlia-wp' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

		<p>
		<label for="<?php echo $this->get_field_id('orderby'); ?>"><?php _e( 'Sort by:', 'antlia-wp' ); ?></label>
		<select name="<?php echo $this->get_field_name('orderby'); ?>" id="<?php echo $this->get_field_id('orderby'); ?>" class="widefat">
			<option value="date"<?php selected( $orderby, 'date' ); ?>><?php _e( 'Recent Posts', 'antlia-wp' ); ?></option>
			<option value="view"<?php selected( $orderby, 'view' ); ?>><?php _e( 'Most Viewed Posts', 'antlia-wp' ); ?></option>
			<option value="comment_count"<?php selected( $orderby, 'comment_count' ); ?>><?php _e( 'Most Commented Posts', 'antlia-wp' ); ?></option>
			<option value="rand"<?php selected( $orderby, 'rand' ); ?>><?php _e( 'Random Posts', 'antlia-wp' ); ?></option>
			<option value="title"<?php selected( $orderby, 'title' ); ?>><?php _e( 'Post Title', 'antlia-wp' ); ?></option>
			<option value="id"<?php selected( $orderby, 'id' ); ?>><?php _e( 'Post ID', 'antlia-wp' ); ?></option>
		</select>
		</p>

		<p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of posts to show:', 'antlia-wp' ); ?></label>
		<input class="tiny-text" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="number" step="1" min="1" value="<?php echo $number; ?>" size="3" /></p>

		<p><input class="checkbox" type="checkbox"<?php checked( $show_image ); ?> id="<?php echo $this->get_field_id( 'show_image' ); ?>" name="<?php echo $this->get_field_name( 'show_image' ); ?>" />
		<label for="<?php echo $this->get_field_id( 'show_image' ); ?>"><?php _e( 'Display post image?', 'antlia-wp' ); ?></label></p>

		<p><input class="checkbox" type="checkbox"<?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
		<label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php _e( 'Display post date?', 'antlia-wp' ); ?></label></p>

		<p><input class="checkbox" type="checkbox"<?php checked( $show_excerpt ); ?> id="<?php echo $this->get_field_id( 'show_excerpt' ); ?>" name="<?php echo $this->get_field_name( 'show_excerpt' ); ?>" />
		<label for="<?php echo $this->get_field_id( 'show_excerpt' ); ?>"><?php _e( 'Display post excerpt?', 'antlia-wp' ); ?></label></p>
<?php
	}
}
