<?php
/**
 * Template Name: -- No Title --
 *
 * @package  WPBisnis
 */

add_filter('wpbisnis_page_fullwidth', '__return_true');
get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'wpbisnis_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'wpbisnis_entry_page_before' ); ?>

			<?php get_template_part( 'content', 'page-notitle' ); ?>

			<?php do_action( 'wpbisnis_entry_page_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'wpbisnis_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php if ( ! wpbisnis_is_page_fullwidth() ) get_sidebar(); ?>
<?php get_footer(); ?>
