!function(){var e,t,a;if(e=document.getElementById("site-navigation"),e&&(t=e.getElementsByTagName("button")[0],"undefined"!=typeof t)){if(a=e.getElementsByTagName("ul")[0],"undefined"==typeof a)return void(t.style.display="none");a.setAttribute("aria-expanded","false"),-1===a.className.indexOf("nav-menu")&&(a.className+=" nav-menu"),t.onclick=function(){-1!==e.className.indexOf("toggled")?(e.className=e.className.replace(" toggled",""),t.setAttribute("aria-expanded","false"),a.setAttribute("aria-expanded","false")):(e.className+=" toggled",t.setAttribute("aria-expanded","true"),a.setAttribute("aria-expanded","true"))}}}();!function(){var e=navigator.userAgent.toLowerCase().indexOf("webkit")>-1,t=navigator.userAgent.toLowerCase().indexOf("opera")>-1,n=navigator.userAgent.toLowerCase().indexOf("msie")>-1;(e||t||n)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var e=document.getElementById(location.hash.substring(1));e&&(/^(?:a|select|input|button|textarea)$/i.test(e.tagName)||(e.tabIndex=-1),e.focus())},!1)}();
/* https://jonsuh.com/blog/social-share-links/ */
function wpbshareopen(url, width, height) {
	var left = (screen.width / 2) - (width / 2), top = (screen.height / 2) - (height / 2);
	window.open(
		url,
		"",
		"menubar=no,toolbar=no,resizable=yes,scrollbars=yes,width=" + width + ",height=" + height + ",top=" + top + ",left=" + left
	);
}
var wpbshare = document.querySelectorAll(".share-link");
if (wpbshare) {
	[].forEach.call(wpbshare, function(anchor) {
		anchor.addEventListener("click", function(e) {
			e.preventDefault();
			wpbshareopen(this.href, 500, 300);
		});
	});
}
