<?php
/**
 * WPBisnis functions and definitions
 *
 * @package WPBisnis
 */

define( 'WPBISNIS_URL', 'http://www.wpbisnis.com' );
define( 'WPBISNIS_THEME_NAME', 'Antlia WordPress Theme' );
define( 'WPBISNIS_THEME_SLUG', 'antlia-wp' );
define( 'WPBISNIS_THEME_VERSION', '1.2.0' );

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 750; /* pixels */
}

if ( ! function_exists( 'wpbisnis_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function wpbisnis_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on WPBisnis, use a find and replace
	 * to change 'antlia-wp' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'antlia-wp', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 728, 393, true );
	add_image_size( 'medium-thumbnail', 222, 137, true );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'header' => __( 'Header Menu', 'antlia-wp' ),
		'footer' => __( 'Footer Menu', 'antlia-wp' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	// add_theme_support( 'post-formats', array(
	// 	'aside', 'image', 'video', 'quote', 'link',
	// ) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'wpbisnis_custom_background_args', array(
		'default-color' => '',
		'default-image' => '',
	) ) );

	add_theme_support( 'custom-header', apply_filters( 'wpbisnis_custom_header_args', array(
		'width'                  => 788,
		'height'                 => 200,
		'default-image'          => '',
		'default-text-color'     => '',
		'flex-width'             => true,
		'flex-height'            => true,
	) ) );

	add_editor_style();

	require( get_template_directory() . '/updater/theme-updater.php' );
}
endif; // wpbisnis_setup
add_action( 'after_setup_theme', 'wpbisnis_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function wpbisnis_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar [DISABLED]', 'antlia-wp' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'This theme does not use this sidebar, but Jetpack Mobile will use it.', 'antlia-wp' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	for ($i=1; $i <=3 ; $i++) { 
		register_sidebar( array(
			'name'          => sprintf( __( 'Footer #%s', 'antlia-wp' ), $i ),
			'id'            => 'footer-'.$i,
			'description'   => '',
			'before_widget' => '<aside id="%1$s" class="footer-widget widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
	}
}
add_action( 'widgets_init', 'wpbisnis_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function wpbisnis_enqueue_scripts() {
	wp_enqueue_script( 'script', get_template_directory_uri() . '/js/script.js', array(), WPBISNIS_THEME_VERSION, true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		if ( get_theme_mod( 'wpbisnis_'.get_post_type().'_comments', '1' ) ) {
			global $wpbisnis_comment_reply_js;
			$wpbisnis_comment_reply_js = true;
			wp_enqueue_script( 'comment-reply' );
		}
	}
	wp_register_script( 'wallop', get_template_directory_uri() . '/js/wallop.min.js', array(), WPBISNIS_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'wpbisnis_enqueue_scripts' );

function wpbisnis_enqueue_styles() {
    if ( is_child_theme() ) {
        wp_enqueue_style( 'style-parent', trailingslashit( get_template_directory_uri() ) . 'style.css', array(), WPBISNIS_THEME_VERSION );
    }
	wp_enqueue_style( 'style', get_stylesheet_uri(), array(), WPBISNIS_THEME_VERSION );
}
add_action( 'wp_enqueue_scripts', 'wpbisnis_enqueue_styles', 25 );

include_once( get_template_directory() . '/inc/googlefonts.php' );
include_once( get_template_directory() . '/inc/customize.php' );
include_once( get_template_directory() . '/inc/options.php' );
include_once( get_template_directory() . '/inc/exportimport.php' );
include_once( get_template_directory() . '/inc/widgets.php' );

if ( ! is_admin() ) {
	include_once( get_template_directory() . '/inc/frontend.php' );
	include_once( get_template_directory() . '/inc/optimize.php' );
	include_once( get_template_directory() . '/inc/breadcrumb.php' );
}
