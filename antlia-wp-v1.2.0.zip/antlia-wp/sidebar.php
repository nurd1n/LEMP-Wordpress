<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package WPBisnis
 */

/* No sidebar for this theme */
return;

?>

<div id="secondary" class="widget-area">
	<div class="site-sidebar">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div>
</div>
