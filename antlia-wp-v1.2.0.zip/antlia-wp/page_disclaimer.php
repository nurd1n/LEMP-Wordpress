<?php
/**
 * Template Name: - Disclaimer -
 *
 * @package  WPBisnis
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'wpbisnis_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'wpbisnis_entry_page_before' ); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header class="entry-header">
					<?php do_action( 'wpbisnis_entry_header_page_before' ); ?>
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
					<?php do_action( 'wpbisnis_entry_header_page_after' ); ?>
				</header>

				<?php do_action( 'wpbisnis_entry_content_page_before' ); ?>

				<div class="entry-content">
					<?php the_content(); ?>
					<?php 
					$wpb_page_content = get_theme_mod( 'wpbisnis_page_dislaimer' );
					if ( !trim($wpb_page_content) ) {
						$wpb_page_content = __( '<p>The information contained in this website is for general information purposes only. The information is provided by this website and while we endeavour to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.</p><p>In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.</p><p>Through this website you are able to link to other websites which are not under the control of this website. We have no control over the nature, content and availability of those sites. The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them.</p><p>Every effort is made to keep the website up and running smoothly. However, this website takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.</p><p>Regards,<br/>%1$s Team</p>', 'antlia-wp' ) ;
					}
					printf( $wpb_page_content, '<a href="'.home_url('/').'" rel="home">'.get_bloginfo('name').'</a>' );
					?>
				</div>

				<?php do_action( 'wpbisnis_entry_content_page_after' ); ?>
				
			</article>

			<?php do_action( 'wpbisnis_entry_page_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'wpbisnis_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php if ( ! wpbisnis_is_page_fullwidth() ) get_sidebar(); ?>
<?php get_footer(); ?>
