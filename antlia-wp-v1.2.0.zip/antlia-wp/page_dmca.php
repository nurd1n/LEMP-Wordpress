<?php
/**
 * Template Name: - DMCA -
 *
 * @package  WPBisnis
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'wpbisnis_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'wpbisnis_entry_page_before' ); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header class="entry-header">
					<?php do_action( 'wpbisnis_entry_header_page_before' ); ?>
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
					<?php do_action( 'wpbisnis_entry_header_page_after' ); ?>
				</header>

				<?php do_action( 'wpbisnis_entry_content_page_before' ); ?>

				<div class="entry-content">
					<?php the_content(); ?>
					<?php 
					$wpb_page_content = get_theme_mod( 'wpbisnis_page_dmca' );
					if ( !trim($wpb_page_content) ) {
						$wpb_page_content = __( '<p>If you have reason to believe that one of our content is violating your copyrights or some of Search Results references to illegal contents, please contact us using the contact menu we provide.</p><p>Please allow up to a 1-3 business days for an email response. Note that emailing your complaint to other parties such as our Internet Service Provider, Hosting Provider, and other third party will not expedite your request and may result in a delayed response due to the complaint not being filed properly.</p><p>Please note that we deal only with messages that meet the following requirements:</p><ul><li>Please Provide us with your name, address and telephone number. We reserve the right to verify this information.</li><li>Explain which copyrighted material is affected.</li><li>Please provide the exact and complete to the URL link.</li><li>If it a case of files with illegal contents, please describe the contents briefly in two or three points.</li><li>Please ensure that you can receive further enquiries from us at the e-mail address you are writing from.</li><li>Please write to us only in English.</li></ul><p>Anonymous or incomplete messages will not be dealt with. Thank you for your understanding.</p><p>All the images are not under our Copyrights and belong to their respective owners. We respect Copyright Laws. If You have found the link to an illegal content, please report it to us using the contact menu. We will remove it in 1-3 business days.</p><p>Thank you very much.</p><p>Regards,<br/>%1$s Team</p>', 'antlia-wp' ) ;
					}
					printf( $wpb_page_content, '<a href="'.home_url('/').'" rel="home">'.get_bloginfo('name').'</a>' );
					?>
				</div>

				<?php do_action( 'wpbisnis_entry_content_page_after' ); ?>
				
			</article>

			<?php do_action( 'wpbisnis_entry_page_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'wpbisnis_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php if ( ! wpbisnis_is_page_fullwidth() ) get_sidebar(); ?>
<?php get_footer(); ?>
