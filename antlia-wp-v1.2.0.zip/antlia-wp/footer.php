<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WPBisnis
 */
?>

	<?php do_action( 'wpbisnis_site_content_after' ); ?>
	</div>

	<?php if ( get_theme_mod( 'wpbisnis_footer_widgets', '1' ) ) : ?>
		<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
			<div id="footer-widgets" class="site-footer-widgets widget-area">
				<div class="footer-container">
					<div class="footer-row">
						<div class="footer-col">
							<?php dynamic_sidebar( 'footer-1' ); ?>
						</div>
						<div class="footer-col">
							<?php dynamic_sidebar( 'footer-2' ); ?>
						</div>
						<div class="footer-col">
							<?php dynamic_sidebar( 'footer-3' ); ?>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	<?php endif; ?>

	<footer id="colophon" class="site-footer">
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav id="footer-navigation" class="footer-navigation">
				<?php echo wpbisnis_get_nav_menu( array( 'theme_location' => 'footer', 'fallback_cb' => '' ) ); ?>
			</nav>
		<?php endif; ?>
		<div class="site-info">
			<?php if ( get_theme_mod( 'wpbisnis_footer_text' ) ) : ?>
				<?php echo get_theme_mod( 'wpbisnis_footer_text' ); ?>
			<?php else : ?>
				<?php echo 'WPBisnis - WordPress For Your Online Business'; ?>
			<?php endif; ?>
		</div>
	</footer>
</div>

<?php wp_footer(); ?>

</body>
</html>
