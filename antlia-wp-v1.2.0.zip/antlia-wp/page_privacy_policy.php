<?php
/**
 * Template Name: - Privacy Policy -
 *
 * @package  WPBisnis
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'wpbisnis_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'wpbisnis_entry_page_before' ); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header class="entry-header">
					<?php do_action( 'wpbisnis_entry_header_page_before' ); ?>
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
					<?php do_action( 'wpbisnis_entry_header_page_after' ); ?>
				</header>

				<?php do_action( 'wpbisnis_entry_content_page_before' ); ?>

				<div class="entry-content">
					<?php the_content(); ?>
					<?php 
					$wpb_page_content = get_theme_mod( 'wpbisnis_page_privacy_policy' );
					if ( !trim($wpb_page_content) ) {
						$wpb_page_content = __( '<p>Privacy Policy for %1$s</p><p>The privacy of our visitors to %1$s is important to us.</p><p>At %1$s, we recognize that privacy of your personal information is important. Here is information on what types of personal information we receive and collect when you use and visit %1$s, and how we safeguard your information. We never sell your personal information to third parties.</p><h2>Log Files</h2><p>As with most other websites, we collect and use the data contained in log files. The information in the log files contain your IP (internet protocol) address, your ISP (internet service provider, such as AOL or Shaw Cable), the browser you used to visit our site (such as Internet Explorer or Firefox), the time you visited our site and which pages you visited throughout our site.</p><h2>Cookies and Web Beacons</h2><p>We do use cookies to store information, such as your personal preferences when you visit our site. This could be only showing you a popup once in your visit, or the ability to login to some of our features, such as forums.</p><p>We also use third party advertisements on %1$s to support our site. Some of these advertisers may use technology such as cookies and web beacons when they advertise on our site, which will also send these advertisers (such as Google through the Google AdSense program) information including your IP address, your ISP , the browser you used to visit our site, and in some cases, whether you have Flash installed. This is generally used for geotargeting purposes (showing New York real estate ads to someone in New York, for example) or showing certain ads based on specific sites visited (such as showing cooking ads to someone who frequents cooking sites).</p><h2>DoubleClick DART cookies</h2><p>We also may use DART cookies for ad serving through Google\'s DoubleClick, which places a cookie on your computer when you are browsing the web and visit a site using DoubleClick advertising (including some Google AdSense advertisements). This cookie is used to serve ads specific to you and your interests ("interest based targeting").</p><p>The ads served will be targeted based on your previous browsing history (For example, if you have been viewing sites about visiting Las Vegas, you may see Las Vegas hotel advertisements when viewing a non-related site, such as on a site about hockey). DART uses "non personally identifiable information". It does NOT track personal information about you, such as your name, email address, physical address, telephone number, social security numbers, bank account numbers or credit card numbers.</p><p>You can opt-out of this ad serving on all sites using this advertising by visiting http://www.doubleclick.com/privacy/dart_adserving.aspx</p><p>You can choose to disable or selectively turn off our cookies or third-party cookies in your browser settings, or by managing preferences in programs such as Norton Internet Security. However, this can affect how you are able to interact with our site as well as other websites. This could be the inability to login to services or programs, such as logging into forums or accounts.</p><p>Deleting cookies does not mean you are permanently opted out of any advertising program. Unless you have settings that disallow cookies, the next time you visit a site running the advertisements, a new cookie will be added.</p>', 'antlia-wp' ) ;
					}
					printf( $wpb_page_content, '<a href="'.home_url('/').'" rel="home">'.get_bloginfo('name').'</a>' );
					?>
				</div>

				<?php do_action( 'wpbisnis_entry_content_page_after' ); ?>
				
			</article>

			<?php do_action( 'wpbisnis_entry_page_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'wpbisnis_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php if ( ! wpbisnis_is_page_fullwidth() ) get_sidebar(); ?>
<?php get_footer(); ?>
