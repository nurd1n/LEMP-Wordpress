<?php
/**
 * Template Name: - Contact -
 *
 * @package  WPBisnis
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php do_action( 'wpbisnis_content_before' ); ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<?php do_action( 'wpbisnis_entry_page_before' ); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<header class="entry-header">
					<?php do_action( 'wpbisnis_entry_header_page_before' ); ?>
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
					<?php do_action( 'wpbisnis_entry_header_page_after' ); ?>
				</header>

				<?php do_action( 'wpbisnis_entry_content_page_before' ); ?>

				<div class="entry-content">
					<?php the_content(); ?>
					<?php echo wpbisnis_get_contact_form(); ?>
				</div>

				<?php do_action( 'wpbisnis_entry_content_page_after' ); ?>
				
			</article>

			<?php do_action( 'wpbisnis_entry_page_after' ); ?>

		<?php endwhile; ?>

		<?php do_action( 'wpbisnis_content_after' ); ?>

	<?php else : ?>

		<?php get_template_part( 'content', 'none' ); ?>

	<?php endif; ?>

	</main>
</div>

<?php if ( ! wpbisnis_is_page_fullwidth() ) get_sidebar(); ?>
<?php get_footer(); ?>
