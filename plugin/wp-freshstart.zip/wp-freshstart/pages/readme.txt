Available tags: 
[site_name]
[site_url]
[site_description]
[admin_email]

For the about page : 
[field1]
[field2]