<?php

function pmxi_json_to_xml( $json = array() ){	

	return PMXI_ArrayToXML::toXml($json);
	
}

