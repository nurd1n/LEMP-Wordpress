<div class="footer"><div class="footer-copy"> @ <?php echo date('Y'); ?> <?php echo $blog_title = get_bloginfo('name'); ?> - <?php echo get_bloginfo ( 'description' ); ?></div><div class="footer-menu"><?php wp_nav_menu( array('menu' => 'Footer' )); ?></div></div><?php wp_footer(); ?> 
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-8294690155778919",
    enable_page_level_ads: true
  });
</script>
</body></html>