<?php

add_action( 'customize_register', 'wpbisnis_semiwallpaper_customize_register' );
function wpbisnis_semiwallpaper_customize_register( $wp_customize ) {

  if ( ! isset( $wp_customize ) ) {
    return;
  }

  $wp_customize->add_panel(
    'semiwallpaper',
    array(
      'priority' 			=> 10,
      'capability' 		=> 'edit_theme_options',
      'theme_supports'	=> '',
      'title' 			=> __( 'Semi Wallpaper', 'wpbisnis' ),
      'description' 		=> '',
    )
  );

  $wp_customize->add_section(
		'semiwallpaper_single',
		array(
			'title'			=> __( 'Single Post Page', 'wpbisnis' ),
			'description'	=> '',
			'panel'			=> 'semiwallpaper'
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_image_linkto]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_image_linkto]',
    array(
      'settings'    => 'semiwallpaper[single_image_linkto]',
      'section'   => 'semiwallpaper_single',
      'type'      => 'select',
      'label'     => __( 'Image Link To', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'attachment' => 'Image Attachment Page', 'image' => 'Image URL (Lightbox)' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_image_loading]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_image_loading]',
    array(
      'settings'    => 'semiwallpaper[single_image_loading]',
      'section'   => 'semiwallpaper_single',
      'type'      => 'select',
      'label'     => __( 'Fixed/Random Image Loading', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'fixed' => 'fixed', 'random' => 'random' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_content_top_show]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_content_top_show]',
    array(
      'settings'    => 'semiwallpaper[single_content_top_show]',
      'section'   => 'semiwallpaper_single',
      'type'      => 'select',
      'label'     => __( 'Show Content Top', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_content_top]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_content_top]',
    array(
      'settings'    => 'semiwallpaper[single_content_top]',
      'section'   => 'semiwallpaper_single',
      'type'      => 'textarea',
      'label'     => __( 'Content Top', 'wpbisnis' ),
      'description' => 'You can use <strong>spintax</strong> (spin syntax).<br/> Available syntax: <code>%post_title%</code>, <code>%post_date%</code>, <code>%post_time%</code>, <code>%post_author%</code>, <code>%post_url%</code>, <code>%post_cats%</code>, <code>%post_tags%</code>, <code>%post_terms%</code>',
    )
  );

  $position = array(
    '' => __( 'None', 'wpbisnis' ),
    'top' => __( 'Top Content', 'wpbisnis' ),
    '1' => __( 'After 1st Paragraph', 'wpbisnis' ),
    '2' => __( 'After 2nd Paragraph', 'wpbisnis' ),
    '3' => __( 'After 3rd Paragraph', 'wpbisnis' ),
    '4' => __( 'After 4th Paragraph', 'wpbisnis' ),
    '5' => __( 'After 5th Paragraph', 'wpbisnis' ),
    '6' => __( 'After 6th Paragraph', 'wpbisnis' ),
    '7' => __( 'After 7th Paragraph', 'wpbisnis' ),
    '8' => __( 'After 8th Paragraph', 'wpbisnis' ),
    '9' => __( 'After 9th Paragraph', 'wpbisnis' ),
    '10' => __( 'After 10th Paragraph', 'wpbisnis' ),
    'bottom' => __( 'Bottom Content', 'wpbisnis' ),
  );

 //  $wp_customize->add_setting(
	// 	'semiwallpaper[single_image_featured]',
	// 	array(
	// 		'default'			=> '',
	// 		'type'				=> 'option',
	// 		'capability'		=> 'edit_theme_options',
	// 		// 'sanitize_callback'	=> ''
	// 	)
	// );
 //  $wp_customize->add_control(
 //    'semiwallpaper[single_image_featured]',
	// 	array(
	// 		'settings'		=> 'semiwallpaper[single_image_featured]',
	// 		'section'		=> 'semiwallpaper_single',
	// 		'type'			=> 'select',
	// 		'label'			=> __( 'Featured Image', 'wpbisnis' ),
	// 		'description'	=> '',
	// 		'choices'		=> $position,
	// 	)
	// );

  $wp_customize->add_setting(
		'semiwallpaper[single_image1]',
		array(
			'default'			=> '',
			'type'				=> 'option',
			'capability'		=> 'edit_theme_options',
			// 'sanitize_callback'	=> ''
		)
	);
  $wp_customize->add_control(
    'semiwallpaper[single_image1]',
		array(
			'settings'		=> 'semiwallpaper[single_image1]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'select',
			'label'			=> __( '1st Image', 'wpbisnis' ),
			'description'	=> '',
			'choices'		=> $position,
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_image2]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_image2]',
    array(
      'settings'		=> 'semiwallpaper[single_image2]',
      'section'		=> 'semiwallpaper_single',
      'type'			=> 'select',
      'label'			=> __( '2nd Image', 'wpbisnis' ),
      'description'	=> '',
      'choices'		=> $position,
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_image3]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_image3]',
    array(
      'settings'		=> 'semiwallpaper[single_image3]',
      'section'		=> 'semiwallpaper_single',
      'type'			=> 'select',
      'label'			=> __( '3rd Image', 'wpbisnis' ),
      'description'	=> '',
      'choices'		=> $position,
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_image4]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_image4]',
    array(
      'settings'		=> 'semiwallpaper[single_image4]',
      'section'		=> 'semiwallpaper_single',
      'type'			=> 'select',
      'label'			=> __( '4th Image', 'wpbisnis' ),
      'description'	=> '',
      'choices'		=> $position,
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_image5]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_image5]',
    array(
      'settings'		=> 'semiwallpaper[single_image5]',
      'section'		=> 'semiwallpaper_single',
      'type'			=> 'select',
      'label'			=> __( '5th Image', 'wpbisnis' ),
      'description'	=> '',
      'choices'		=> $position,
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_adsense1]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_adsense1]',
		array(
			'settings'		=> 'semiwallpaper[single_adsense1]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'select',
			'label'			=> __( '1st Adsense', 'wpbisnis' ),
			'description'	=> '',
      'choices'		=> $position,
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_adsense1_code]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_adsense1_code]',
		array(
			'settings'		=> 'semiwallpaper[single_adsense1_code]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'textarea',
			'label'			=> __( '1st Adsense Code', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_adsense2]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_adsense2]',
		array(
			'settings'		=> 'semiwallpaper[single_adsense2]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'select',
			'label'			=> __( '2nd Adsense', 'wpbisnis' ),
			'description'	=> '',
      'choices'		=> $position,
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_adsense2_code]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_adsense2_code]',
		array(
			'settings'		=> 'semiwallpaper[single_adsense2_code]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'textarea',
			'label'			=> __( '2st Adsense Code', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_adsense3]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_adsense3]',
		array(
			'settings'		=> 'semiwallpaper[single_adsense3]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'select',
			'label'			=> __( '3rd Adsense', 'wpbisnis' ),
			'description'	=> '',
      'choices'		=> $position,
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_adsense3_code]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_adsense3_code]',
		array(
			'settings'		=> 'semiwallpaper[single_adsense3_code]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'textarea',
			'label'			=> __( '3rd Adsense Code', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_content_bottom_show]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_content_bottom_show]',
    array(
      'settings'    => 'semiwallpaper[single_content_bottom_show]',
      'section'   => 'semiwallpaper_single',
      'type'      => 'select',
      'label'     => __( 'Show Content Bottom', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_content_bottom]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_content_bottom]',
    array(
      'settings'    => 'semiwallpaper[single_content_bottom]',
      'section'   => 'semiwallpaper_single',
      'type'      => 'textarea',
      'label'     => __( 'Content Bottom', 'wpbisnis' ),
      'description' => 'You can use <strong>spintax</strong> (spin syntax).<br/> Available syntax: <code>%post_title%</code>, <code>%post_date%</code>, <code>%post_time%</code>, <code>%post_author%</code>, <code>%post_url%</code>, <code>%post_cats%</code>, <code>%post_tags%</code>, <code>%post_terms%</code>',
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[single_gallery]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_gallery]',
		array(
			'settings'		=> 'semiwallpaper[single_gallery]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'select',
			'label'			=> __( 'Image Gallery', 'wpbisnis' ),
			'description'	=> '',
      'choices'		=> $position,
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[single_related]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[single_related]',
		array(
			'settings'		=> 'semiwallpaper[single_related]',
			'section'		=> 'semiwallpaper_single',
			'type'			=> 'select',
			'label'			=> __( 'Related Posts', 'wpbisnis' ),
			'description'	=> '',
      'choices'		=> $position,
		)
	);

  $wp_customize->add_section(
		'semiwallpaper_attachment',
		array(
			'title'			=> __( 'Image Attachment Page', 'wpbisnis' ),
			'description' => '<strong>NOTE:</strong><br/>To make this feature fully works for you, please <span style="color:red;">detele / rename <strong>attachment.php</strong> and <strong>image.php</strong> files</span> in your theme.',
			'panel'			=> 'semiwallpaper'
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_adsense1]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_adsense1]',
		array(
			'settings'		=> 'semiwallpaper[attachment_adsense1]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'textarea',
			'label'			=> __( 'Adsense Before Content', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_content_top_show]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_content_top_show]',
    array(
      'settings'    => 'semiwallpaper[attachment_content_top_show]',
      'section'   => 'semiwallpaper_attachment',
      'type'      => 'select',
      'label'     => __( 'Show Content Top', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'yes' => 'Yes', 'no' => 'No' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[attachment_content_top]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_content_top]',
		array(
			'settings'		=> 'semiwallpaper[attachment_content_top]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'textarea',
			'label'			=> __( 'Content Top', 'wpbisnis' ),
      'description' => 'You can use <strong>spintax</strong> (spin syntax).<br/> Available syntax: <code>%post_title%</code>, <code>%post_date%</code>, <code>%post_time%</code>, <code>%post_author%</code>, <code>%post_image%</code>, <code>%parent_title%</code>, <code>%parent_title%</code>, <code>%parent_url%</code>, <code>%parent_cats%</code>, <code>%parent_tags%</code>, <code>%parent_terms%</code>, <code>%parent_content_full%</code>, <code>%parent_content_summary%</code>, <code>%parent_content_random%</code>',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_adsense2]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_adsense2]',
		array(
			'settings'		=> 'semiwallpaper[attachment_adsense2]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'textarea',
			'label'			=> __( 'Adsense Before Image', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_image_show]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_image_show]',
    array(
      'settings'    => 'semiwallpaper[attachment_image_show]',
      'section'   => 'semiwallpaper_attachment',
      'type'      => 'select',
      'label'     => __( 'Show Image', 'wpbisnis' ),
      'description' => 'Sometimes, you want to keep your own <code>image.php</code> to output the image',
      'choices'   => array( 'yes' => 'Yes', 'no' => 'No' ),
    )
  );

  $wp_customize->add_setting(
		'semiwallpaper[attachment_image_linkto]',
		array(
			'default'			=> '',
			'type'				=> 'option',
			'capability'		=> 'edit_theme_options',
			// 'sanitize_callback'	=> ''
		)
	);
  $wp_customize->add_control(
    'semiwallpaper[attachment_image_linkto]',
		array(
			'settings'		=> 'semiwallpaper[attachment_image_linkto]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'select',
			'label'			=> __( 'Image Link To', 'wpbisnis' ),
			'description'	=> '',
			'choices'		=> array( '' => 'No Link', 'image' => 'Image URL', 'next' => 'Next Image' ),
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_adsense3]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_adsense3]',
		array(
			'settings'		=> 'semiwallpaper[attachment_adsense3]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'textarea',
			'label'			=> __( 'Adsense After Image', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_content_bottom_show]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_content_bottom_show]',
    array(
      'settings'    => 'semiwallpaper[attachment_content_bottom_show]',
      'section'   => 'semiwallpaper_attachment',
      'type'      => 'select',
      'label'     => __( 'Show Content Bottom', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'yes' => 'Yes', 'no' => 'No' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[attachment_content_bottom]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_content_bottom]',
		array(
			'settings'		=> 'semiwallpaper[attachment_content_bottom]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'textarea',
			'label'			=> __( 'Content Bottom', 'wpbisnis' ),
			'description'	=> 'You can use <strong>spintax</strong> (spin syntax).<br/> Available syntax: <code>%post_title%</code>, <code>%post_date%</code>, <code>%post_time%</code>, <code>%post_author%</code>, <code>%post_image%</code>, <code>%parent_title%</code>, <code>%parent_title%</code>, <code>%parent_url%</code>, <code>%parent_cats%</code>, <code>%parent_tags%</code>, <code>%parent_terms%</code>, <code>%parent_content_full%</code>, <code>%parent_content_summary%</code>, <code>%parent_content_random%</code>',
		)
	);

  $wp_customize->add_setting(
    'semiwallpaper[attachment_adsense4]',
    array(
      'default'			=> '',
      'type'				=> 'option',
      'capability'		=> 'edit_theme_options',
      // 'sanitize_callback'	=> ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[attachment_adsense4]',
		array(
			'settings'		=> 'semiwallpaper[attachment_adsense4]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'textarea',
			'label'			=> __( 'Adsense After Content', 'wpbisnis' ),
			'description'	=> '',
		)
	);

  $wp_customize->add_setting(
		'semiwallpaper[attachment_image_info]',
		array(
			'default'			=> '',
			'type'				=> 'option',
			'capability'		=> 'edit_theme_options',
			// 'sanitize_callback'	=> ''
		)
	);
  $wp_customize->add_control(
    'semiwallpaper[attachment_image_info]',
		array(
			'settings'		=> 'semiwallpaper[attachment_image_info]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'select',
			'label'			=> __( 'Image Info', 'wpbisnis' ),
			'description'	=> '',
      'choices'		=> array( 'yes' => 'Yes', 'no' => 'No' ),
		)
	);

  $wp_customize->add_setting(
		'semiwallpaper[attachment_backto]',
		array(
			'default'			=> '',
			'type'				=> 'option',
			'capability'		=> 'edit_theme_options',
			// 'sanitize_callback'	=> ''
		)
	);
  $wp_customize->add_control(
    'semiwallpaper[attachment_backto]',
		array(
			'settings'		=> 'semiwallpaper[attachment_backto]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'select',
			'label'			=> __( 'Show Back To Article Link', 'wpbisnis' ),
			'description'	=> '',
			'choices'		=> array( 'yes' => 'Yes', 'no' => 'No' ),
		)
	);

  $wp_customize->add_setting(
		'semiwallpaper[attachment_gallery]',
		array(
			'default'			=> '',
			'type'				=> 'option',
			'capability'		=> 'edit_theme_options',
			// 'sanitize_callback'	=> ''
		)
	);
  $wp_customize->add_control(
    'semiwallpaper[attachment_gallery]',
		array(
			'settings'		=> 'semiwallpaper[attachment_gallery]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'select',
			'label'			=> __( 'Show Gallery After Content', 'wpbisnis' ),
			'description'	=> '',
			'choices'		=> array( 'yes' => 'Yes', 'no' => 'No' ),
		)
	);

  $wp_customize->add_setting(
		'semiwallpaper[attachment_related]',
		array(
			'default'			=> '',
			'type'				=> 'option',
			'capability'		=> 'edit_theme_options',
			// 'sanitize_callback'	=> ''
		)
	);
  $wp_customize->add_control(
    'semiwallpaper[attachment_related]',
		array(
			'settings'		=> 'semiwallpaper[attachment_related]',
			'section'		=> 'semiwallpaper_attachment',
			'type'			=> 'select',
			'label'			=> __( 'Show Related Posts After Content', 'wpbisnis' ),
			'description'	=> '',
			'choices'		=> array( 'yes' => 'Yes', 'no' => 'No' ),
		)
	);

  $wp_customize->add_section(
    'semiwallpaper_archive',
    array(
      'title'     => __( 'Homepage / Archive Page [BETA]', 'wpbisnis' ),
      'description' => '<strong>NOTE:<br/><span style="color:red;">Not all themes are compatible with this feature.</span></strong> If your homepage / blog / archive page show "full content", then this feature should works for you.',
      'panel'     => 'semiwallpaper'
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_image]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_image]',
    array(
      'settings'    => 'semiwallpaper[archive_image]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( 'Show Image Before Content', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_image_linkto]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_image_linkto]',
    array(
      'settings'    => 'semiwallpaper[archive_image_linkto]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( 'Image Before Content Link To', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'post' => 'Single Post Page', 'attachment' => 'Image Attachment Page' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_paragraph]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_paragraph]',
    array(
      'settings'    => 'semiwallpaper[archive_paragraph]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( 'Number of Paragraphs to Show', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( '' => 'Default', '1' => '1', '2' => '2', '3' => '3' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_gallery]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_gallery]',
    array(
      'settings'    => 'semiwallpaper[archive_gallery]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( 'Show Gallery After Content', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes (1 Row)' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_gallery_linkto]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_gallery_linkto]',
    array(
      'settings'    => 'semiwallpaper[archive_gallery_linkto]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( 'Gallery After Content Link To', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'attachment' => 'Image Attachment Page', 'post' => 'Single Post Page' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_continue]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_continue]',
    array(
      'settings'    => 'semiwallpaper[archive_continue]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( 'Show Continue Reading Link', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_adsense_code]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_adsense_code]',
    array(
      'settings'    => 'semiwallpaper[archive_adsense_code]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'textarea',
      'label'     => __( 'Adsense Code', 'wpbisnis' ),
      'description' => '',
    )
  );

  $position = array(
    '' => __( 'None', 'wpbisnis' ),
    '1' => __( 'After 1st post content', 'wpbisnis' ),
    '2' => __( 'After 2nd post content', 'wpbisnis' ),
    '3' => __( 'After 3rd post content', 'wpbisnis' ),
    '4' => __( 'After 4th post content', 'wpbisnis' ),
    '5' => __( 'After 5th post content', 'wpbisnis' ),
    '6' => __( 'After 6th post content', 'wpbisnis' ),
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_adsense1]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_adsense1]',
    array(
      'settings'    => 'semiwallpaper[archive_adsense1]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( '1st Adsense Position', 'wpbisnis' ),
      'description' => '',
      'choices'   => $position,
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_adsense2]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_adsense2]',
    array(
      'settings'    => 'semiwallpaper[archive_adsense2]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( '2nd Adsense Position', 'wpbisnis' ),
      'description' => '',
      'choices'   => $position,
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[archive_adsense3]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[archive_adsense3]',
    array(
      'settings'    => 'semiwallpaper[archive_adsense3]',
      'section'   => 'semiwallpaper_archive',
      'type'      => 'select',
      'label'     => __( '3rd Adsense Position', 'wpbisnis' ),
      'description' => '',
      'choices'   => $position,
    )
  );

  $wp_customize->add_section(
    'semiwallpaper_style',
    array(
      'title'     => __( 'Style', 'wpbisnis' ),
      'description' => '',
      'panel'     => 'semiwallpaper'
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[style_gallery_columns]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[style_gallery_columns]',
    array(
      'settings'    => 'semiwallpaper[style_gallery_columns]',
      'section'   => 'semiwallpaper_style',
      'type'      => 'select',
      'label'     => __( 'Image Gallery Columns', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( '4' => '4 Columns', '5' => '5 Columns', '6' => '6 Columns' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[style_image_border]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[style_image_border]',
    array(
      'settings'    => 'semiwallpaper[style_image_border]',
      'section'   => 'semiwallpaper_style',
      'type'      => 'select',
      'label'     => __( 'Single Image Border', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[style_image_border_color]', 
    array(
      'default'           => '',
      'type'           => 'option',
      'capability'        => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
  );
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 
    'semiwallpaper[style_image_border_color]', 
    array(
      'settings' => 'semiwallpaper[style_image_border_color]',
      'section'  => 'semiwallpaper_style',
      'label'    => __('Single Image Border Color', 'wpbisnis'),
    )
  ));

  $wp_customize->add_setting(
    'semiwallpaper[style_thumbnail_border]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[style_thumbnail_border]',
    array(
      'settings'    => 'semiwallpaper[style_thumbnail_border]',
      'section'   => 'semiwallpaper_style',
      'type'      => 'select',
      'label'     => __( 'Thumbnail Border', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[style_thumbnail_border_color]', 
    array(
      'default'           => '',
      'type'           => 'option',
      'capability'        => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
  );
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 
    'semiwallpaper[style_thumbnail_border_color]', 
    array(
      'settings' => 'semiwallpaper[style_thumbnail_border_color]',
      'section'  => 'semiwallpaper_style',
      'label'    => __('Thumbnail Border Color', 'wpbisnis'),
    )
  ));

  $wp_customize->add_setting(
    'semiwallpaper[style_widget_border]',
    array(
      'default'     => '',
      'type'        => 'option',
      'capability'    => 'edit_theme_options',
      // 'sanitize_callback'  => ''
    )
  );
  $wp_customize->add_control(
    'semiwallpaper[style_widget_border]',
    array(
      'settings'    => 'semiwallpaper[style_widget_border]',
      'section'   => 'semiwallpaper_style',
      'type'      => 'select',
      'label'     => __( 'Widget Border', 'wpbisnis' ),
      'description' => '',
      'choices'   => array( 'no' => 'No', 'yes' => 'Yes' ),
    )
  );

  $wp_customize->add_setting(
    'semiwallpaper[style_widget_border_color]', 
    array(
      'default'           => '',
      'type'           => 'option',
      'capability'        => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
  );
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 
    'semiwallpaper[style_widget_border_color]', 
    array(
      'settings' => 'semiwallpaper[style_widget_border_color]',
      'section'  => 'semiwallpaper_style',
      'label'    => __('Widget Border Color', 'wpbisnis'),
    )
  ));

}
