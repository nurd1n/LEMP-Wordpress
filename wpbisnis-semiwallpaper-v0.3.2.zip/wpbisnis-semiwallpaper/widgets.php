<?php

function wpbisnis_semiwallpaper_widgets_init() {
	register_widget('WPBisnis_Semiwallpaper_Images_Widget');
}
add_action('widgets_init', 'wpbisnis_semiwallpaper_widgets_init');

class WPBisnis_Semiwallpaper_Images_Widget extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget-images', 'description' => __( "Your site&#8217;s random images.", 'wpbisnis') );
		parent::__construct('widget-sw-images', __(':: Semiwallpaper Images ::', 'wpbisnis'), $widget_ops);
		$this->alt_option_name = 'widget-sw-images';

		add_action( 'save_post', array($this, 'flush_widget_cache') );
		add_action( 'deleted_post', array($this, 'flush_widget_cache') );
		add_action( 'switch_theme', array($this, 'flush_widget_cache') );
	}

	public function widget($args, $instance) {
		$cache = array();
		if ( ! $this->is_preview() ) {
			$cache = wp_cache_get( 'wpbisnis_semiwallpaper_images', 'widget' );
		}

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo wp_kses_post( $cache[ $args['widget_id'] ] );
			return;
		}

		ob_start();

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Images', 'wpbisnis' );

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 4;
		if ( ! $number )
			$number = 4;

		$orderby = ( ! empty( $instance['orderby'] ) && in_array( $instance['orderby'], array( 'rand', 'date' ) ) ) ? $instance['orderby'] : 'rand';

		$linkto = ( ! empty( $instance['linkto'] ) && in_array( $instance['linkto'], array( 'post', 'attachment' ) ) ) ? $instance['linkto'] : 'post';

		$type = ( ! empty( $instance['type'] ) && in_array( $instance['type'], array( '1c', '1ct', '2c' ) ) ) ? $instance['type'] : '1c';

		$image_size = $type == '2c' ? 'thumbnail' : 'full';

		$r = new WP_Query( array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'orderby'         	  => $orderby,
			'ignore_sticky_posts' => true,
		) );

		if ($r->have_posts()) :
		?>
		<?php printf( '%s', $args['before_widget'] ); ?>
		<?php if ( $title ) {
			printf( '%s', $args['before_title'] . $title . $args['after_title'] );
		} ?>
		<ul class="widget-images-<?php echo $type; ?>">
		<?php while ( $r->have_posts() ) : $r->the_post(); ?>
			<?php
			global $post;
			$id = 0;
			if ( has_post_thumbnail() ) {
				$id = get_post_thumbnail_id();
			}
			//* Else if first-attached, pull the first (default) image attachment
			else {
				$image_ids = array_keys(
					get_children(
						array(
							'post_parent'    => $post->ID,
							'post_type'	     => 'attachment',
							'post_mime_type' => 'image',
							'orderby'        => 'menu_order',
							'order'	         => 'ASC',
						)
					)
				);
				if ( isset( $image_ids[0] ) )
					$id = $image_ids[0];
			}
			if ( $id ) {
				$image = wp_get_attachment_image( $id, $image_size, false );
				if ( $image ) {
					?>
					<li>
						<span class="widget-image">
							<a href="<?php echo ( $linkto == 'attachment' ? get_permalink($id) : get_permalink() ); ?>" title="">
								<?php echo $image; ?>
							</a>
						</span>
						<?php if ( $type == '1ct' ) : ?>
							<a class="widget-image-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<?php endif; ?>
					</li>
					<?php
				}
			}
			?>
		<?php endwhile; ?>
		</ul>
		<?php printf( '%s', $args['after_widget'] ); ?>
		<?php
		// Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();

		endif;

		if ( ! $this->is_preview() ) {
			$cache[ $args['widget_id'] ] = ob_get_flush();
			wp_cache_set( 'wpbisnis_semiwallpaper_images', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
		if ( in_array( $new_instance['orderby'], array( 'rand', 'date' ) ) ) {
			$instance['orderby'] = $new_instance['orderby'];
		} else {
			$instance['orderby'] = 'rand';
		}
		if ( in_array( $new_instance['linkto'], array( 'post', 'attachment' ) ) ) {
			$instance['linkto'] = $new_instance['linkto'];
		} else {
			$instance['linkto'] = 'post';
		}
		if ( in_array( $new_instance['type'], array( '1c', '1ct', '2c' ) ) ) {
			$instance['type'] = $new_instance['type'];
		} else {
			$instance['type'] = '1c';
		}
		$this->flush_widget_cache();

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['wpbisnis_semiwallpaper_images']) )
			delete_option('wpbisnis_semiwallpaper_images');

		return $instance;
	}

	public function flush_widget_cache() {
		wp_cache_delete('wpbisnis_semiwallpaper_images', 'widget');
	}

	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 4;
?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Title:', 'wpbisnis' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php _e( 'Number of posts (images) to show:', 'wpbisnis' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('orderby'); ?>"><?php _e( 'Order By:' ); ?></label>
			<select name="<?php echo $this->get_field_name('orderby'); ?>" id="<?php echo $this->get_field_id('orderby'); ?>" class="widefat">
				<option value="rand"<?php selected( $instance['orderby'], 'rand' ); ?>><?php _e( 'Random Posts' ); ?></option>
				<option value="date"<?php selected( $instance['orderby'], 'date' ); ?>><?php _e( 'Recent Posts' ); ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('linkto'); ?>"><?php _e( 'Link Image To:' ); ?></label>
			<select name="<?php echo $this->get_field_name('linkto'); ?>" id="<?php echo $this->get_field_id('linkto'); ?>" class="widefat">
				<option value="post"<?php selected( $instance['linkto'], 'post' ); ?>><?php _e( 'Single Post Page' ); ?></option>
				<option value="attachment"<?php selected( $instance['linkto'], 'attachment' ); ?>><?php _e( 'Image Attachment Page' ); ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('type'); ?>"><?php _e( 'Type:' ); ?></label>
			<select name="<?php echo $this->get_field_name('type'); ?>" id="<?php echo $this->get_field_id('type'); ?>" class="widefat">
				<option value="1c"<?php selected( $instance['type'], '1c' ); ?>><?php _e( '1 Column (Full Size)' ); ?></option>
				<option value="1ct"<?php selected( $instance['type'], '1ct' ); ?>><?php _e( '1 Column (Full Size) + Title' ); ?></option>
				<option value="2c"<?php selected( $instance['type'], '2c' ); ?>><?php _e( '2 Columns (Thumbnail)' ); ?></option>
			</select>
		</p>

<?php
	}
}

