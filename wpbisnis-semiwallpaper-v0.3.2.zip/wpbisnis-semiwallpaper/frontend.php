<?php

function get_semiwallpaper_option( $name, $default = false ) {
	$options = get_option( 'semiwallpaper' );
	if ( isset( $options[$name] ) )
		return $options[$name];

	return $default;
}

add_action( 'wp_enqueue_scripts', 'wpbisnis_semiwallpaper_scripts' );
function wpbisnis_semiwallpaper_scripts() {
	if ( is_singular('post') && get_semiwallpaper_option( 'single_image_linkto' ) == 'image' ) {
		$lightbox = true;
	}
	elseif ( is_singular('attachment') && get_semiwallpaper_option( 'attachment_image_linkto' ) == 'image' ) {
		$lightbox = true;
	}
	else {
		$lightbox = false;
	}
	if ( !$lightbox )
		return;

	wp_enqueue_style( 'magnific-popup-css', plugins_url( 'assets/magnific-popup.css', __FILE__ ) );
	wp_enqueue_script( 'magnific-popup', plugins_url( 'assets/jquery.magnific-popup.min.js', __FILE__ ), array('jquery'), '1.0.0', true );
}

add_action( 'wp_head', 'wpbisnis_semiwallpaper_head_style' );
function wpbisnis_semiwallpaper_head_style() {
	echo '<style>';
	echo 'img{max-width:100%;height:auto}';
	$image_style = '';
	if ( get_semiwallpaper_option('style_image_border') == 'yes' ) {
		$image_border = get_semiwallpaper_option('style_image_border_color');
		if ( !trim( $image_border) )
			$image_border = '#ddd';
		$image_style = 'border:1px solid '.$image_border.';padding:4px;';
	}
	echo '.entry-image-single{'.$image_style.';-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;}';
	echo '.entry-image-gallery{margin:0 -5px;box-sizing:border-box}';
	echo '.entry-image-gallery p:before,.entry-image-gallery p:after{content: " ";display: table}';
	echo '.entry-image-gallery p:after{clear: both}';
	$gallery_columns = intval( get_semiwallpaper_option( 'style_gallery_columns' ) );
	if ( $gallery_columns == 5 ) {
		$gallery_width = '20%';
	}
	elseif ( $gallery_columns == 6 ) {
		$gallery_width = '16.666666667%';
	}
	else {
		$gallery_width = '25%';
	}
	echo '.entry-image-gallery .image-thumbnail{display:block;padding:5px;width:'.$gallery_width.';float:left;box-sizing:border-box}';
	echo '.entry-image-gallery .image-thumbnail a{display:block;line-height:0}';
	$thumbnail_style = '';
	if ( get_semiwallpaper_option('style_thumbnail_border') == 'yes' ) {
		$thumbnail_border = get_semiwallpaper_option('style_thumbnail_border_color');
		if ( !trim( $thumbnail_border) )
			$thumbnail_border = '#ddd';
		$thumbnail_style = 'border:1px solid '.$thumbnail_border.';padding:3px;';
	}
	echo '.entry-image-gallery .image-thumbnail img{width:100%;'.$thumbnail_style.';-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;}';
	echo '.entry-related-post:before,.entry-related-post:after{content: " ";display: table}';
	echo '.entry-related-post:after{clear: both;}';
	echo '.entry-related-post h4{margin:0;clear:none;}';
	if ( $thumbnail_style )
		echo '.entry-related-post img{'.$thumbnail_style.'}';
	echo '.entry-related-post img.alignleft{float:left;margin:0 20px 15px 0}';
	echo '.entry-image-info{background:#fff}';
	echo '.entry-image-info th,.entry-image-info td{border:1px solid #ededed;padding:6px 10px;word-wrap:break-word}';
	echo '.entry-image-info th{width:30%}';
	echo '.widget-images ul,.widget-images li{list-style:none;padding:0;margin:0;border:none;}';
	echo '.widget-images ul.widget-images-2c:before,.widget-images ul.widget-images-2c:after{display:table;content:" ";}.widget-images ul.widget-images-2c:after{clear:both;}';
	echo '.widget-images ul.widget-images-2c{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;margin:0 -5px;}';
	echo '.widget-images .widget-image{text-align:center;display:block;line-height:1px;padding:5px 0;}';
	echo '.widget-images ul.widget-images-2c .widget-image{width:50%;float:left;padding:5px;}';
	echo '.widget-images ul.widget-images-1c .widget-image{}';
	echo '.widget-images .widget-image a{display:inline-block; max-width:100%;}';
	echo '.widget-images .widget-image-title{display:block;padding-bottom:10px;}';
	echo '.admin-bar .mfp-close { top: 32px !important; }';
	$widget_image_style = '';
	if ( get_semiwallpaper_option('style_widget_border') == 'yes' ) {
		$widget_image_border = get_semiwallpaper_option('style_widget_border_color');
		if ( !trim( $widget_image_border) )
			$widget_image_border = '#ddd';
		$widget_image_style = 'border:1px solid '.$widget_image_border.';padding:3px;';
	}
	if ( $widget_image_style )
		echo '.widget-images .widget-image img{'.$widget_image_style.';-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;}';

	echo '</style>';
}

add_action( 'wp_head', 'wpbisnis_semiwallpaper_footer_script' );
function wpbisnis_semiwallpaper_footer_script() {
	if ( is_singular('post') && get_semiwallpaper_option( 'single_image_linkto' ) == 'image' ) {
		$lightbox = true;
	}
	elseif ( is_singular('attachment') && get_semiwallpaper_option( 'attachment_image_linkto' ) == 'image' ) {
		$lightbox = true;
	}
	else {
		$lightbox = false;
	}
	if ( !$lightbox )
		return;
?>
<script type="text/javascript">
jQuery(document).ready(function($) {

	$('.entry-image-lightbox').magnificPopup({
		delegate: 'a',
		type: 'image',
		closeOnContentClick: true,
		closeBtnInside: false,
		image: {
			verticalFit: true
		}
	});

	$('.entry-gallery-lightbox').magnificPopup({
		delegate: 'a',
		type: 'image',
		closeOnContentClick: true,
		closeBtnInside: false,
		gallery: {
			enabled: true
		},
		image: {
			verticalFit: true
		}
	});

});
</script>
<?php
}

add_filter( 'the_content', 'wpbisnis_semiwallpaper_content_archive', 10 );
function wpbisnis_semiwallpaper_content_archive( $content ) {

	global $semiwallpaper_count;
	$semiwallpaper_count = $semiwallpaper_count + 1;

	/* Debug formatted content */
	// echo '<pre>'; echo esc_html( $content ); echo '</pre>';

	global $post;

	/* Debug post object */
	// echo '<pre>'; var_dump( $post ); echo '</pre>';

	$post_id 		= $post->ID;
	$post_type 		= $post->post_type;
	$post_parent_id	= $post->post_parent;

    if ( $post_type != 'post' )
		return $content;

    if ( is_single() )
		return $content;

    if ( is_page() )
		return $content;

	if ( !is_main_query() ) 
		return $content;

	$number_par = intval( get_semiwallpaper_option( 'archive_paragraph' ) );
	if ( $number_par > 0 ) {
	    $content_p = wpautop( $post->post_content );
	    $closing_p = '</p>';
		$paragraphs = wpbisnis_semiwallpaper_clean_post_content( $post_id );
	    if ( count( $paragraphs ) > $number_par ) {
		    if ( $number_par == 1 )
		    	$content = $paragraphs[0];
		    elseif ( $number_par == 2 )
		    	$content = $paragraphs[0].$paragraphs[1];
		    elseif ( $number_par == 3 )
		    	$content = $paragraphs[0].$paragraphs[1].$paragraphs[2];
	    }
	}

	if ( get_semiwallpaper_option( 'archive_image' ) == 'yes' ) {
	 	$linkto = get_semiwallpaper_option( 'archive_image_linkto' );
		$content = wpbisnis_semiwallpaper_thumbnail( 'full', 'entry-image-single', $linkto, '<p>', '</p>' ) . $content;
	}

	if ( get_semiwallpaper_option( 'archive_gallery' ) == 'yes' ) {
		$image_columns = intval( get_semiwallpaper_option( 'style_gallery_columns' ) );
		if ( !in_array( $image_columns, array( 4, 5, 6 ) ) ) {
			$image_columns = 4;
		}
	 	$linkto = get_semiwallpaper_option( 'archive_gallery_linkto' );
		$content .= wpbisnis_semiwallpaper_post_galleries( $post_id, false, $image_columns, 'rand', $linkto );
	}

	if ( get_semiwallpaper_option( 'archive_continue' ) == 'yes' ) {
		$content .= sprintf( '<p><a href="%s" title="%s">Continue reading "%s"...</a></p>', get_permalink(), the_title_attribute('echo=0'), get_the_title() );
	}

	$ad_code = get_semiwallpaper_option( 'archive_adsense_code' );
	for ($i=1; $i <= 3; $i++) { 
		$ad_pos = get_semiwallpaper_option( 'archive_adsense'.$i );
		if( intval( $ad_pos ) > 0 ) {
			if ( intval( $ad_pos ) == $semiwallpaper_count ) {
	            $content .= '<p><!--noptimize-->'.$ad_code.'<!--/noptimize--></p>';
			}
		}
	}

	return $content;
}

add_filter( 'the_content', 'wpbisnis_semiwallpaper_content_single', 10 );
function wpbisnis_semiwallpaper_content_single( $content ) {

	/* Debug formatted content */
	// echo '<pre>'; echo esc_html( $content ); echo '</pre>';

	global $post;

	/* Debug post object */
	// echo '<pre>'; var_dump( $post ); echo '</pre>';

	$post_id 		= $post->ID;
	$post_type 		= $post->post_type;
	$post_parent_id	= $post->post_parent;

    if ( $post_type != 'post' )
		return $content;

    if ( !is_singular('post') )
		return $content;

	if ( !is_main_query() ) 
		return $content;

	$post_thumbnail_id = get_post_thumbnail_id();

	/* Debug post thumbnail */
	// echo '<pre>'; var_dump( $post_thumbnail_id ); echo '</pre>';

	$image_loading = get_semiwallpaper_option( 'single_image_loading' );
	$image_orderby = $image_loading == 'random' ? 'rand' : 'menu_order';

	$image_linkto = get_semiwallpaper_option( 'single_image_linkto' );

	/* Debug image_orderby */
	// echo '<pre>'; var_dump( $image_orderby ); echo '</pre>';

	$images = get_children(
		array(
			'post_parent'    => $post_id,
			'post_type'	     => 'attachment',
			'post_mime_type' => 'image',
			'orderby'        => $image_orderby,
			'order'	         => 'ASC',
		)
	);
	$images_id = !empty( $images ) ? array_keys( $images ) : array();

	/* Debug attached images */
	// echo '<pre>'; var_dump( $images ); echo '</pre>';

	$content = str_replace( '<p>&nbsp;</p>', '', $content );

	$content_top = '';
	$content_bottom = '';

	if ( get_semiwallpaper_option( 'single_content_top_show' ) == 'yes' && get_semiwallpaper_option( 'single_content_top' ) ) {
		$content_top .= wpbisnis_semiwallpaper_single_content( get_semiwallpaper_option( 'single_content_top' ) );
	}

    $closing_p = '</p>';
    $paragraphs = explode( $closing_p, $content );
    foreach ($paragraphs as $index => $paragraph) {
        if ( trim( $paragraph ) ) {
            $paragraphs[$index] .= $closing_p;
        }
    }

	/* Debug paragraphs */
	// echo '<pre>'; var_dump( $paragraphs ); echo '</pre>';

	for ($i=0; $i < 5; $i++) { 
		$j=$i+1;
		$option = get_semiwallpaper_option( 'single_image'.$j );
		if ( $option && isset( $images_id[$i] ) ) {
			$img_id = $images_id[$i];
			$img_title = esc_attr( wpbisnis_semiwallpaper_format_title( $images[$img_id]->post_title ) );
			$img_html = wp_get_attachment_image( $img_id, 'full', false, array( 'class' => 'entry-image-single', 'alt' => $img_title ) );
			if ( $img_html ) {
				if ( $image_linkto == 'image' ) {
					$img_src = wp_get_attachment_image_src( $img_id, 'full' );
					$img_link = $img_src[0];
				}
				else {
					$img_link = get_permalink( $img_id );
				}
				if ( $image_linkto == 'image' ) {
					$img_out = sprintf( '<p class="entry-image-lightbox"><a href="%s" title="%s">%s</a></p>', $img_link, $img_title, $img_html );
				}
				else {
					$img_out = sprintf( '<p><a href="%s" title="%s">%s</a></p>', $img_link, $img_title, $img_html );
				}
				if ( $option == 'top' ) {
					$content_top .= $img_out;
				}
				elseif ( $option == 'bottom' ) {
					$content_bottom .= $img_out;
				}
				elseif( intval( $option ) > 0 ) {
					$img_par = intval( $option ) - 1;
					if ( isset( $paragraphs[$img_par] ) ) {
			            $paragraphs[$img_par] .= $img_out;
					}
				}
			}
		}
	}

	for ($i=1; $i <= 3; $i++) { 
		$ad_pos = get_semiwallpaper_option( 'single_adsense'.$i );
		$ad_code = get_semiwallpaper_option( 'single_adsense'.$i.'_code' );
		if ( $ad_pos && $ad_code ) {
			if ( $ad_pos == 'top' ) {
				$content_top .= '<p><!--noptimize-->'.$ad_code.'<!--/noptimize--></p>';
			}
			elseif ( $ad_pos == 'bottom' ) {
				$content_bottom .= '<p><!--noptimize-->'.$ad_code.'<!--/noptimize--></p>';
			}
			elseif( intval( $ad_pos ) > 0 ) {
				$ad_par = intval( $ad_pos ) - 1;
				if ( isset( $paragraphs[$ad_par] ) ) {
		            $paragraphs[$ad_par] .= '<p><!--noptimize-->'.$ad_code.'<!--/noptimize--></p>';
				}
			}
		}
	}

	if ( get_semiwallpaper_option( 'single_content_bottom_show' ) == 'yes' && get_semiwallpaper_option( 'single_content_bottom' ) ) {
		$content_bottom .= wpbisnis_semiwallpaper_single_content( get_semiwallpaper_option( 'single_content_bottom' ) );
	}

	$gallery = get_semiwallpaper_option( 'single_gallery' );
	if ( $gallery && !empty( $images_id ) ) {
		if ( $gallery == 'top' ) {
			if ( $image_linkto == 'image' )
				$content_top .= '<div class="entry-gallery-lightbox">';
			$content_top .= wpbisnis_semiwallpaper_post_galleries( $post_id, true, '-1', $image_orderby, $image_linkto );
			if ( $image_linkto == 'image' )
				$content_top .= '</div>';
		}
		elseif ( $gallery == 'bottom' ) {
			if ( $image_linkto == 'image' )
				$content_bottom .= '<div class="entry-gallery-lightbox">';
			$content_bottom .= wpbisnis_semiwallpaper_post_galleries( $post_id, true, '-1', $image_orderby, $image_linkto );
			if ( $image_linkto == 'image' )
				$content_bottom .= '</div>';
		}
		elseif( intval( $gallery ) > 0 ) {
			$gallery_par = intval( $gallery ) - 1;
			if ( isset( $paragraphs[$gallery_par] ) ) {
				if ( $image_linkto == 'image' )
					$paragraphs[$gallery_par] .= '<div class="entry-gallery-lightbox">';
	            $paragraphs[$gallery_par] .= wpbisnis_semiwallpaper_post_galleries( $post_id, false, '-1', $image_orderby, $image_linkto );
				if ( $image_linkto == 'image' )
					$paragraphs[$gallery_par] .= '</div>';
			}
		}
	}

	$related = get_semiwallpaper_option( 'single_related' );
	if ( $related ) {
		if ( $related == 'top' ) {
			$content_top .= wpbisnis_semiwallpaper_related_posts( $post_id, true );
		}
		elseif ( $related == 'bottom' ) {
			$content_bottom .= wpbisnis_semiwallpaper_related_posts( $post_id, true );
		}
		elseif( intval( $related ) > 0 ) {
			$related_par = intval( $related_par ) - 1;
			if ( isset( $paragraphs[$related_par] ) ) {
	            $paragraphs[$related_par] .= wpbisnis_semiwallpaper_related_posts( $post_id, false );
			}
		}
	}

	/* Debug content top & bottom */
	// echo '<pre>'; echo esc_html( $content_top ); echo '</pre>';
	// echo '<pre>'; echo esc_html( $content_bottom ); echo '</pre>';

    $content = $content_top . implode( '', $paragraphs ) . $content_bottom;

	return $content;
}

add_filter( 'the_content', 'wpbisnis_semiwallpaper_content_attachment', 10 );
function wpbisnis_semiwallpaper_content_attachment( $content ) {

	/* Debug formatted content */
	// echo '<pre>'; echo esc_html( $content ); echo '</pre>';

	global $post;

	/* Debug post object */
	// echo '<pre>'; var_dump( $post ); echo '</pre>';

	$post_id 		= $post->ID;
	$post_type 		= $post->post_type;
	$post_parent_id	= $post->post_parent;

    if ( $post_type != 'attachment' )
		return $content;

    if ( !is_singular('attachment') )
		return $content;

	if ( !is_main_query() ) 
		return $content;

	$mime = get_post_mime_type();
	if ( strpos( $mime, 'image' ) === false)
		return;

	$content_before = '';

	$adsense1 = get_semiwallpaper_option( 'attachment_adsense1' );
	if ( trim($adsense1) )
		$content_before .= '<p><!--noptimize-->'.$adsense1.'<!--/noptimize--></p>';

	if ( get_semiwallpaper_option( 'attachment_content_top_show' ) != 'no' ) {
		$content_top = get_semiwallpaper_option( 'attachment_content_top' );
		if ( !$content_top ) {
			$content_top = 'The {amazing|amusing|appealing|astonishing|astounding|awesome|breathtaking|captivating|charming|cool|enchanting|excellent|exciting|extraordinary|fascinating|glamorous|inspiring|interesting|marvellous|marvelous|mesmerizing|outstanding|remarkable|stunning|surprising|terrific|wonderful} %post_title% {photo|picture|pics|photograph|digital imagery|digital photography|image|images} below, is {part|segment|section|other parts} of %parent_title% {article|document|post|publishing|piece of writing|content|written piece|editorial|report|write-up} which is {categorized|classified|grouped|sorted|labeled|listed|categorised|classed as|arranged|assigned} within %parent_terms% and {published|posted} at %post_date%.';
		}
		$content_top = wpbisnis_semiwallpaper_attachment_content( $content_top );
		$content_before .= $content_top;
	}

	$adsense2 = get_semiwallpaper_option( 'attachment_adsense2' );
	if ( trim($adsense2) )
		$content_before .= '<p><!--noptimize-->'.$adsense2.'<!--/noptimize--></p>';

	$img_id = $post_id;
	if ( get_semiwallpaper_option( 'attachment_image_show' ) != 'no' ) {
		$img_title = esc_attr( get_the_title() );
		$img_html = wp_get_attachment_image( $post_id, 'full', false, array( 'class' => 'entry-image-single', 'alt' => $img_title ) );
		if ( $img_html ) {
			$img_linkto = get_semiwallpaper_option( 'attachment_image_linkto' );
			if ( $img_linkto == 'image') {
				$image_attributes = wp_get_attachment_image_src( $img_id, 'full' );
				if( $image_attributes )
					$img_out = '<p class="entry-image-lightbox"><a href="'.$image_attributes[0].'" title="'.$img_title.'">'.$img_html.'</a></p>';
			}
			elseif ( $img_linkto == 'next') {
				/*
				 * Grab the IDs of all the image attachments in a gallery so we can get the URL of the next adjacent image in a gallery,
				 * or the first image (if we're looking at the last image in a gallery), or, in a gallery of one, just the link to that image file
				 */
				$attachments = array_values( get_children( array( 'post_parent' => $post->post_parent, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID' ) ) );
				foreach ( $attachments as $k => $attachment ) :
					if ( $attachment->ID == $post->ID )
						break;
				endforeach;

				// If there is more than 1 attachment in a gallery
				if ( count( $attachments ) > 1 ) :
					$k++;
					if ( isset( $attachments[ $k ] ) ) :
						// get the URL of the next image attachment
						$next_attachment_url = get_attachment_link( $attachments[ $k ]->ID );
					else :
						// or get the URL of the first image attachment
						$next_attachment_url = get_attachment_link( $attachments[0]->ID );
					endif;
				else :
					// or, if there's only 1 image, get the URL of the image
					$next_attachment_url = wp_get_attachment_url();
				endif;

				$img_out = '<p><a href="'.$next_attachment_url.'" title="'.$img_title.'">'.$img_html.'</a></p>';
			}
			else {
				$img_out = '<p>'.$img_html.'</p>';
			}
			$content_before .= $img_out;
		}
	}

	$adsense3 = get_semiwallpaper_option( 'attachment_adsense3' );
	if ( trim($adsense3) )
		$content_before .= '<p><!--noptimize-->'.$adsense3.'<!--/noptimize--></p>';

	/* Debug content before */
	// echo '<pre>'; var_dump( $content_before ); echo '</pre>';

	$content_after = '';

	if ( get_semiwallpaper_option( 'attachment_content_bottom_show' ) != 'no' ) {
		$content_bottom = get_semiwallpaper_option( 'attachment_content_bottom' );
		if ( !$content_bottom ) {
			$content_bottom = '<p><strong>%parent_title% : %post_title%</strong></p> <blockquote>%parent_content_summary%</blockquote> <p> Here is {essential|important|crucial|foremost|fundamental|imperative|main|necessary|needful|required|wanted} {advice|recommendation|chapter|clue|data|info|instruction|knowledge|notification|science|tip} on %parent_terms%. We have the {best|greatest|finest|excellent|cool|prime|tops|world class} {resources|assets|sources|method|source|step|substance} for %parent_terms%. Check it out for yourself! You can {find|discover|gather|get|acquire} %post_title% guide and {read|see|view|look} the latest <a href="%parent_url%">%parent_title%</a>.</p>';
		}
		$content_bottom = wpbisnis_semiwallpaper_attachment_content( $content_bottom );
		$content_after .= $content_bottom;
	}

	$adsense4 = get_semiwallpaper_option( 'attachment_adsense4' );
	if ( trim($adsense4) )
		$content_after .= '<p><!--noptimize-->'.$adsense4.'<!--/noptimize--></p>';

	$img_info = get_semiwallpaper_option( 'attachment_image_info' );
	if ( $img_info != 'no' ) {
		$info = array();
		$info['Title'] = get_the_title();
		$info['Format'] = strtoupper( str_replace('image/', '', $mime) );
		$image_attributes = wp_get_attachment_image_src( $img_id, 'full' );
		if ( $image_attributes ) {
			$info['Width'] = $image_attributes[1].'px';
			$info['Height'] = $image_attributes[2].'px';
			$info['URL'] = $image_attributes[0];
		}
		if ( ! empty( $post->post_excerpt ) ) {
			$info['Caption'] = $post->post_excerpt;
		}
		$info['Published Date'] = get_the_date();
		$info['Latest Updated Date'] = get_the_modified_date();
		$info['Uploaded By'] = get_the_author();
		/* Debug image info */
		// echo '<pre>'; var_dump( $info ); echo '</pre>';
		if ( !empty( $info ) ) {
			$info_out = '<table class="entry-image-info">';
			foreach ($info as $key => $value) {
				$info_out .= '<tr>';
				$info_out .= '<th>'.$key.'</th>';
				$info_out .= '<td>'.$value.'</td>';
				$info_out .= '</tr>';
			}
			$info_out .= '</table>';
			$content_after .= $info_out;
		}
	}


	$backto = get_semiwallpaper_option( 'attachment_backto' );
	if ( $backto != 'no' && $post_parent_id ) {
		$parent_title = get_the_title( $post_parent_id );
		$content_after .= '<p><strong>Back To <a href="'.get_permalink($post_parent_id).'" title="'.esc_attr($parent_title).'">'.$parent_title.'</a></strong></p>';
	}

	$gallery = get_semiwallpaper_option( 'attachment_gallery' );
	if ( $gallery != 'no' && $post_parent_id ) {
		$content_after .= wpbisnis_semiwallpaper_post_galleries( $post_parent_id, true, '-1', 'rand' );
	}

	$related = get_semiwallpaper_option( 'attachment_related' );
	if ( $related != 'no' && $post_parent_id ) {
		$content_after .= wpbisnis_semiwallpaper_related_posts( $post_parent_id, true );
	}

	/* Debug content after */
	// echo '<pre>'; var_dump( $content_after ); echo '</pre>';

	$content = $content_before . $content . $content_after;

	return $content;
}

add_action( 'wp', 'wpbisnis_semiwallpaper_prepend_attachment_remove' );
function wpbisnis_semiwallpaper_prepend_attachment_remove() {
	if ( !is_singular('attachment') )
		return;

	$mime = get_post_mime_type();
	if ( strpos( $mime, 'image' ) !== false) {
	    remove_filter('the_content', 'prepend_attachment');
	}
}

add_filter('pre_option_use_balanceTags', 'wpbisnis_semiwallpaper_use_balanceTags');
function wpbisnis_semiwallpaper_use_balanceTags( $option ) {
	return 1;
}

add_filter( 'wp_title', 'wpbisnis_semiwallpaper_attachment_wp_title', 99 );
function wpbisnis_semiwallpaper_attachment_wp_title( $title ) {
	if ( get_post_type() == 'attachment' )
		$title = wpbisnis_semiwallpaper_format_title( $title );
	return $title;
}

add_filter( 'the_title', 'wpbisnis_semiwallpaper_attachment_title', 99 );
function wpbisnis_semiwallpaper_attachment_title( $title ) {
	if ( get_post_type() == 'attachment' )
		$title = wpbisnis_semiwallpaper_format_title( $title );
	return $title;
}

function wpbisnis_semiwallpaper_format_title( $title ) {
	$title = str_replace( array( ' - ' ), '%%%%%', $title );
	$title = str_replace( array( '_', '-' ), ' ', $title );
	$title = str_replace( array( '%%%%%' ), ' - ', $title );
	$title = ucwords( $title );
	return $title;
}

function wpbisnis_semiwallpaper_post_galleries( $post_id = '', $title = true, $number = '-1', $orderby = 'menu_order', $linkto = 'attachment' ) {
	global $post;

	if ( !$post_id )
		$post_id = get_the_ID();

	$output = '';

	$attachment_ids = get_posts( 'post_parent=' . $post_id . '&numberposts=' . $number . ' &post_type=attachment&orderby=' . $orderby . '&order=ASC&post_mime_type=image&fields=ids' );

	if ( $attachment_ids ) {
		
		if ( $title )
			$output .= '<h2 class="entry-image-gallery-title">'.count( $attachment_ids ).' photos of the "'.get_the_title( $post_id ).'"</h2>';

		$output .= '<div class="entry-image-gallery"><p>';

		foreach ( $attachment_ids as $img_id ) {

			if ( $linkto == 'post' ) {
				$img_link = get_permalink( $post_id );
			}
			elseif ( $linkto == 'image' ) {
				$img_src = wp_get_attachment_image_src( $img_id, 'full' );
				$img_link = $img_src[0];
			}
			else {
				$img_link = get_permalink( $img_id );
			}

			if ( ! $img_link )
				continue;

			$img_title = esc_attr( wpbisnis_semiwallpaper_format_title( get_the_title( $img_id ) ) );
			$img_html = wp_get_attachment_image( $img_id, 'thumbnail', false, array( 'alt' => $img_title ) );

			$output .= sprintf( '<span class="image-thumbnail"><a href="%s" title="%s">%s</a></span>', $img_link, $img_title, $img_html );

		}

		$output .= '</p></div>';
	}

	return $output;
}

function wpbisnis_semiwallpaper_related_posts( $post_id = '', $title = true ) {
	global $wpdb;

	if ( !$post_id )
		$post_id = get_the_ID();

	// Related products are found from category
	$cats_array = array();
	$cats = '';
	$terms = wp_get_post_terms($post_id, 'category');
	foreach ($terms as $term) {
		$cats_array[] = $term->term_id;
	}
	$cats = implode(',', $cats_array);

	$args = array(
		'cat' => $cats,
		'post__not_in' => array( $post_id ),
		'posts_per_page' => 4,
		'orderby' => 'rand',
		);

	/* Debug related post args */
	// echo '<pre>'; var_dump( $args ); echo '</pre>';

	// The Query
	$the_query = new WP_Query( $args );

	/* Debug query */
	// echo '<pre>'; var_dump( $the_query ); echo '</pre>';

	$output = '';

	// The Loop
	if ( $the_query->have_posts() ) {
		$output .= '<h2 class="entry-related-posts-title">Related posts of "'.get_the_title( $post_id ).'"</h2>';
		$output .= '<div class="entry-related-posts">';
		while ( $the_query->have_posts() ) {
			$the_query->the_post();
			global $post;
			$output .= '<div class="entry-related-post">';
			$output .= wpbisnis_semiwallpaper_thumbnail( 'thumbnail', 'alignleft' );
			$output .= the_title( sprintf( '<h4><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>', false );
			$output .= '<p>'.wp_trim_words( strip_tags( $post->post_content ), 55, '...' ).'</p>';
			$output .= '</div>';
		}
		$output .= '</div>';
	} 
	else {
		// no posts found
	}
	/* Restore original Post Data */
	wp_reset_postdata();

	return $output;
}

function wpbisnis_semiwallpaper_thumbnail( $size = 'thumbnail', $class = 'entry-image', $linkto = 'post', $before = '', $after = '' ) {

	global $post;

	$id = false;

	if ( has_post_thumbnail() ) {
		$id = get_post_thumbnail_id();
	}
	//* Else if first-attached, pull the first (default) image attachment
	else {
		$image_ids = array_keys(
			get_children(
				array(
					'post_parent'    => $post->ID,
					'post_type'	     => 'attachment',
					'post_mime_type' => 'image',
					'orderby'        => 'menu_order',
					'order'	         => 'ASC',
				)
			)
		);
		if ( isset( $image_ids[0] ) )
			$id = $image_ids[0];
	}

	if ( !$id )
		return;

	$html = wp_get_attachment_image( $id, $size, false, array( 'class' => $class ) );

	if ( !$html )
		return;

	if ( $linkto == 'attachment' ) {
		$link = get_permalink($id);
	}
	elseif ( $linkto == 'image' ) {
		$img_src = wp_get_attachment_image_src( $id, 'full' );
		$link = $img_src[0];
	}
	else {
		$link = get_permalink();
	}

	return sprintf( '%s<a href="%s" title="%s">%s</a>%s', $before, $link, the_title_attribute('echo=0'), $html, $after );
}

function wpbisnis_semiwallpaper_clean_post_content( $id ) {
	$parent = get_post( $id );
	$content = $parent->post_content;
	if ( ! $parent->post_content )
		return null;
	$content = strip_shortcodes( $content );
	$content = wpautop( $content, false );
	$content = wp_kses( $content, array(
	    'a' => array(
	        'href' => array(),
	        'title' => array()
	    ),
	    'br' => array(),
	    'em' => array(),
	    'strong' => array(),
	    'p' => array(),
	) );
	$split = explode( "</p>", $content );
	$clean = array();
	foreach ( $split as $value ) {
		$value = wp_strip_all_tags( $value, false );
		$length = function_exists( 'mb_strlen' ) ? mb_strlen( $value, 'utf8' ) : strlen( $value );
		if ( $length > 100 ) 
			$clean[] = wpautop( $value );
	}
	if ( empty( $clean ) )
		return null;
	return $clean;
}

function wpbisnis_semiwallpaper_single_content( $content ) {
	global $post;
	$spintax = new WPBisnis_Semiwallpaper_Spintax();
	$content = $spintax->process($content);
	if ( strpos( $content, '%post_title%' ) !== false) {
		$title = wpbisnis_semiwallpaper_format_title( get_the_title() );
		// $title = strtolower($title);
		$content = str_replace( '%post_title%', $title, $content );
	}
	if ( strpos( $content, '%post_date%' ) !== false) {
		$date = get_the_date();
		$content = str_replace( '%post_date%', $date, $content );
	}
	if ( strpos( $content, '%post_time%' ) !== false) {
		$time = get_the_time();
		$content = str_replace( '%post_time%', $time, $content );
	}
	if ( strpos( $content, '%post_author%' ) !== false) {
		$author = get_the_author();
		$content = str_replace( '%post_author%', $author, $content );
	}
	if ( strpos( $content, '%post_image%' ) !== false) {
		$image = wp_get_attachment_url( $post->ID, 'full' );
		$content = str_replace( '%post_image%', $image, $content );
	}
	if ( strpos( $content, '%post_url%' ) !== false) {
		$url = get_permalink($post->ID);
		$content = str_replace( '%parent_url%', $url, $content );
	}
	if ( strpos( $content, '%post_cats%' ) !== false) {
		$cats_array = array();
		$cats = '';
		$terms = wp_get_post_terms($post->ID, 'category');
		foreach ($terms as $term) {
			$cats_array[] = $term->name;
		}
		$cats = implode(', ', $cats_array);
		// $cats = strtolower( $cats );
		$content = str_replace( '%post_cats%', $cats, $content );
	}
	if ( strpos( $content, '%post_tags%' ) !== false) {
		$tags_array = array();
		$tags = '';
		$terms = wp_get_post_terms($post->ID, 'post_tag');
		foreach ($terms as $term) {
			$tags_array[] = $term->name;
		}
		$tags = implode(', ', $tags_array);
		// $tags = strtolower( $tags );
		$content = str_replace( '%post_tags%', $tags, $content );
	}
	if ( strpos( $content, '%post_terms%' ) !== false) {
		$cats_array = array();
		$cats = '';
		$terms = wp_get_post_terms($post->ID, 'category');
		foreach ($terms as $term) {
			$cats_array[] = $term->name;
		}

		$tags_array = array();
		$tags = '';
		$terms = wp_get_post_terms($post->ID, 'post_tag');
		foreach ($terms as $term) {
			$tags_array[] = $term->name;
		}

		$terms_array = array_merge( $cats_array, $tags_array );
		$terms_out = implode(', ', $terms_array);
		// $terms_out = strtolower( $terms_out );
		$content = str_replace( '%post_terms%', $terms_out, $content );
	}
	$content = wpautop( $content );
	return $content;
}

function wpbisnis_semiwallpaper_attachment_content( $content ) {
	global $post;
	$spintax = new WPBisnis_Semiwallpaper_Spintax();
	$content = $spintax->process($content);
	if ( strpos( $content, '%post_title%' ) !== false) {
		$title = wpbisnis_semiwallpaper_format_title( get_the_title() );
		// $title = strtolower($title);
		$content = str_replace( '%post_title%', $title, $content );
	}
	if ( strpos( $content, '%post_date%' ) !== false) {
		$date = get_the_date();
		$content = str_replace( '%post_date%', $date, $content );
	}
	if ( strpos( $content, '%post_time%' ) !== false) {
		$time = get_the_time();
		$content = str_replace( '%post_time%', $time, $content );
	}
	if ( strpos( $content, '%post_author%' ) !== false) {
		$author = get_the_author();
		$content = str_replace( '%post_author%', $author, $content );
	}
	if ( strpos( $content, '%post_image%' ) !== false) {
		$image = wp_get_attachment_url( $post->ID, 'full' );
		$content = str_replace( '%post_image%', $image, $content );
	}
	if ( strpos( $content, '%parent_title%' ) !== false) {
		if ( $post->post_parent ) {
			$title = get_the_title($post->post_parent);
			// $title = strtolower($title);
		}
		else {
			$title = '';
		}
		$content = str_replace( '%parent_title%', $title, $content );
	}
	if ( strpos( $content, '%parent_url%' ) !== false) {
		if ( $post->post_parent ) {
			$url = get_permalink($post->post_parent);
			$content = str_replace( '%parent_url%', $url, $content );
		}
		else {
			$url = '';
		}
	}
	if ( strpos( $content, '%parent_cats%' ) !== false) {
		if ( $post->post_parent ) {
			$cats_array = array();
			$cats = '';
			$terms = wp_get_post_terms($post->post_parent, 'category');
			foreach ($terms as $term) {
				$cats_array[] = $term->name;
			}
			$cats = implode(', ', $cats_array);
			// $cats = strtolower( $cats );
		}
		else {
			$cats = '';
		}
		$content = str_replace( '%parent_cats%', $cats, $content );
	}
	if ( strpos( $content, '%parent_tags%' ) !== false) {
		if ( $post->post_parent ) {
			$tags_array = array();
			$tags = '';
			$terms = wp_get_post_terms($post->post_parent, 'post_tag');
			foreach ($terms as $term) {
				$tags_array[] = $term->name;
			}
			$tags = implode(', ', $tags_array);
			// $tags = strtolower( $tags );
		}
		else {
			$tags = '';
		}
		$content = str_replace( '%parent_tags%', $tags, $content );
	}
	if ( strpos( $content, '%parent_terms%' ) !== false) {
		if ( $post->post_parent ) {
			$cats_array = array();
			$cats = '';
			$terms = wp_get_post_terms($post->post_parent, 'category');
			foreach ($terms as $term) {
				$cats_array[] = $term->name;
			}

			$tags_array = array();
			$tags = '';
			$terms = wp_get_post_terms($post->post_parent, 'post_tag');
			foreach ($terms as $term) {
				$tags_array[] = $term->name;
			}

			$terms_array = array_merge( $cats_array, $tags_array );
			$terms_out = implode(', ', $terms_array);
			// $terms_out = strtolower( $terms_out );
		}
		else {
			$terms_out = '';
		}
		$content = str_replace( '%parent_terms%', $terms_out, $content );
	}
	if ( strpos( $content, '%parent_content_full%' ) !== false) {
		$out = '';
		if ( $post->post_parent ) {
			$pcontent = wpbisnis_semiwallpaper_clean_post_content( $post->post_parent );
			$out = implode('', $pcontent);
			$content = str_replace( '%parent_content_full%', $out, $content );
		}
	}
	if ( strpos( $content, '%parent_content_summary%' ) !== false) {
		$out = '';
		if ( $post->post_parent ) {
			$pcontent = wpbisnis_semiwallpaper_clean_post_content( $post->post_parent );
			if ( isset( $pcontent[0] ) )
				$out .= $pcontent[0];
			if ( isset( $pcontent[1] ) )
				$out .= $pcontent[1];
			$content = str_replace( '%parent_content_summary%', $out, $content );
		}
	}
	if ( strpos( $content, '%parent_content_random%' ) !== false) {
		$out = '';
		if ( $post->post_parent ) {
			$pcontent = wpbisnis_semiwallpaper_clean_post_content( $post->post_parent );
			$rand = array_rand( $pcontent );
			$out = $pcontent[$rand];
			$content = str_replace( '%parent_content_random%', $out, $content );
		}
	}
	$content = wpautop( $content );
	return $content;
}

/**
 * Spintax - A helper class to process Spintax strings.
 * @name Spintax
 * @author Jason Davis - https://www.codedevelopr.com/
 * Tutorial: https://www.codedevelopr.com/articles/php-spintax-class/
 */
class WPBisnis_Semiwallpaper_Spintax
{
    public function process($text)
    {
        return preg_replace_callback(
            '/\{(((?>[^\{\}]+)|(?R))*)\}/x',
            array($this, 'replace'),
            $text
        );
    }

    public function replace($text)
    {
        $text = $this->process($text[1]);
        $parts = explode('|', $text);
        return $parts[array_rand($parts)];
    }
}

/* EXAMPLE USAGE */
// $spintax = new WPBisnis_Semiwallpaper_Spintax();
// $string = '{Hello|Howdy|Hola} to you, {Mr.|Mrs.|Ms.} {Smith|Williams|Davis}!';
// echo $spintax->process($string);

/* NESTED SPINNING EXAMPLE */
// echo $spintax->process('{Hello|Howdy|Hola} to you, {Mr.|Mrs.|Ms.} {{Jason|Malina|Sara}|Williams|Davis}');
